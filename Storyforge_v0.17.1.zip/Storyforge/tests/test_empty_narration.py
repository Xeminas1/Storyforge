"""An otherwise valid scene heading is not a Game Master story response."""
import json
import os
import sys
import tempfile
import threading
import unittest
from contextlib import contextmanager
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import engine


HEADER = '[Clock Quay - Greyhaven - Dusk]'
ACTION = 'I wait beside the notice board.'
PROSE = HEADER + '\n\nA courier rings a handbell.'
LABELS = {'location': 'Clock Quay', 'parent_area': 'Greyhaven', 'time_of_day': 'Dusk'}


def envelope(narration, updates=None):
    return json.dumps({'narration': narration, 'state_updates': updates or {}})


@contextmanager
def local_ollama(replies):
    requests = []

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, _format, *args):
            pass

        def do_POST(self):
            requests.append(json.loads(self.rfile.read(int(self.headers['Content-Length']))))
            document = {'message': {'content': replies[min(len(requests) - 1, len(replies) - 1)]},
                        'done': True, 'done_reason': 'stop'}
            payload = json.dumps(document).encode()
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)

    server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
    worker = threading.Thread(target=server.serve_forever, daemon=True)
    worker.start()
    try:
        yield f'http://127.0.0.1:{server.server_port}', requests
    finally:
        server.shutdown()
        worker.join(timeout=5)
        server.server_close()


class EmptyNarrationTests(unittest.TestCase):
    def setUp(self):
        directory = self.enterContext(tempfile.TemporaryDirectory())
        self.con = engine.open_db(Path(directory) / 'fixture.db')
        self.addCleanup(self.con.close)
        self.world = engine.make_world(self.con, {'title': 'Greyhaven',
            'description': 'A river city with a public notice board at Clock Quay.'})
        campaign = engine.new_campaign(self.con, {'world_id': self.world['id'],
            'pc_name': 'Riven', 'species': 'Human', 'starting_location': 'Clock Quay',
            'starting_items': 'bronze key'})
        self.cid = campaign['id']
        state = dict(campaign['state'])
        state.update(LABELS)
        with self.con:
            self.con.execute('UPDATE campaigns SET state_json=? WHERE id=?', (json.dumps(state), self.cid))
            self.con.execute('INSERT INTO messages(campaign_id,role,content,created_at) VALUES (?,?,?,?)',
                (self.cid, 'gm', HEADER + '\n\nA seller folds a striped cloth beside the notice board.', engine.now()))

    def snapshot(self):
        return list(self.con.iterdump())

    def review(self, narration):
        return engine._review_gm_turn(narration, {}, LABELS, 'Riven', ACTION, [],
            world_title='Greyhaven', require_evidence=True)

    def test_parser_rejects_heading_only_even_when_no_newline_remains(self):
        for narration in (HEADER, HEADER + '\n', HEADER + '\n\n', '  ' + HEADER + '\t  '):
            with self.subTest(narration=narration):
                with self.assertRaisesRegex(ValueError, 'empty narration'):
                    engine.parse_gm_response(envelope(narration))

    def test_parser_rejects_punctuation_and_decorative_body(self):
        for body in ('', ' \t\r\n ', '...', '***', '— —', '“”', '```', '\u200b', '\n* * *\n'):
            for separator in ('\n\n', ' '):
                with self.subTest(body=body, separator=separator):
                    with self.assertRaisesRegex(ValueError, 'empty narration'):
                        engine.parse_gm_response(envelope(HEADER + separator + body))

    def test_shared_review_rejects_an_empty_story_independently_of_the_parser(self):
        for narration in ('', ' ', HEADER, HEADER + '\n\n', HEADER + '\n\n***', HEADER + ' ...'):
            with self.subTest(narration=narration):
                review = self.review(narration)
                self.assertTrue(review.narrative_violations)
                self.assertTrue(any('body' in finding for finding in review.narrative_violations))

    def test_short_valid_npc_or_world_prose_has_no_minimum_word_count(self):
        for body in ('A bell rings.', '"Wait," the courier says.', '*Closed.*', 'La cloche sonne.', '鐘が鳴る。', '"7," the clerk says.'):
            for narration in (body, HEADER + '\n\n' + body):
                with self.subTest(narration=narration):
                    parsed, updates = engine.parse_gm_response(envelope(narration))
                    self.assertEqual(parsed, narration)
                    self.assertEqual(updates, {})
                    self.assertEqual(self.review(narration).narrative_violations, ())

    def test_header_only_then_valid_story_rewrites_narration_without_extraction(self):
        calls = []

        def chat(messages, model, *, timeout, response_schema):
            calls.append({'messages': json.loads(json.dumps(messages)), 'schema': response_schema})
            return envelope(HEADER) if len(calls) == 1 else envelope(PROSE)

        chat.supports_timeout = chat.supports_response_schema = chat.requires_state_evidence = True
        result = engine.play_turn(self.con, self.cid, ACTION, model='synthetic:14b', chat=chat)
        self.assertEqual(len(calls), 2)
        self.assertTrue(all('narration' in call['schema']['properties'] for call in calls))
        self.assertEqual(result['narration'], PROSE)
        self.assertEqual(sum(message['role'] == 'player' and message['content'] == ACTION
                             for message in result['messages']), 1)
        self.assertEqual(calls[0]['messages'], calls[1]['messages'][:-1])
        self.assertNotIn(HEADER, calls[1]['messages'][-1]['content'])
        self.assertFalse(any(message['role'] == 'assistant' and message['content'] == HEADER
                             for message in calls[1]['messages']))

    def test_two_empty_replies_preserve_every_campaign_row(self):
        before = self.snapshot()
        calls = []

        def chat(messages, model, *, timeout, response_schema):
            calls.append(response_schema)
            return envelope(HEADER + '\n\n***')

        chat.supports_timeout = chat.supports_response_schema = chat.requires_state_evidence = True
        with self.assertRaises(ValueError):
            engine.play_turn(self.con, self.cid, ACTION, model='synthetic:14b', chat=chat)
        self.assertEqual(len(calls), 2)
        self.assertTrue(all('narration' in schema['properties'] for schema in calls))
        self.assertEqual(self.snapshot(), before)

    def test_empty_retry_preserves_saved_action_reply_feedback_and_state(self):
        valid = engine.play_turn(self.con, self.cid, ACTION,
            chat=lambda messages, model: envelope(PROSE))
        target = next(message for message in reversed(valid['messages']) if message['role'] == 'gm')
        before = self.snapshot()
        calls = []

        def chat(messages, model, *, timeout, response_schema):
            calls.append(response_schema)
            return envelope(HEADER)

        chat.supports_timeout = chat.supports_response_schema = chat.requires_state_evidence = True
        with self.assertRaises(ValueError):
            engine.retry_message(self.con, self.cid, target['id'], feedback='Add a relevant detail.',
                                 model='synthetic:14b', chat=chat)
        self.assertEqual(len(calls), 2)
        self.assertEqual(self.snapshot(), before)

    def test_real_loopback_schema_retries_story_and_never_extracts_a_header(self):
        with local_ollama([envelope(HEADER), envelope(PROSE)]) as (endpoint, requests), \
                patch.dict(os.environ, {'OLLAMA_URL': endpoint}):
            result = engine.play_turn(self.con, self.cid, ACTION, model='synthetic:14b')
        self.assertEqual(result['narration'], PROSE)
        self.assertEqual(len(requests), 2)
        self.assertTrue(all('narration' in request['format']['properties'] for request in requests))
        self.assertTrue(all(request['options']['num_predict'] == 1050 for request in requests))


if __name__ == '__main__':
    unittest.main()
