"""Repository-only diagnostic bundle checks with scripted loopback Ollama."""
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
import tempfile
import threading
import unittest
import zipfile
from contextlib import contextmanager
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BUILDER = ROOT / 'tools' / 'build_continuity_check.py'
OLD_PACKAGE = ROOT / 'dist' / 'Storyforge_v0.16.7.zip'
if BUILDER.exists():
    spec = importlib.util.spec_from_file_location('continuity_check_builder', BUILDER)
    builder = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(builder)
else:
    builder = None


@contextmanager
def scripted_local_ollama(*, repair=False):
    from test_gm_continuity_evaluation import synthetic_responder
    respond = synthetic_responder()
    requests = []

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, _format, *args):
            pass

        def send_json(self, document):
            content = json.dumps(document).encode()
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(content)))
            self.end_headers()
            self.wfile.write(content)

        def do_GET(self):
            self.send_json({'version': 'synthetic-test'} if self.path == '/api/version' else {'models': []})

        def do_POST(self):
            document = json.loads(self.rfile.read(int(self.headers['Content-Length'])))
            if self.path != '/api/chat':
                self.send_json({})
                return
            requests.append(document)
            if 'narration' not in document['format'].get('properties', {}):
                content = json.dumps({'state_updates': {'location': 'North Landing', 'evidence': {
                    'location': 'The shuttle reaches North Landing in Bellwater, where late afternoon light touches the blue sign.'}}})
            else:
                response = json.loads(respond(document['messages'], document['model']))
                if repair and response['state_updates'].get('location') == 'North Landing':
                    response['narration'] = '[North Landing - Bellwater - Late afternoon]\n\n' + response['narration']
                    response['state_updates']['evidence']['location'] = 'SYNTHETIC UNSUPPORTED EXTRACTION'
                content = json.dumps(response)
            self.send_json({'message': {'content': content}, 'done': True, 'done_reason': 'stop',
                           'load_duration': 1_000_000, 'eval_count': 30})

    httpd = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
    worker = threading.Thread(target=httpd.serve_forever, daemon=True)
    worker.start()
    try:
        yield f'http://127.0.0.1:{httpd.server_port}', requests
    finally:
        httpd.shutdown()
        worker.join(timeout=5)
        httpd.server_close()


@unittest.skipUnless(builder is not None, 'Diagnostic builder is repository-only and excluded from installed application updates.')
class ContinuityCheckBundleTests(unittest.TestCase):
    def make_installation(self, directory, *, old=False):
        installation = directory / 'installed'
        installation.mkdir()
        if old:
            with zipfile.ZipFile(OLD_PACKAGE) as archive:
                for name in ('engine.py', 'updater.py'):
                    candidates = [entry for entry in archive.namelist() if entry == name or entry.endswith('/' + name)]
                    self.assertEqual(len(candidates), 1)
                    (installation / name).write_bytes(archive.read(candidates[0]))
        else:
            for name in ('engine.py', 'updater.py'):
                (installation / name).write_bytes((ROOT / name).read_bytes())
        data = installation / 'data'
        data.mkdir()
        (data / 'storyforge.db').write_bytes(b'PRIVATE NON-SQLITE SAVE CANARY')
        (data / 'portrait.png').write_bytes(b'PRIVATE ART CANARY')
        (data / 'settings.json').write_text('{"model":"PRIVATE SELECTED MODEL"}')
        return installation

    def invoke(self, artifact, installation, endpoint, *options):
        environment = dict(os.environ, OLLAMA_URL=endpoint,
                           STORYFORGE_DB=str(installation / 'data' / 'storyforge.db'))
        return subprocess.run([sys.executable, str(artifact), *options], cwd=installation,
                              env=environment, text=True, capture_output=True, timeout=30)

    def test_bundle_is_deterministic_and_contains_only_new_helper_files(self):
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            first = builder.build(directory / 'one')
            second = builder.build(directory / 'two')
            self.assertEqual(first['sha256'], second['sha256'])
            with zipfile.ZipFile(first['bundle']) as archive:
                self.assertEqual(set(archive.namelist()), {'Storyforge-GM-Check.py',
                    'Run-Storyforge-GM-Check.cmd', 'README-GM-Check.txt'})
                source = archive.read('Storyforge-GM-Check.py').decode()
                compile(source, 'Storyforge-GM-Check.py', 'exec')
                self.assertIn('sys.dont_write_bytecode = True', source)
                self.assertIn('engine.__dict__', source)
                self.assertIn('ministral-3:14b', source)
                self.assertNotIn('PRIVATE NON-SQLITE SAVE CANARY', source)
                self.assertIn(b'pause\r\n', archive.read('Run-Storyforge-GM-Check.cmd'))
                self.assertIn('not an application update', archive.read('README-GM-Check.txt').decode())
            self.assertEqual(hashlib.sha256(Path(first['bundle']).read_bytes()).hexdigest(), first['sha256'])

    @unittest.skipUnless(OLD_PACKAGE.exists(), 'Historical release ZIP is a local verification artifact.')
    def test_runs_with_installed_v0167_and_preserves_application_and_private_data(self):
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            builder.build(directory / 'helper')
            artifact = directory / 'helper' / 'Storyforge-GM-Check.py'
            installation = self.make_installation(directory, old=True)
            before = {str(path.relative_to(installation)): path.read_bytes()
                      for path in installation.rglob('*') if path.is_file()}
            with scripted_local_ollama() as (endpoint, requests):
                result = self.invoke(artifact, installation, endpoint)
            self.assertEqual(result.returncode, 0, result.stdout[-2000:] + result.stderr)
            self.assertEqual(len(requests), 9)
            self.assertTrue(all(request['model'] == 'ministral-3:14b' for request in requests))
            reports = list((installation / 'data').glob('continuity-check-*.json'))
            self.assertEqual(len(reports), 1)
            report = json.loads(reports[0].read_text())
            self.assertEqual(report['storyforge_version'], '0.16.7')
            self.assertEqual(report['execution'], 'local_ollama')
            self.assertEqual(report['summary']['completed_runs'], 1)
            self.assertEqual(report['summary']['completed'], 9)
            self.assertNotIn('PRIVATE', reports[0].read_text())
            for name, content in before.items():
                self.assertEqual((installation / name).read_bytes(), content)
            self.assertFalse(list(installation.rglob('*.pyc')))
            self.assertFalse((installation / 'server.py').exists())

    def test_new_engine_state_extraction_uses_its_dedicated_schema(self):
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            builder.build(directory / 'helper')
            installation = self.make_installation(directory)
            output = directory / 'new-report.json'
            with scripted_local_ollama(repair=True) as (endpoint, requests):
                result = self.invoke(directory / 'helper' / 'Storyforge-GM-Check.py', installation, endpoint,
                                     '--model', 'scripted:14b', '--report', str(output))
            self.assertEqual(result.returncode, 0, result.stdout[-2000:] + result.stderr)
            self.assertEqual(len(requests), 10)
            report = json.loads(output.read_text())
            self.assertEqual(report['summary']['completed_runs'], 1)
            travel = report['runs'][0]['steps'][6]
            self.assertEqual([attempt['phase'] for attempt in travel['attempts']], ['narration', 'state_extraction'])
            extraction = next(request for request in requests if 'narration' not in request['format']['properties'])
            self.assertNotIn('SYNTHETIC UNSUPPORTED EXTRACTION', json.dumps(extraction))
            self.assertEqual(len(extraction['messages']), 2)

    def test_existing_report_is_refused_before_model_calls_or_file_changes(self):
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            builder.build(directory / 'helper')
            installation = self.make_installation(directory)
            output = directory / 'existing.json'
            output.write_text('KEEP EXISTING REPORT')
            with scripted_local_ollama() as (endpoint, requests):
                result = self.invoke(directory / 'helper' / 'Storyforge-GM-Check.py', installation, endpoint,
                                     '--report', str(output))
            self.assertEqual(result.returncode, 2)
            self.assertEqual(requests, [])
            self.assertEqual(output.read_text(), 'KEEP EXISTING REPORT')
            self.assertIn('already exists', result.stderr)

    def test_invalid_repeat_is_refused_before_any_ollama_request(self):
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            builder.build(directory / 'helper')
            installation = self.make_installation(directory)
            with scripted_local_ollama() as (endpoint, requests):
                result = self.invoke(directory / 'helper' / 'Storyforge-GM-Check.py', installation, endpoint,
                                     '--repeat', '0')
            self.assertEqual(result.returncode, 2)
            self.assertEqual(requests, [])
            self.assertFalse(list((installation / 'data').glob('continuity-check-*.json')))


if __name__ == '__main__':
    unittest.main()
