"""Synthetic behavioral contracts for narrative review and state-only repair.

These fixtures describe an original setting. They test stage ownership and
transactions, rather than particular wording from a personal campaign.
"""
import copy
import io
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import engine


LABELS = {'location': 'Ferry Court', 'parent_area': 'Valewick', 'time_of_day': 'Dusk'}
HEADER = '[Ferry Court - Valewick - Dusk]'
INTRO = (HEADER + '\n\n'
         'A fishmonger stacks wicker baskets below a striped awning. '
         'Three watch officers examine a broken wagon wheel beside the fountain. '
         'A clockmaker carries a wrapped pendulum through the eastern archway.')
BODY = ('The clerk opens a green ledger. A copper token rests on the counter. '
        'Two apprentices sort bundles of letters beneath a cracked skylight. '
        'The clerk asks, "Which delivery needs tracing?"')
FRESH = HEADER + '\n\n' + BODY
OTHER = (HEADER + '\n\n'
         'A messenger places an ivory whistle beside the scales. '
         'The clerk studies its maker\'s mark through a brass lens. '
         'Outside, the fountain stops and a caretaker unlocks the pump housing.')
DESTINATION = 'Beacon Archive'
MOVE_QUOTE = 'Inside Beacon Archive, a keeper places an amber lamp beside a bound atlas.'
MOVE = ('[Beacon Archive - Valewick - Dusk]\n\n' + MOVE_QUOTE + ' '
        'A wooden screen separates the reading room from shelves of wax tablets. '
        'The keeper asks, "Would the maps or shipping registers be useful?"')
RAW_PATCH_MARKER = 'UNTRUSTED_STATE_PROPOSAL_23'
WORLD_MARKER = 'FULL_WORLD_CONTEXT_EXCLUDED_FROM_STATE_REPAIR_47'


def full_reply(narration, updates=None):
    return {'narration': narration, 'state_updates': copy.deepcopy(updates or {})}


def state_reply(updates=None):
    return {'state_updates': copy.deepcopy(updates or {})}


class StagedGMPipelineTests(unittest.TestCase):
    def setUp(self):
        directory = self.enterContext(tempfile.TemporaryDirectory())
        self.con = engine.open_db(Path(directory) / 'synthetic.db')
        self.addCleanup(self.con.close)
        world = engine.make_world(self.con, {
            'title': 'The City of Valewick',
            'description': 'An original river-city story about messengers and cartographers. ' + WORLD_MARKER})
        campaign = engine.new_campaign(self.con, {
            'world_id': world['id'], 'pc_name': 'Tamsin', 'aliases': 'Ash Warden',
            'pronouns': 'she/her', 'species': 'Human'})
        self.cid = campaign['id']
        self.prior_memory = {'summary': 'The ferry bell needs repair.', 'npcs': [],
                             'events': ['A barge arrived before dawn.'],
                             'open_threads': ['The western bridge remains closed.']}
        state = copy.deepcopy(campaign['state'])
        state.update(LABELS)
        state.update(inventory=['iron key'], journal=['The harbour lights are lit.'],
                     scene_memory=copy.deepcopy(self.prior_memory))
        with self.con:
            self.con.execute('UPDATE campaigns SET state_json=? WHERE id=?', (json.dumps(state), self.cid))
            opening = self.con.execute(
                'INSERT INTO messages (campaign_id,role,content,created_at) VALUES (?,?,?,?)',
                (self.cid, 'gm', INTRO, engine.now())).lastrowid
            self.con.execute('INSERT INTO turn_checkpoints VALUES (?,?,?,?)',
                             (opening, json.dumps(state), json.dumps(state), '__START__'))
        self.opening_id = opening

    def snapshot(self):
        return list(self.con.iterdump())

    def set_labels(self, **labels):
        state = engine.get_campaign(self.con, self.cid)['state']
        for field in LABELS:
            state.pop(field, None)
        state.update(labels)
        with self.con:
            self.con.execute('UPDATE campaigns SET state_json=? WHERE id=?', (json.dumps(state), self.cid))
            self.con.execute('UPDATE turn_checkpoints SET state_before=?,state_after=? WHERE gm_message_id=?',
                             (json.dumps(state), json.dumps(state), self.opening_id))

    def script(self, *responses):
        calls = []
        originals = copy.deepcopy(responses)

        def chat(messages, model, *, timeout=None, response_schema=None):
            self.assertEqual(model, 'ministral-3:14b')
            calls.append({'messages': copy.deepcopy(messages), 'timeout': timeout,
                          'schema': copy.deepcopy(response_schema)})
            self.assertLessEqual(len(calls), len(responses), 'No hidden third model request is permitted.')
            response = responses[len(calls) - 1]
            if isinstance(response, Exception):
                raise response
            return response if isinstance(response, str) else json.dumps(response)

        chat.supports_timeout = True
        chat.supports_response_schema = True
        chat.requires_state_evidence = True
        return chat, calls, originals

    def play(self, responses, action='I listen.'):
        chat, calls, _ = self.script(*responses)
        result = engine.play_turn(self.con, self.cid, action, model='ministral-3:14b', chat=chat)
        return result, calls

    def assert_scene(self, result, labels=None):
        self.assertEqual({field: result['state'].get(field) for field in LABELS}, labels or LABELS)

    def assert_rejected(self, responses, action='I listen.', retry_id=None):
        before = self.snapshot()
        chat, calls, _ = self.script(*responses)
        with self.assertRaises((ValueError, RuntimeError)):
            if retry_id is None:
                engine.play_turn(self.con, self.cid, action, model='ministral-3:14b', chat=chat)
            else:
                engine.retry_message(self.con, self.cid, retry_id, feedback='Keep the original scene.',
                                     model='ministral-3:14b', chat=chat)
        self.assertEqual(self.snapshot(), before)
        self.assertLessEqual(len(calls), 2)
        return calls

    def test_consistent_header_drops_different_families_of_unsupported_location_metadata(self):
        for proposal in ('The shutters open beside an ornate wall of colored glass.',
                         json.dumps({'evidence': {'location': 'A fragment of prose.'}}),
                         'Northern Observatory',
                         'Ferry Court - West counter - Valewick - Dusk'):
            with self.subTest(family=type(proposal).__name__, proposal=proposal):
                before = engine.get_campaign(self.con, self.cid)['state']
                chat, calls, originals = self.script(full_reply(FRESH, {'location': proposal}))
                result = engine._generate_turn(
                    self.con, engine.get_campaign(self.con, self.cid),
                    engine.get_world(self.con, engine.get_campaign(self.con, self.cid)['world_id']),
                    'I listen.', engine.get_messages(self.con, self.cid), before,
                    model='ministral-3:14b', chat=chat)
                self.assertEqual(result[0], FRESH)
                self.assertEqual({field: result[1].get(field) for field in LABELS}, LABELS)
                self.assertEqual(len(calls), 1)
                self.assertEqual(originals[0]['state_updates']['location'], proposal)
                self.assertEqual(engine.get_campaign(self.con, self.cid)['state'], before)

    def test_discarded_location_does_not_discard_supported_memory_siblings(self):
        observation = 'The clerk opens a green ledger.'
        result, calls = self.play([full_reply(FRESH, {
            'location': RAW_PATCH_MARKER,
            'scene_memory': {'events': [{'text': observation, 'evidence': observation}]}})])
        self.assertEqual(len(calls), 1)
        self.assert_scene(result)
        self.assertEqual(result['state']['scene_memory']['events'],
                         self.prior_memory['events'] + [observation])

    def test_partial_unknown_scene_fields_are_not_promoted_from_header(self):
        self.set_labels(location=LABELS['location'])
        result, calls = self.play([full_reply(FRESH, {'location': RAW_PATCH_MARKER})])
        self.assertEqual(len(calls), 1)
        self.assertEqual(result['state']['location'], LABELS['location'])
        self.assertNotIn('parent_area', result['state'])
        self.assertNotIn('time_of_day', result['state'])

    def test_no_header_cannot_authorize_discarding_a_bad_location(self):
        calls = self.assert_rejected([
            full_reply(BODY, {'location': RAW_PATCH_MARKER}), state_reply({'location': RAW_PATCH_MARKER})])
        self.assertEqual(len(calls), 2)

    def test_unknown_location_cannot_be_filled_by_an_unsupported_proposal(self):
        self.set_labels(location='Unknown', parent_area='Valewick', time_of_day='Dusk')
        self.assert_rejected([full_reply(FRESH, {'location': RAW_PATCH_MARKER}),
                              state_reply({'location': RAW_PATCH_MARKER})])

    def test_placeholder_proposal_cannot_erase_known_location(self):
        self.assert_rejected([full_reply(FRESH, {'location': 'Unknown'}),
                              state_reply({'location': 'Unknown'})])

    def test_body_supported_actual_transition_persists_in_one_call(self):
        result, calls = self.play([full_reply(MOVE, {
            'location': DESTINATION, 'evidence': {'location': MOVE_QUOTE}})],
            action='I walk to Beacon Archive.')
        self.assertEqual(len(calls), 1)
        self.assert_scene(result, {**LABELS, 'location': DESTINATION})
        self.assertEqual(result['narration'], MOVE)

    def test_body_supported_location_conflicting_with_current_heading_still_rejects(self):
        contradictory = HEADER + '\n\n' + MOVE_QUOTE
        patch_value = {'location': DESTINATION, 'evidence': {'location': MOVE_QUOTE}}
        self.assert_rejected([full_reply(contradictory, patch_value), state_reply(patch_value)],
                             action='I walk to Beacon Archive.')

    def test_changed_heading_needs_supported_state_after_repair(self):
        calls = self.assert_rejected([full_reply(MOVE, {'location': RAW_PATCH_MARKER}), state_reply({})],
                                     action='I walk to Beacon Archive.')
        self.assertEqual(len(calls), 2)
        self.assertEqual(calls[1]['schema'], engine.GM_STATE_RESPONSE_SCHEMA)

    def test_supported_real_transition_repairs_only_state_and_keeps_exact_prose(self):
        result, calls = self.play([
            full_reply(MOVE, {'location': RAW_PATCH_MARKER}),
            state_reply({'location': DESTINATION, 'evidence': {'location': MOVE_QUOTE}})],
            action='I walk to Beacon Archive.')
        self.assertEqual(len(calls), 2)
        self.assertEqual(result['narration'], MOVE)
        self.assert_scene(result, {**LABELS, 'location': DESTINATION})
        self.assertEqual(calls[0]['schema'], engine.GM_RESPONSE_SCHEMA)
        self.assertEqual(calls[1]['schema'], engine.GM_STATE_RESPONSE_SCHEMA)
        self.assertEqual(set(calls[1]['schema']['properties']), {'state_updates'})
        self.assertEqual(set(calls[1]['schema']['required']), {'state_updates'})
        self.assertFalse(calls[1]['schema']['additionalProperties'])
        second = json.dumps(calls[1]['messages'])
        self.assertIn(MOVE_QUOTE, second)
        self.assertIn('I walk to Beacon Archive.', second)
        self.assertIn('Tamsin', second)
        self.assertNotIn(RAW_PATCH_MARKER, second)
        self.assertNotIn(WORLD_MARKER, second)
        self.assertFalse(any(message['role'] == 'assistant' for message in calls[1]['messages']))
        fixed_data = json.loads(calls[1]['messages'][-1]['content'])

        def string_values(value):
            if isinstance(value, dict):
                return [item for child in value.values() for item in string_values(child)]
            if isinstance(value, list):
                return [item for child in value for item in string_values(child)]
            return [value] if isinstance(value, str) else []

        self.assertIn(MOVE, string_values(fixed_data), 'Reviewed prose is quoted data, not a new instruction.')
        for call in calls:
            self.assertLessEqual(sum(len(message['content'].encode('utf-8'))
                                     for message in call['messages']), engine.GM_CONTEXT_BYTE_LIMIT)

    def test_state_repair_cannot_replace_fixed_narration(self):
        replacement = state_reply({'location': DESTINATION, 'evidence': {'location': MOVE_QUOTE}})
        replacement['narration'] = 'A different story is substituted.'
        calls = self.assert_rejected([full_reply(MOVE, {'location': RAW_PATCH_MARKER}), replacement],
                                     action='I walk to Beacon Archive.')
        self.assertEqual(len(calls), 2)

    def test_state_repair_cannot_add_unobserved_inventory(self):
        calls = self.assert_rejected([
            full_reply(MOVE, {'location': RAW_PATCH_MARKER}),
            state_reply({'location': DESTINATION, 'evidence': {'location': MOVE_QUOTE},
                         'inventory_add': ['crystal crown']})], action='I walk to Beacon Archive.')
        self.assertEqual(len(calls), 2)

    def test_empty_state_repair_cannot_hide_a_body_mentioned_conflicting_scene_change(self):
        contradictory = HEADER + '\n\n' + MOVE_QUOTE
        before = self.snapshot()
        chat, calls, _ = self.script(
            full_reply(contradictory, {'location': DESTINATION,
                                       'evidence': {'location': RAW_PATCH_MARKER}}), state_reply({}))
        with self.assertRaisesRegex(ValueError, 'state correction omitted unresolved change: location'):
            engine.play_turn(self.con, self.cid, 'I walk to Beacon Archive.',
                             model='ministral-3:14b', chat=chat)
        self.assertEqual(len(calls), 2)
        self.assertEqual(calls[1]['schema'], engine.GM_STATE_RESPONSE_SCHEMA)
        self.assertNotIn(RAW_PATCH_MARKER, json.dumps(calls[1]['messages']))
        self.assertEqual(self.snapshot(), before)

    def test_empty_state_repair_cannot_hide_a_body_mentioned_inventory_change(self):
        quote = 'The clerk gives you a copper token.'
        before = self.snapshot()
        chat, calls, _ = self.script(
            full_reply(HEADER + '\n\n' + quote, {'inventory_add': ['copper token'],
                                                 'evidence': {'inventory_add': RAW_PATCH_MARKER}}),
            state_reply({}))
        with self.assertRaisesRegex(ValueError, 'state correction omitted unresolved change: inventory_add'):
            engine.play_turn(self.con, self.cid, 'I accept the copper token.',
                             model='ministral-3:14b', chat=chat)
        self.assertEqual(len(calls), 2)
        self.assertNotIn(RAW_PATCH_MARKER, json.dumps(calls[1]['messages']))
        self.assertEqual(self.snapshot(), before)

    def test_state_repair_cannot_drop_an_already_supported_inventory_sibling(self):
        quote = 'The keeper gives you a copper token.'
        narration = MOVE + '\n\n' + quote
        before = self.snapshot()
        chat, calls, _ = self.script(
            full_reply(narration, {
                'location': DESTINATION, 'inventory_add': ['copper token'],
                'evidence': {'location': RAW_PATCH_MARKER, 'inventory_add': quote}}),
            state_reply({'location': DESTINATION, 'evidence': {'location': MOVE_QUOTE}}))
        with self.assertRaisesRegex(ValueError, 'state correction omitted unresolved change: inventory_add'):
            engine.play_turn(self.con, self.cid, 'I walk to Beacon Archive and accept the copper token.',
                             model='ministral-3:14b', chat=chat)
        self.assertEqual(len(calls), 2)
        self.assertNotIn(RAW_PATCH_MARKER, json.dumps(calls[1]['messages']))
        self.assertEqual(self.snapshot(), before)

    def test_state_repair_preserves_and_grounds_both_scene_and_inventory_changes(self):
        quote = 'The keeper gives you a copper token.'
        narration = MOVE + '\n\n' + quote
        result, calls = self.play([
            full_reply(narration, {
                'location': DESTINATION, 'inventory_add': ['copper token'],
                'evidence': {'location': RAW_PATCH_MARKER, 'inventory_add': RAW_PATCH_MARKER}}),
            state_reply({'location': DESTINATION, 'inventory_add': ['copper token'],
                         'evidence': {'location': MOVE_QUOTE, 'inventory_add': quote}})],
            action='I walk to Beacon Archive and accept the copper token.')
        self.assertEqual(len(calls), 2)
        self.assertEqual(result['narration'], narration)
        self.assert_scene(result, {**LABELS, 'location': DESTINATION})
        self.assertEqual(result['state']['inventory'], ['iron key', 'copper token'])
        self.assertEqual(result['state']['scene_memory'], self.prior_memory)
        self.assertNotIn(RAW_PATCH_MARKER, json.dumps(calls[1]['messages']))

    def test_state_repair_omits_unobserved_optional_memory_without_losing_previous_memory(self):
        invented = 'The council has replaced every bridge guard.'
        result, calls = self.play([
            full_reply(MOVE, {'location': RAW_PATCH_MARKER}),
            state_reply({'location': DESTINATION, 'evidence': {'location': MOVE_QUOTE},
                         'scene_memory': {'events': [{'text': invented, 'evidence': invented}]}})],
            action='I walk to Beacon Archive.')
        self.assertEqual(len(calls), 2)
        self.assertEqual(result['state']['scene_memory'], self.prior_memory)
        self.assertNotIn(invented, json.dumps(result['state']))

    def test_narrative_player_action_requires_narrative_rewrite_not_state_repair(self):
        unsafe = FRESH + '\n\nTamsin decides to open the sealed case.'
        result, calls = self.play([full_reply(unsafe, {'location': RAW_PATCH_MARKER}), full_reply(OTHER)])
        self.assertEqual(len(calls), 2)
        self.assertEqual(calls[1]['schema'], engine.GM_RESPONSE_SCHEMA)
        self.assertNotIn('Tamsin decides to open', json.dumps(calls[1]['messages']))
        self.assertNotIn(RAW_PATCH_MARKER, json.dumps(calls[1]['messages']))
        self.assertEqual(result['narration'], OTHER)

    def test_repeated_narration_requires_rewrite_not_state_repair(self):
        result, calls = self.play([full_reply(INTRO, {'location': RAW_PATCH_MARKER}), full_reply(FRESH)])
        self.assertEqual(len(calls), 2)
        self.assertEqual(calls[1]['schema'], engine.GM_RESPONSE_SCHEMA)
        self.assertIn('repeat', calls[1]['messages'][-1]['content'].casefold())
        self.assertEqual(result['narration'], FRESH)

    def test_bad_metadata_never_masks_repeated_or_unauthorized_narration(self):
        for narration in (INTRO, FRESH + '\n\nYou walk to the river.'):
            with self.subTest(kind='repeat' if narration == INTRO else 'player action'):
                calls = self.assert_rejected([full_reply(narration, {'location': RAW_PATCH_MARKER})] * 2)
                self.assertEqual(calls[1]['schema'], engine.GM_RESPONSE_SCHEMA)

    def test_player_behavior_embedded_in_location_metadata_is_not_silently_dropped(self):
        unsafe = 'Tamsin decides to accept the bargain'
        self.assert_rejected([full_reply(FRESH, {'location': unsafe}), state_reply({'location': unsafe})])

    def test_invalid_inventory_proposals_are_never_discarded_with_location_noise(self):
        for change in ({'inventory_add': ['ruby seal']}, {'inventory_remove': ['iron key']}):
            with self.subTest(change=change):
                calls = self.assert_rejected([
                    full_reply(FRESH, {'location': RAW_PATCH_MARKER, **change}), state_reply(change)])
                self.assertEqual(len(calls), 2)
                self.assertEqual(calls[1]['schema'], engine.GM_STATE_RESPONSE_SCHEMA)

    def test_supported_inventory_survives_discarded_location_noise(self):
        quote = 'The clerk gives you a copper token.'
        result, calls = self.play([full_reply(HEADER + '\n\n' + quote, {
            'location': RAW_PATCH_MARKER, 'inventory_add': ['copper token'],
            'evidence': {'inventory_add': quote}})], action='I accept the copper token.')
        self.assertEqual(len(calls), 1)
        self.assertEqual(result['state']['inventory'], ['iron key', 'copper token'])

    def test_failed_state_repair_preserves_every_database_row(self):
        self.assert_rejected([full_reply(MOVE, {'location': RAW_PATCH_MARKER}),
                              state_reply({'location': 'Unseen Palace'})],
                             action='I walk to Beacon Archive.')

    def test_failed_retry_state_repair_preserves_feedback_and_all_turns(self):
        first, _ = self.play([full_reply(FRESH)])
        target = first['messages'][-1]['id']
        self.play([full_reply(OTHER)], action='I wait.')
        calls = self.assert_rejected([
            full_reply(MOVE, {'location': RAW_PATCH_MARKER}), state_reply({})], retry_id=target)
        self.assertEqual(len(calls), 2)

    def test_repair_uses_only_remaining_shared_time_budget(self):
        chat, calls, _ = self.script(full_reply(MOVE, {'location': RAW_PATCH_MARKER}),
                                    state_reply({'location': DESTINATION,
                                                 'evidence': {'location': MOVE_QUOTE}}))
        with patch('engine.time.monotonic', side_effect=[100, 100, 170]):
            result = engine.play_turn(self.con, self.cid, 'I walk to Beacon Archive.',
                                      model='ministral-3:14b', chat=chat)
        self.assertEqual([call['timeout'] for call in calls], [70, 25])
        self.assertEqual(result['narration'], MOVE)

    def test_exhausted_shared_budget_never_starts_state_repair(self):
        before = self.snapshot()
        chat, calls, _ = self.script(full_reply(MOVE, {'location': RAW_PATCH_MARKER}))
        with patch('engine.time.monotonic', side_effect=[100, 100, 196]):
            with self.assertRaisesRegex(RuntimeError, '95-second turn budget'):
                engine.play_turn(self.con, self.cid, 'I walk to Beacon Archive.',
                                 model='ministral-3:14b', chat=chat)
        self.assertEqual(len(calls), 1)
        self.assertEqual(self.snapshot(), before)

    def test_malformed_state_envelope_cannot_trigger_a_third_call(self):
        calls = self.assert_rejected([full_reply(MOVE, {'location': RAW_PATCH_MARKER}),
                                      '{"state_updates":'], action='I walk to Beacon Archive.')
        self.assertEqual(len(calls), 2)

    def test_state_repair_cannot_truncate_prose_to_fit_its_utf8_context_budget(self):
        long_prose = '[Beacon Archive - Valewick - Dusk]\n\n' + MOVE_QUOTE + ' ' + '\u754c' * 5700
        before = self.snapshot()
        chat, calls, _ = self.script(full_reply(long_prose, {'location': RAW_PATCH_MARKER}))
        with self.assertRaises(ValueError):
            engine.play_turn(self.con, self.cid, 'I walk to Beacon Archive.',
                             model='ministral-3:14b', chat=chat)
        self.assertEqual(len(calls), 1, 'Oversized fixed prose must fail before the extraction call.')
        self.assertEqual(self.snapshot(), before)

    def test_ollama_request_forwards_state_only_schema_and_validates_capped_completion_against_it(self):
        content = json.dumps(state_reply({}))
        response = io.BytesIO(json.dumps({'message': {'content': content},
                                          'done_reason': 'length', 'eval_count': 1050}).encode())
        with patch('engine.urllib.request.urlopen', return_value=response) as request:
            output = engine.ollama_chat([], 'ministral-3:14b', response_schema=engine.GM_STATE_RESPONSE_SCHEMA)
        self.assertEqual(output, content)
        sent = json.loads(request.call_args.args[0].data)
        self.assertEqual(sent['format'], engine.GM_STATE_RESPONSE_SCHEMA)
        self.assertNotIn('narration', sent['format']['properties'])
        self.assertEqual(sent['options']['num_predict'], 1050)

    def test_capped_state_completion_with_narration_is_not_a_valid_state_repair(self):
        response = io.BytesIO(json.dumps({
            'message': {'content': json.dumps(full_reply(FRESH))},
            'done_reason': 'length', 'eval_count': 1050}).encode())
        with patch('engine.urllib.request.urlopen', return_value=response):
            with self.assertRaises(engine.OllamaOutputLimitError):
                engine.ollama_chat([], 'ministral-3:14b', response_schema=engine.GM_STATE_RESPONSE_SCHEMA)


if __name__ == '__main__':
    unittest.main()
