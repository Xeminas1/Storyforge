"""Optional extracted notes cannot veto sound fiction or become trusted state.

All campaigns and dialogue are invented fixtures. These checks exercise the
production turn boundary; they do not contact a model or read personal saves.
"""
import copy
import io
import json
import logging
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import engine


LABELS = {'location': 'Ticket Hall', 'parent_area': 'Frostweir', 'time_of_day': 'Noon'}
HEADER = '[Ticket Hall - Frostweir - Noon]'
OBSERVED = 'Clerk Neral fastens the brass drawer.'
OPPORTUNITY = 'An unopened parcel awaits its recipient.'
BODY = (OBSERVED + ' ' + OPPORTUNITY + ' '
        'A caretaker replaces a cracked lamp beside the luggage scales. '
        'Outside, a delivery cart rattles over the cobbled bridge.')
FRESH = HEADER + '\n\n' + BODY
INTRO = (HEADER + '\n\n'
         'A porter counts empty baskets beneath the station clock. '
         'Two messengers shelter from the rain under a blue canvas awning. '
         'Steam rises from a dented kettle on the watchman\'s stove.')
DESTINATION = 'Glass Workshop'
TRAVEL_QUOTE = 'Inside Glass Workshop, a craftswoman sorts pieces of green glass.'
TRAVEL = '[Glass Workshop - Frostweir - Noon]\n\n' + TRAVEL_QUOTE
OLD_THREAD = 'The western lock needs inspection.'
BAD_MARKER = 'UNTRUSTED_OPTIONAL_NOTE_859'


def fact(text=OBSERVED, evidence=None):
    return {'text': text, 'evidence': text if evidence is None else evidence}


class OptionalExtractionBoundaryTests(unittest.TestCase):
    def setUp(self):
        self.directory = self.enterContext(tempfile.TemporaryDirectory())
        self.old_memory = {
            'summary': 'A porter guards the western luggage room.',
            'npcs': [{'name': 'Porter Hen', 'facts': ['Porter Hen guards the luggage room.']}],
            'events': ['The rain began before noon.'],
            'open_threads': [OLD_THREAD],
        }

    def campaign(self):
        con = engine.open_db(Path(self.directory) / (engine.new_id() + '.db'))
        self.addCleanup(con.close)
        world = engine.make_world(con, {'title': 'The Frostweir Carriers',
                                       'description': 'A story about couriers and glassworkers.'})
        campaign = engine.new_campaign(con, {
            'world_id': world['id'], 'pc_name': 'Lysa', 'aliases': 'Ash Sparrow',
            'pronouns': 'she/her', 'species': 'Human'})
        state = copy.deepcopy(campaign['state'])
        state.update(LABELS)
        state.update(inventory=['tin whistle'], journal=['A clock stopped at noon.'],
                     scene_memory=copy.deepcopy(self.old_memory))
        with con:
            con.execute('UPDATE campaigns SET state_json=? WHERE id=?',
                        (json.dumps(state), campaign['id']))
            first = con.execute(
                'INSERT INTO messages (campaign_id,role,content,created_at) VALUES (?,?,?,?)',
                (campaign['id'], 'gm', INTRO, engine.now())).lastrowid
            con.execute('INSERT INTO turn_checkpoints VALUES (?,?,?,?)',
                        (first, json.dumps(state), json.dumps(state), '__START__'))
        return con, campaign['id']

    def script(self, *responses):
        calls = []

        def chat(messages, model, *, timeout=None, response_schema=None):
            calls.append({'messages': copy.deepcopy(messages), 'schema': copy.deepcopy(response_schema)})
            self.assertLessEqual(len(calls), 2)
            response = responses[min(len(calls) - 1, len(responses) - 1)]
            return response if isinstance(response, str) else json.dumps(response)

        chat.supports_timeout = True
        chat.supports_response_schema = True
        chat.requires_state_evidence = True
        return chat, calls

    def play(self, updates, *, narration=FRESH, action='I listen.'):
        con, cid = self.campaign()
        original = copy.deepcopy(updates)
        chat, calls = self.script({'narration': narration, 'state_updates': updates})
        result = engine.play_turn(con, cid, action, model='ministral-3:14b', chat=chat)
        self.assertEqual(len(calls), 1, 'Disposable notes must not request replacement fiction.')
        self.assertEqual(updates, original)
        self.assertEqual(result['narration'], narration)
        self.assertEqual(engine.get_campaign(con, cid)['state'], result['state'])
        self.assertEqual(sum(m['role'] == 'player' and m['content'] == action
                             for m in result['messages']), 1)
        return result

    def assert_old_notes(self, result):
        self.assertEqual(result['state']['scene_memory'], self.old_memory)
        self.assertEqual(result['state']['journal'], ['A clock stopped at noon.'])

    def assert_rejected(self, updates, *, narration=FRESH, action='I listen.'):
        con, cid = self.campaign()
        before = list(con.iterdump())
        chat, calls = self.script({'narration': narration, 'state_updates': updates})
        with self.assertRaises((ValueError, RuntimeError)) as caught:
            engine.play_turn(con, cid, action, model='ministral-3:14b', chat=chat)
        self.assertEqual(list(con.iterdump()), before)
        self.assertEqual(len(calls), 2)
        return caught.exception, calls

    def test_malformed_journal_containers_do_not_veto_sound_prose(self):
        for value in (None, True, 7, ['a note'], {'text': BAD_MARKER}):
            with self.subTest(value=value):
                self.assert_old_notes(self.play({'journal_entry': value}))

    def test_malformed_memory_containers_leave_existing_memory_intact(self):
        for value in (None, False, 17, BAD_MARKER, [fact()]):
            with self.subTest(value=value):
                self.assert_old_notes(self.play({'scene_memory': value}))

    def test_malformed_summary_does_not_remove_a_valid_event_sibling(self):
        for value in (None, BAD_MARKER, [], 17, {'text': OBSERVED},
                      {'text': 17, 'evidence': OBSERVED}):
            with self.subTest(value=value):
                result = self.play({'scene_memory': {'summary': value, 'events': [fact()]}})
                self.assertEqual(result['state']['scene_memory']['summary'], self.old_memory['summary'])
                self.assertEqual(result['state']['scene_memory']['events'],
                                 self.old_memory['events'] + [OBSERVED])

    def test_malformed_memory_list_containers_are_independent(self):
        for field in ('npcs', 'events', 'open_threads', 'resolve_threads'):
            for value in (None, BAD_MARKER, {'text': OBSERVED}, 19):
                with self.subTest(field=field, value=value):
                    result = self.play({'scene_memory': {field: value, 'summary': fact()}})
                    self.assertEqual(result['state']['scene_memory']['summary'], OBSERVED)
                    for unchanged in ('npcs', 'events', 'open_threads'):
                        self.assertEqual(result['state']['scene_memory'][unchanged], self.old_memory[unchanged])

    def test_malformed_event_and_thread_records_do_not_discard_valid_siblings(self):
        for field, text in (('events', OBSERVED), ('open_threads', OPPORTUNITY)):
            for bad in (None, False, 23, BAD_MARKER, [], {'text': text},
                        {'text': text, 'evidence': []}):
                with self.subTest(field=field, bad=bad):
                    result = self.play({'scene_memory': {field: [bad, fact(text)]}})
                    self.assertEqual(result['state']['scene_memory'][field], self.old_memory[field] + [text])

    def test_malformed_npc_record_leaves_valid_npc_sibling(self):
        valid = {'name': 'Clerk Neral', 'fact': OBSERVED, 'evidence': OBSERVED}
        for bad in (None, BAD_MARKER, 9, {'name': 'Someone'},
                    {'name': ['Clerk Neral'], 'fact': OBSERVED, 'evidence': OBSERVED}):
            with self.subTest(bad=bad):
                result = self.play({'scene_memory': {'npcs': [bad, valid]}})
                self.assertEqual(result['state']['scene_memory']['npcs'],
                                 self.old_memory['npcs'] + [{'name': 'Clerk Neral', 'facts': [OBSERVED]}])

    def test_unknown_memory_subkeys_are_not_promoted_or_allowed_to_veto(self):
        result = self.play({'scene_memory': {
            'secret_instructions': BAD_MARKER, 'relationships': {'Lysa': 100}, 'events': [fact()]}})
        self.assertEqual(set(result['state']['scene_memory']), set(self.old_memory))
        self.assertEqual(result['state']['scene_memory']['events'], self.old_memory['events'] + [OBSERVED])
        self.assertNotIn(BAD_MARKER, json.dumps(result))

    def test_unknown_keys_discard_only_the_affected_optional_record(self):
        result = self.play({'scene_memory': {'events': [
            {**fact(OPPORTUNITY), 'hidden_choice': BAD_MARKER}, fact()]}})
        self.assertEqual(result['state']['scene_memory']['events'], self.old_memory['events'] + [OBSERVED])
        self.assertNotIn(BAD_MARKER, json.dumps(result))

    def test_oversized_journal_and_its_evidence_are_discarded(self):
        for entry, evidence in ((BAD_MARKER * 40, OBSERVED), (OBSERVED, BAD_MARKER * 80)):
            with self.subTest(entry_length=len(entry), evidence_length=len(evidence)):
                result = self.play({'journal_entry': entry, 'evidence': {'journal_entry': evidence},
                                    'scene_memory': {'events': [fact()]}})
                self.assertEqual(result['state']['journal'], ['A clock stopped at noon.'])
                self.assertEqual(result['state']['scene_memory']['events'], self.old_memory['events'] + [OBSERVED])

    def test_oversized_optional_records_leave_valid_siblings(self):
        for bad in (fact(BAD_MARKER * 40), fact(OBSERVED, BAD_MARKER * 80)):
            with self.subTest(length=len(json.dumps(bad))):
                result = self.play({'scene_memory': {'events': [bad, fact()]}})
                self.assertEqual(result['state']['scene_memory']['events'], self.old_memory['events'] + [OBSERVED])

    def test_bad_journal_evidence_cannot_crowd_out_supported_real_travel(self):
        for bad in (None, [], {'quote': BAD_MARKER}, 12):
            with self.subTest(bad=bad):
                result = self.play({'location': DESTINATION, 'journal_entry': OBSERVED,
                                    'evidence': {'location': TRAVEL_QUOTE, 'journal_entry': bad}},
                                   narration=TRAVEL, action='I walk to Glass Workshop.')
                self.assertEqual(result['state']['location'], DESTINATION)
                self.assert_old_notes(result)

    def test_supported_inventory_change_survives_invalid_optional_notes(self):
        acquisition = "A silver thimble rests in Lysa's open palm."
        result = self.play({'inventory_add': ['silver thimble'],
                            'evidence': {'inventory_add': acquisition},
                            'journal_entry': [BAD_MARKER],
                            'scene_memory': {'events': [None, fact()]}},
                           narration=FRESH + '\n\n' + acquisition,
                           action='I take the silver thimble.')
        self.assertEqual(result['state']['inventory'], ['tin whistle', 'silver thimble'])
        self.assertEqual(result['state']['scene_memory']['events'], self.old_memory['events'] + [OBSERVED])
        self.assertNotIn(BAD_MARKER, json.dumps(result))

    def test_player_inventions_in_journal_are_discarded_without_weakening_prose_rules(self):
        for entry in ('Lysa decides to open the parcel.', 'Lysa feels relieved.',
                      'Lysa says, "Take the entire shipment."', 'Ash Sparrow raises a hand.'):
            with self.subTest(entry=entry):
                result = self.play({'journal_entry': entry, 'evidence': {'journal_entry': entry}})
                self.assert_old_notes(result)
                self.assertNotIn(entry, json.dumps(result))

    def test_player_inventions_are_removed_individually_from_optional_memory(self):
        for unsafe in ('Lysa decides to accept the job.', 'Lysa remembers the old pact.',
                       'Lysa says, "I accept the job."', 'Ash Sparrow raises a hand.'):
            for field in ('summary', 'events', 'open_threads'):
                with self.subTest(unsafe=unsafe, field=field):
                    memory = {field: fact(unsafe) if field == 'summary' else [fact(unsafe)]}
                    if field != 'events':
                        memory['events'] = [fact()]
                    else:
                        memory[field].append(fact())
                    result = self.play({'scene_memory': memory})
                    self.assertEqual(result['state']['scene_memory']['summary'], self.old_memory['summary'])
                    self.assertEqual(result['state']['scene_memory']['events'], self.old_memory['events'] + [OBSERVED])
                    self.assertNotIn(unsafe, json.dumps(result))

    def test_player_identity_and_alias_cannot_become_cached_npcs(self):
        for name in ('Lysa', 'Ash Sparrow', 'you', 'the player'):
            with self.subTest(name=name):
                result = self.play({'scene_memory': {'npcs': [
                    {'name': name, 'fact': BAD_MARKER, 'evidence': BAD_MARKER}], 'events': [fact()]}})
                self.assertEqual(result['state']['scene_memory']['npcs'], self.old_memory['npcs'])
                self.assertEqual(result['state']['scene_memory']['events'], self.old_memory['events'] + [OBSERVED])

    def test_nonexistent_thread_resolution_is_discarded_and_existing_threads_survive(self):
        result = self.play({'scene_memory': {'resolve_threads': [fact(OPPORTUNITY)], 'events': [fact()]}})
        self.assertEqual(result['state']['scene_memory']['open_threads'], self.old_memory['open_threads'])
        self.assertEqual(result['state']['scene_memory']['events'], self.old_memory['events'] + [OBSERVED])

    def test_valid_resolution_survives_beside_invalid_resolution(self):
        resolution = 'The inspector crosses out "' + OLD_THREAD + '" after examining the lock.'
        result = self.play({'scene_memory': {'resolve_threads': [
            fact(OPPORTUNITY), fact(OLD_THREAD, resolution)]}}, narration=FRESH + '\n\n' + resolution)
        self.assertEqual(result['state']['scene_memory']['open_threads'], [])
        self.assertEqual(result['state']['scene_memory']['events'], self.old_memory['events'])

    def test_complete_invalid_optional_proposal_is_retained_only_in_rejection_diagnostics(self):
        updates = {'journal_entry': {'untrusted': BAD_MARKER},
                   'scene_memory': {'events': [None, {'text': BAD_MARKER}], 'unknown_cache': [BAD_MARKER]}}
        unsafe = HEADER + '\n\nLysa decides to steal the parcel.'
        exc, calls = self.assert_rejected(updates, narration=unsafe)
        self.assertIsInstance(exc, engine.GMReplyRejected)
        for attempt in exc.diagnostics['attempts']:
            self.assertEqual(json.loads(attempt['state_updates_json']), updates)
        self.assertNotIn(BAD_MARKER, json.dumps(calls[1]['messages']))
        self.assertNotIn(BAD_MARKER, str(exc))

    def test_optional_notes_do_not_enter_success_payload_or_plain_logs(self):
        output = io.StringIO()
        handler = logging.StreamHandler(output)
        logger = logging.getLogger('engine.gm.validation')
        old_level = logger.level
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
        try:
            result = self.play({'journal_entry': BAD_MARKER,
                                'scene_memory': {'events': [fact(BAD_MARKER), fact()]}})
        finally:
            logger.removeHandler(handler)
            logger.setLevel(old_level)
        self.assertNotIn(BAD_MARKER, json.dumps(result) + output.getvalue())
        self.assertEqual(result['state']['scene_memory']['events'], self.old_memory['events'] + [OBSERVED])

    def test_bad_narration_is_still_rejected_with_malformed_optional_data(self):
        updates = {'journal_entry': None, 'scene_memory': ['an invalid cache']}
        for narration in (HEADER + '\n\nLysa decides to board the coach.', INTRO):
            with self.subTest(narration=narration):
                self.assert_rejected(updates, narration=narration)

    def test_real_travel_and_inventory_cannot_be_erased_by_optional_projection(self):
        for narration, updates, action in (
            (TRAVEL, {'location': DESTINATION}, 'I walk to Glass Workshop.'),
            (FRESH, {'inventory_add': ['amber ring']}, 'I listen.'),
            (FRESH, {'inventory_remove': ['tin whistle']}, 'I listen.'),
        ):
            with self.subTest(updates=updates):
                combined = {**updates, 'scene_memory': {'events': [None, fact(BAD_MARKER)]}}
                self.assert_rejected(combined, narration=narration, action=action)

    def test_root_and_critical_unknown_fields_and_types_stay_strict(self):
        for updates in ({'location': []}, {'inventory_add': 'ring'}, {'inventory_remove': [17]},
                        {'hidden_transition': BAD_MARKER}, {'evidence': {'unknown_critical': BAD_MARKER}},
                        {'evidence': []}):
            with self.subTest(updates=updates):
                with self.assertRaises(ValueError):
                    engine.parse_gm_response(json.dumps({'narration': FRESH, 'state_updates': updates}))
        with self.assertRaises(ValueError):
            engine.parse_gm_response(json.dumps({'narration': FRESH, 'state_updates': {}, 'hidden': BAD_MARKER}))

    def test_state_only_parser_preserves_the_original_optional_proposal(self):
        for updates in ({'journal_entry': [BAD_MARKER]},
                        {'scene_memory': {'events': [None, fact()], 'unknown_cache': BAD_MARKER}}):
            with self.subTest(updates=updates):
                raw = json.dumps({'state_updates': updates})
                self.assertEqual(engine._parse_gm_state_response(raw), updates)

    def test_state_only_correction_uses_same_independent_optional_boundary(self):
        con, cid = self.campaign()
        chat, calls = self.script(
            {'narration': TRAVEL, 'state_updates': {'location': DESTINATION}},
            {'state_updates': {'location': DESTINATION, 'evidence': {'location': TRAVEL_QUOTE},
                               'journal_entry': {'bad': BAD_MARKER},
                               'scene_memory': {'events': [None, fact(TRAVEL_QUOTE)]}}})
        result = engine.play_turn(con, cid, 'I walk to Glass Workshop.', model='ministral-3:14b', chat=chat)
        self.assertEqual(len(calls), 2)
        self.assertEqual(result['narration'], TRAVEL)
        self.assertEqual(result['state']['location'], DESTINATION)
        self.assertEqual(result['state']['journal'], ['A clock stopped at noon.'])
        self.assertEqual(result['state']['scene_memory']['events'], self.old_memory['events'] + [TRAVEL_QUOTE])
        self.assertNotIn(BAD_MARKER, json.dumps(result))

    def test_failed_state_only_correction_keeps_original_optional_proposal_in_diagnostics(self):
        con, cid = self.campaign()
        before = list(con.iterdump())
        last_updates = {'location': DESTINATION, 'journal_entry': {'untrusted': BAD_MARKER},
                        'scene_memory': [None, BAD_MARKER]}
        chat, calls = self.script(
            {'narration': TRAVEL, 'state_updates': {'location': DESTINATION}},
            {'state_updates': last_updates})
        with self.assertRaises(engine.GMReplyRejected) as caught:
            engine.play_turn(con, cid, 'I walk to Glass Workshop.', model='ministral-3:14b', chat=chat)
        self.assertEqual(len(calls), 2)
        self.assertEqual(list(con.iterdump()), before)
        last = caught.exception.diagnostics['attempts'][-1]
        self.assertEqual(last['phase'], 'state_extraction')
        self.assertEqual(json.loads(last['state_updates_json']), last_updates)
        self.assertNotIn(BAD_MARKER, str(caught.exception))

    def test_complete_json_at_output_cap_uses_the_same_optional_boundary(self):
        envelopes = (
            (engine.GM_RESPONSE_SCHEMA, {'narration': FRESH, 'state_updates': {'scene_memory': [BAD_MARKER]}}),
            (getattr(engine, 'GM_STATE_RESPONSE_SCHEMA', {}), {'state_updates': {'journal_entry': [BAD_MARKER]}}),
        )
        for schema, envelope in envelopes:
            with self.subTest(envelope=envelope):
                content = json.dumps(envelope)
                response = io.BytesIO(json.dumps({'message': {'content': content},
                                                   'done_reason': 'length', 'eval_count': 1050}).encode())
                with patch('engine.urllib.request.urlopen', return_value=response):
                    self.assertEqual(engine.ollama_chat([], 'ministral-3:14b', response_schema=schema), content)

    def test_torn_or_wrapped_output_cap_json_is_never_repaired_locally(self):
        complete = json.dumps({'narration': FRESH, 'state_updates': {'scene_memory': [BAD_MARKER]}})
        for content in (complete[:-1], complete + ' trailing prose', '```json\n' + complete + '\n```'):
            with self.subTest(content=content):
                response = io.BytesIO(json.dumps({'message': {'content': content},
                                                   'done_reason': 'length'}).encode())
                with patch('engine.urllib.request.urlopen', return_value=response):
                    with self.assertRaises(engine.OllamaOutputLimitError):
                        engine.ollama_chat([], 'ministral-3:14b')


if __name__ == '__main__':
    unittest.main()
