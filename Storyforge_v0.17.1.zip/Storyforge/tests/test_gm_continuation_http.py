"""Synthetic continuation regressions through HTTP, SQLite and Ollama's adapter.

These scripted replies test validation and transactions, not live model quality.
"""
from contextlib import closing
import json
import unittest

import engine
import test_gm_http as gm_http


HEADER = '[Willow Quay - Northbank - Dawn]'
SCENE_SENTENCES = (
    'At Dawn, Willow Quay in Northbank lies beneath a pale ribbon of river mist, '
    'and the weathered dockkeeper checks a stack of copper cargo seals beside the warehouse doors.',
    'A pair of apprentices wrestles an enormous basket of wriggling silver fish across '
    'the wooden landing while the baker counts seven sacks of flour beside a crooked yellow cart.',
    'Beyond the empty mooring posts, a patched green ferry drifts against the current '
    'under the patient guidance of an elderly pilot with a long ash pole.',
)
SCENE = HEADER + '\n\n' + ' '.join(SCENE_SENTENCES)
FRESH = (HEADER + '\n\n'
         'The dockkeeper breaks a wax seal and discovers a small iron key inside the folded manifest. '
         'A bell sounds twice from the warehouse roof. "That is not our cargo mark," the dockkeeper '
         'says, showing the pilot a circle stamped beneath the key.')
ACTION = 'I watch the dockkeeper.'


class GmContinuationHttpTests(unittest.TestCase):
    # Reuse the real local HTTP fixture without inheriting its test methods.
    start_server = gm_http.GameMasterHttpTests.start_server
    post = gm_http.GameMasterHttpTests.post
    dump = gm_http.GameMasterHttpTests.dump

    def setUp(self):
        gm_http.GameMasterHttpTests.setUp(self)
        with closing(engine.open_db(self.path)) as con:
            world = engine.make_world(con, {
                'title': 'Willow Riverlands',
                'description': 'A river trading town. Begin at Willow Quay in Northbank at Dawn.'})
            campaign = engine.new_campaign(con, {
                'world_id': world['id'], 'pc_name': 'Mira', 'species': 'High Elf',
                'pronouns': 'she/her', 'aliases': 'Lady Willow'})
            self.cid = campaign['id']
            self.sparse = campaign['state']
            self.seed_id = con.execute(
                'INSERT INTO messages (campaign_id,role,content,created_at) VALUES (?,?,?,?)',
                (self.cid, 'gm', SCENE, engine.now())).lastrowid
            con.execute('INSERT INTO turn_checkpoints VALUES (?,?,?,?)', (
                self.seed_id, json.dumps(self.sparse), json.dumps(self.sparse), '__START__'))
            con.commit()

    def assert_scene(self, result):
        self.assertEqual(result['state']['location'], 'Willow Quay')
        self.assertEqual(result['state']['parent_area'], 'Northbank')
        self.assertEqual(result['state']['time_of_day'], 'Dawn')
        self.assertTrue(result['narration'].startswith(HEADER + '\n\n'))

    def test_copied_passage_with_fresh_prefix_and_paragraphs_is_repaired(self):
        copied = (HEADER + '\n\n'
                  'A loose roof slate rattles high above the landing. Beneath a sagging awning, '
                  'two traders argue about the price of an unopened crate of blue glass bottles. '
                  'The northern footbridge has acquired a bright red banner since market day.\n\n'
                  + ' '.join(SCENE_SENTENCES[:2]) + '\n\n'
                  'Farther along the waterfront, three red lamps flicker under a canvas stall '
                  'where a courier has spread a collection of maps and broken brass compasses.')
        self.model.replies = [gm_http.output(copied), gm_http.output(FRESH)]
        result = self.post('/turn', {'action': ACTION, 'model': 'qwen3:8b'})
        self.assertEqual(len(self.model.requests), 2)
        self.assert_scene(result)
        self.assertEqual([message['role'] for message in result['messages']], ['gm', 'player', 'gm'])
        self.assertEqual(result['messages'][0]['content'], SCENE)
        self.assertEqual(result['messages'][1]['content'], ACTION)
        self.assertEqual(result['messages'][-1]['content'], FRESH)
        self.assertTrue(result['messages'][-1]['has_checkpoint'])
        repair = self.model.requests[-1]['messages'][-1]['content']
        self.assertIn('repeats', repair)
        self.assertIn(ACTION, repair)
        self.assertNotIn('loose roof slate', json.dumps(self.model.requests[-1]['messages']))
        with closing(engine.open_db(self.path)) as con:
            checkpoint = con.execute('SELECT state_after FROM turn_checkpoints WHERE gm_message_id=?',
                                     (result['messages'][-1]['id'],)).fetchone()
            self.assertEqual(json.loads(checkpoint['state_after'])['parent_area'], 'Northbank')

    def test_alias_and_name_pronoun_actions_or_expressions_are_repaired_with_profile(self):
        for unsafe in ('Lady Willow pauses beside the railing. She decides to follow the pilot.',
                       'Mira waits beside the quay. Her expression remains defiant.'):
            with self.subTest(unsafe=unsafe):
                self.model.requests.clear()
                self.model.replies = [gm_http.output(HEADER + '\n\n' + unsafe),
                    gm_http.output(HEADER + '\n\nThe dockkeeper opens a shallow drawer. '
                                   'Inside, a compass spins beneath a cracked pane of glass.')]
                # Rewrite the same synthetic opening each time to keep this a single continuation.
                with closing(engine.open_db(self.path)) as con:
                    con.execute('DELETE FROM messages WHERE campaign_id=? AND id>?',
                                (self.cid, self.seed_id))
                    con.execute('UPDATE campaigns SET state_json=? WHERE id=?',
                                (json.dumps(self.sparse), self.cid))
                    con.commit()
                result = self.post('/turn', {'action': ACTION})
                self.assertEqual(len(self.model.requests), 2)
                self.assert_scene(result)
                self.assertNotIn(unsafe, result['narration'])
                system = self.model.requests[0]['messages'][0]['content']
                character = json.loads(system.split('CHARACTER (player-controlled):\n', 1)[1]
                    .split('\nCANONICAL CHARACTER SPELLS & ABILITIES', 1)[0])
                self.assertEqual(character['name'], 'Mira')
                self.assertEqual(character['aliases'], 'Lady Willow')
                self.assertEqual(character['pronouns'], 'she/her')
                self.assertEqual(character['species'], 'High Elf')
                repair = self.model.requests[-1]['messages'][-1]['content']
                self.assertIn('unrequested player', repair)
                self.assertNotIn(unsafe, json.dumps(self.model.requests[-1]['messages']))

    def test_twice_bad_retry_preserves_every_row_checkpoint_and_feedback(self):
        self.model.replies = [gm_http.output(FRESH)]
        original = self.post('/turn', {'action': ACTION})
        target = original['messages'][-1]['id']
        with closing(engine.open_db(self.path)) as con:
            con.execute('INSERT INTO gm_feedback '
                '(campaign_id,message_id,message_role,operation,reason,original_text,created_at) '
                'VALUES (?,?,?,?,?,?,?)',
                (self.cid, self.seed_id, 'gm', 'retry', 'Keep the river scene consistent.', SCENE, engine.now()))
            con.commit()
        before = self.dump()
        self.model.requests.clear()
        bad = HEADER + '\n\nLady Willow pauses beneath the awning. She decides to accept the bargain.'
        self.model.replies = [gm_http.output(bad)] * 2
        result = self.post(f'/messages/{target}/retry',
                           {'feedback': 'Leave Mira\'s decisions to me.'}, expected=400)
        self.assertEqual(len(self.model.requests), 2)
        self.assertIn('Nothing was saved', result['error'])
        self.assertEqual(self.dump(), before)

    def test_player_alias_cannot_be_saved_as_a_gm_controlled_npc(self):
        sentence = "Lady Willow's cloak bears a silver clasp."
        self.model.replies = [gm_http.output(HEADER + '\n\n' + sentence, scene_memory={
            'npcs': [{'name': 'Lady Willow', 'fact': sentence, 'evidence': sentence}]})]

        result = self.post('/turn', {'action': ACTION})

        self.assertEqual(len(self.model.requests), 1)
        self.assert_scene(result)
        self.assertEqual(self.model.requests[0]['format'], engine.GM_RESPONSE_SCHEMA)
        self.assertEqual(result['narration'], HEADER + '\n\n' + sentence)
        self.assertNotIn('scene_memory', result['state'])
        self.assertEqual([m['role'] for m in result['messages']], ['gm', 'player', 'gm'])
        self.assertEqual(result['messages'][-1]['content'], result['narration'])
        with closing(engine.open_db(self.path)) as con:
            self.assertNotIn('scene_memory', engine.get_campaign(con, self.cid)['state'])

    def test_retry_unsafe_existing_reply_recovers_labels_without_duplicate_action(self):
        action = 'I listen.'
        unsafe = ('[Unknown location - Willow Riverlands - Time unspecified]\n\n'
                  'Lady Willow pauses beside the railing. She decides to board the ferry.')
        corrupted = {**self.sparse, 'parent_area': 'Willow Riverlands', 'time_of_day': 'Time unspecified'}
        with closing(engine.open_db(self.path)) as con:
            player_id = con.execute(
                'INSERT INTO messages (campaign_id,role,content,created_at) VALUES (?,?,?,?)',
                (self.cid, 'player', action, engine.now())).lastrowid
            target = con.execute(
                'INSERT INTO messages (campaign_id,role,content,created_at) VALUES (?,?,?,?)',
                (self.cid, 'gm', unsafe, engine.now())).lastrowid
            con.execute('INSERT INTO turn_checkpoints VALUES (?,?,?,?)',
                        (target, json.dumps(self.sparse), json.dumps(corrupted), action))
            con.execute('UPDATE campaigns SET state_json=? WHERE id=?',
                        (json.dumps(corrupted), self.cid))
            con.commit()
        # Generic/unknown heading fields must not erase supported prior labels.
        fresh_body = FRESH.split('\n\n', 1)[1]
        self.model.replies = [gm_http.output(
            '[Unknown location - Willow Riverlands - Time unspecified]\n\n' + fresh_body)]
        result = self.post(f'/messages/{target}/retry', {'feedback': 'Only control the dockkeeper and world.'})
        self.assertEqual(len(self.model.requests), 1)
        self.assert_scene(result)
        self.assertEqual([message['role'] for message in result['messages']], ['gm', 'player', 'gm'])
        self.assertEqual(result['messages'][1]['id'], player_id)
        self.assertEqual(result['messages'][1]['content'], action)
        self.assertNotEqual(result['messages'][-1]['id'], target)
        self.assertNotIn(unsafe, json.dumps(self.model.requests[0]['messages']))
        with closing(engine.open_db(self.path)) as con:
            self.assertIsNone(con.execute('SELECT 1 FROM turn_checkpoints WHERE gm_message_id=?',
                                         (target,)).fetchone())
            replacement = con.execute('SELECT state_after,source_action FROM turn_checkpoints '
                                      'WHERE gm_message_id=?', (result['messages'][-1]['id'],)).fetchone()
            self.assertEqual(replacement['source_action'], action)
            self.assertEqual(json.loads(replacement['state_after'])['location'], 'Willow Quay')
            feedback = con.execute('SELECT original_text FROM gm_feedback WHERE campaign_id=?',
                                   (self.cid,)).fetchall()
            self.assertEqual([row['original_text'] for row in feedback], [unsafe])


if __name__ == '__main__':
    unittest.main()
