"""Synthetic ownership regressions for a nearby NPC's continued quotations.

Private generated replies are deliberately absent. Recognizing a bounded
attribution bridge must not exempt unrelated narration or a new speaker.
"""
import copy
import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import engine


PROFILE = {'aliases': 'Silver Alder', 'pronouns': 'she/her', 'species': 'Human'}
PC = 'Selene'
ACTION = 'I listen to the courier.'
HEADER = '[Fountain Court - Merewatch - Dusk]'
OPENING = 'The courier checks a delivery ledger beside a covered fountain. '
FIRST = 'The eastern gate is closed,'
SECOND = "I'll wait by the fountain. My parcels can stay dry."


def dialogue(text, opener='"', closer='"', marker='*'):
    return marker + opener + text + closer + marker


def continuation(opener='"', closer='"', marker='*'):
    return (OPENING + dialogue(FIRST, opener, closer, marker)
            + ' the courier says, her voice low. '
            + dialogue(SECOND, opener, closer, marker))


class ChainedNpcSpeechTests(unittest.TestCase):
    def findings(self, text, action=ACTION):
        return engine.player_agency_violations(text, PC, action, pc_profile=PROFILE)

    def test_npc_attribution_and_voice_descriptor_connect_literal_quote_families(self):
        for marker in ('', '*', '**'):
            for opener, closer in (('"', '"'), ('“', '”'), ("'", "'"), ('‘', '’')):
                with self.subTest(marker=marker, opener=opener):
                    self.assertEqual(self.findings(continuation(opener, closer, marker)), [])

    def test_plain_attribution_and_inverted_attribution_connect_quotes(self):
        for bridge in (' the courier says. ', ' she says. ', ' says the courier. ',
                       ' he replies, his tone quiet. ', ' they add, their voice low and rough. '):
            with self.subTest(bridge=bridge):
                self.assertEqual(self.findings(dialogue(FIRST) + bridge + dialogue(SECOND)), [])

    def test_attribution_before_first_quote_or_npc_label_owns_adjacent_quotes(self):
        for attribution in ('The courier says, ', 'Courier: '):
            with self.subTest(attribution=attribution):
                self.assertEqual(self.findings(attribution + dialogue(FIRST) + ' ' + dialogue(SECOND)), [])

    def test_same_speaker_can_continue_a_third_adjacent_literal_quote(self):
        self.assertEqual(self.findings(continuation() + ' ' + dialogue('I have another delivery at dawn.')), [])

    def test_contractions_possessives_and_npc_second_person_remain_inside_dialogue(self):
        text = (dialogue("O'Brien's cart is late,", "'", "'", '*')
                + ' the courier says, her voice low. '
                + dialogue("I can't leave my driver's parcels. You raise your hand only for kings, I know.",
                           "'", "'", '*'))
        self.assertEqual(self.findings(text), [])

    def test_new_paragraph_or_line_does_not_inherit_a_speaker(self):
        for gap in ('\n', '\n\n'):
            with self.subTest(gap=repr(gap)):
                text = dialogue(FIRST) + ' the courier says.' + gap + dialogue(SECOND)
                self.assertTrue(self.findings(text))

    def test_intervening_prose_unknown_attribution_or_ambiguous_speaker_breaks_chain(self):
        for bridge in (
            ' the courier says. The watch changes shifts. ',
            ' the courier says. Another messenger steps forward. ',
            ' the courier says. It is your turn to speak. ',
            ' the courier says. Your Thoughts: ',
            ' the courier blorps, her voice low. ',
            ' the courier says. ' + 'A distant bell rings. ' * 8,
        ):
            with self.subTest(bridge=bridge):
                self.assertTrue(self.findings(dialogue(FIRST) + bridge + dialogue(SECOND)))

    def test_player_attribution_and_alias_override_the_npc_chain(self):
        for actor in ('you', PC, 'Silver Alder'):
            for second in (dialogue('I accept the contract.') + ' ' + actor + ' says.',
                           actor + ' says, ' + dialogue('I accept the contract.'),
                           actor + ': ' + dialogue('I accept the contract.')):
                with self.subTest(actor=actor, second=second):
                    self.assertTrue(self.findings(dialogue(FIRST) + ' the courier says. ' + second))

    def test_unknown_new_attribution_cannot_borrow_the_previous_npc_owner(self):
        for attribution in ('you sing.', 'Selene sings.', 'Silver Alder sings.',
                            'she blorps.', 'She blorps.', 'The messenger blorps.'):
            with self.subTest(attribution=attribution):
                text = (dialogue(FIRST) + ' the courier says. '
                        + dialogue('I accept the contract,') + ' ' + attribution)
                self.assertTrue(self.findings(text))

    def test_authorized_player_quote_does_not_own_a_new_unattributed_quote(self):
        text = dialogue('Good evening.') + ' you say. ' + dialogue('I accept the contract.')
        self.assertTrue(self.findings(text, 'I say "Good evening."'))

    def test_unquoted_first_person_and_player_behavior_remain_rejected(self):
        for tail in ('I raise my hand.', '*I raise my hand.*', '**I raise my hand.**',
                     'You raise your hand.', 'Selene accepts the contract.'):
            with self.subTest(tail=tail):
                self.assertTrue(self.findings(continuation() + ' ' + tail))

    def test_player_behavior_between_quotes_is_not_hidden_by_inheritance(self):
        for actor in ('You', PC, 'Silver Alder', 'I'):
            verb = 'raise' if actor in ('You', 'I') else 'raises'
            text = (dialogue(FIRST) + ' the courier says. ' + actor + ' ' + verb
                    + ' a hand. ' + dialogue(SECOND))
            with self.subTest(actor=actor):
                self.assertTrue(self.findings(text))

    def test_malformed_emphasized_boundaries_cannot_swallow_player_behavior(self):
        for opener, closer in (('"', '"'), ('“', '”'), ("'", "'"), ('‘', '’')):
            text = (dialogue(FIRST) + ' the courier says. *' + opener + 'I waited'
                    + closer + 'You choose the bridge beside the porters' + closer + '*')
            with self.subTest(opener=opener):
                self.assertTrue(self.findings(text))
        # A one-letter PC name can resemble the suffix of a contraction.
        text = dialogue(FIRST) + ' the courier says. *‘I waited’D chooses the bridge beside the porters’*'
        self.assertTrue(engine.player_agency_violations(text, 'D', ACTION))


class ChainedNpcSpeechPipelineTests(unittest.TestCase):
    def setUp(self):
        directory = self.enterContext(tempfile.TemporaryDirectory())
        self.db = engine.open_db(Path(directory) / 'synthetic.db')
        self.addCleanup(self.db.close)
        world = engine.make_world(self.db, {'title': 'Merewatch', 'description': 'An original courier-city setting.'})
        campaign = engine.new_campaign(self.db, {'world_id': world['id'], 'pc_name': PC, **PROFILE})
        self.cid = campaign['id']
        state = copy.deepcopy(campaign['state'])
        state.update(location='Fountain Court', parent_area='Merewatch', time_of_day='Dusk')
        with self.db:
            self.db.execute('UPDATE campaigns SET state_json=? WHERE id=?', (json.dumps(state), self.cid))

    def script(self, text):
        calls = []

        def chat(messages, model, *, timeout=None, response_schema=None):
            calls.append(copy.deepcopy(messages))
            self.assertLessEqual(len(calls), 2)
            return json.dumps({'narration': HEADER + '\n\n' + text, 'state_updates': {}})

        chat.supports_timeout = True
        chat.supports_response_schema = True
        chat.requires_state_evidence = True
        return chat, calls

    def test_attributed_npc_continuation_saves_once_with_one_call_and_no_new_pc_facts(self):
        before = engine.get_campaign(self.db, self.cid)['state']
        chat, calls = self.script(continuation("'", "'", '*'))
        result = engine.play_turn(self.db, self.cid, ACTION, chat=chat)
        self.assertEqual(len(calls), 1)
        self.assertEqual(result['narration'], HEADER + '\n\n' + continuation("'", "'", '*'))
        expected = copy.deepcopy(before)
        expected['last_action'] = ACTION
        self.assertEqual(result['state'], expected)
        self.assertEqual([message['role'] for message in result['messages']], ['player', 'gm'])
        self.assertEqual(self.db.execute('SELECT count(*) FROM turn_checkpoints').fetchone()[0], 1)

    def test_chained_npc_speech_does_not_save_invented_player_behavior(self):
        before = list(self.db.iterdump())
        chat, calls = self.script(continuation() + ' You raise your hand.')
        with self.assertRaises(ValueError):
            engine.play_turn(self.db, self.cid, ACTION, chat=chat)
        self.assertEqual(len(calls), 2)
        self.assertEqual(list(self.db.iterdump()), before)


if __name__ == '__main__':
    unittest.main()
