"""Expressive speech verbs must retain ownership of quoted dialogue.

All fixtures are synthetic. Unknown attribution and presentation markup do not
grant the GM permission to invent player words or actions.
"""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import engine


class ExpressiveNpcSpeechTests(unittest.TestCase):
    profile = {'aliases': 'Silver Fox', 'pronouns': 'he/him'}

    def findings(self, narration, action='I wait by the fountain.'):
        return engine.player_agency_violations(
            narration, 'Corin', action, pc_profile=self.profile)

    def test_standard_expressive_npc_speech_after_plain_quotation(self):
        for verb in ('blurts', 'blurted'):
            with self.subTest(verb=verb):
                self.assertEqual(self.findings(
                    '"I lost my map!" the courier ' + verb + '.'), [])

    def test_standard_expressive_npc_speech_after_emphasized_quotation(self):
        for marker in ('*', '**'):
            for opener, closer in (('"', '"'), ('“', '”'), ("'", "'"), ('‘', '’')):
                with self.subTest(marker=marker, opener=opener):
                    self.assertEqual(self.findings(
                        marker + opener + 'I lost my map!' + closer + marker
                        + ' she blurts.'), [])

    def test_nonstandard_expressive_npc_speech_is_still_attributed(self):
        for verb in ('blurps', 'blurped'):
            for marker in ('', '*', '**'):
                with self.subTest(verb=verb, marker=marker):
                    self.assertEqual(self.findings(
                        marker + '“I dropped my compass!”' + marker
                        + ' the courier ' + verb + '.'), [])

    def test_expressive_npc_attribution_before_quotation(self):
        for verb in ('blurts', 'blurted', 'blurps', 'blurped'):
            with self.subTest(verb=verb):
                self.assertEqual(self.findings(
                    'The courier ' + verb + ', *“I lost my map!”*'), [])

    def test_invented_player_speech_remains_rejected(self):
        for actor in ('You', 'Corin', 'Silver Fox'):
            for verb in ('blurts', 'blurted', 'blurps', 'blurped'):
                with self.subTest(actor=actor, verb=verb):
                    self.assertIn('invented player dialogue', self.findings(
                        '*“I pledge my sword.”* ' + actor + ' ' + verb + '.'))

    def test_inverted_player_speech_remains_rejected(self):
        for actor in ('you', 'Corin', 'Silver Fox'):
            for verb in ('blurts', 'blurps'):
                with self.subTest(actor=actor, verb=verb):
                    self.assertIn('invented player dialogue', self.findings(
                        '“I pledge my sword,” ' + verb + ' ' + actor + '.'))

    def test_exact_authored_expressive_player_speech_is_allowed(self):
        for action_verb, narration_verb in (('blurt', 'blurt'), ('blurt', 'blurts'),
                                            ('blurted', 'blurted'), ('blurp', 'blurp'),
                                            ('blurp', 'blurps'), ('blurped', 'blurped')):
            with self.subTest(action_verb=action_verb, narration_verb=narration_verb):
                actor = 'you' if narration_verb in ('blurt', 'blurp') else 'Corin'
                self.assertEqual(self.findings(
                    '*“My map is missing.”* ' + actor + ' ' + narration_verb + '.',
                    'I ' + action_verb + ' "My map is missing."'), [])

    def test_authored_expressive_speech_cannot_gain_additional_words(self):
        for verb in ('blurt', 'blurp'):
            with self.subTest(verb=verb):
                self.assertIn('invented player dialogue', self.findings(
                    'You ' + verb + ', "My map is missing. I pledge my sword."',
                    'I ' + verb + ' "My map is missing."'))

    def test_negated_or_other_actor_speech_does_not_authorize_player_words(self):
        for action in ('I do not blurt "My map is missing."',
                       'I watch the courier blurt "My map is missing."'):
            with self.subTest(action=action):
                self.assertIn('invented player dialogue', self.findings(
                    'You blurt, "My map is missing."', action))

    def test_npc_speech_does_not_hide_outside_player_actions(self):
        for verb in ('blurts', 'blurps'):
            with self.subTest(verb=verb):
                self.assertIn('unrequested player action or thought: raise', self.findings(
                    '*“I lost my map!”* the courier ' + verb
                    + '. You raise your hand.'))

    def test_unquoted_first_person_emphasis_remains_rejected(self):
        for text in ('I raise my hand.', '*I raise my hand.*', '**I raise my hand.**'):
            with self.subTest(text=text):
                self.assertTrue(self.findings(text))

    def test_unknown_attribution_and_unattributed_quotes_remain_rejected(self):
        for text in ('*“I lost my map!”* she blorps.',
                     '“I lost my map!” she blorps.', '*“I lost my map!”*',
                     '“I lost my map!”'):
            with self.subTest(text=text):
                self.assertTrue(self.findings(text))


if __name__ == '__main__':
    unittest.main()
