"""Synthetic endpoint/possession controls for untrusted critical extraction."""
import copy
import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import engine


BASE = {'location': 'Sable Quay', 'parent_area': 'Frostford', 'time_of_day': 'Noon',
        'inventory': ['folded map'], 'journal': []}
PROFILE = {'name': 'Lysa', 'aliases': ['Ash Sparrow'], 'pronouns': 'she/her'}
HEADER = '[Sable Quay - Frostford - Noon]'
DESTINATION = 'Copper House'
SENTENCE = "The packet boat's ramp remains lowered, its weathered boards wet with river spray."
BODY = SENTENCE + ' A clerk folds a green receipt beside the empty luggage scales.'


class SceneStateSupportTests(unittest.TestCase):
    def review(self, body=BODY, updates=None, *, heading=HEADER, action='I listen.', base=None):
        return engine._review_gm_turn(heading + '\n\n' + body if heading else body,
            copy.deepcopy(updates or {}), copy.deepcopy(base or BASE), 'Lysa', action, [],
            world_title='The Frostford Couriers', require_evidence=True, pc_profile=PROFILE)

    def move(self, body, *, evidence=None, action='I board the boat and travel to Copper House.'):
        updates = {'location': DESTINATION, 'evidence': {'location': body if evidence is None else evidence}}
        return self.review(body, updates, heading='[Copper House - Frostford - Noon]', action=action)

    def test_full_descriptive_body_sentence_is_omitted_under_stable_heading(self):
        for evidence in (None, SENTENCE):
            with self.subTest(evidence=evidence):
                updates = {'location': SENTENCE}
                if evidence is not None:
                    updates['evidence'] = {'location': evidence}
                original = copy.deepcopy(updates)
                review = self.review(updates=updates)
                self.assertEqual(review.violations, [])
                self.assertNotIn('location', review.updates)
                self.assertEqual(review.omitted.get('location'), 1)
                self.assertEqual(updates, original)

    def test_projection_preserves_valid_notes_and_inventory_siblings(self):
        event = 'A clerk folds a green receipt.'
        gain = 'The clerk puts a brass token into your hand.'
        review = self.review(BODY + ' ' + event + ' ' + gain, {
            'location': SENTENCE, 'inventory_add': ['brass token'],
            'evidence': {'inventory_add': gain},
            'scene_memory': {'events': [{'text': event, 'evidence': event}]}})
        self.assertEqual(review.violations, [])
        self.assertEqual(review.updates['inventory_add'], ['brass token'])
        self.assertIn('scene_memory', review.updates)
        self.assertNotIn('location', review.updates)

    def test_changed_or_missing_heading_cannot_project_the_sentence(self):
        for heading in ('', '[Copper House - Frostford - Noon]'):
            with self.subTest(heading=heading):
                review = self.review(updates={'location': SENTENCE}, heading=heading)
                self.assertTrue(review.state_violations)
                self.assertIn('location', review.updates)

    def test_unknown_location_cannot_be_filled_by_sentence_projection(self):
        review = self.review(updates={'location': SENTENCE}, base={**BASE, 'location': 'Unknown'})
        self.assertTrue(review.state_violations)
        self.assertIn('location', review.updates)

    def test_sentence_recovery_does_not_hide_actual_time_change(self):
        sentence = 'Night falls across the harbour while the lamps burn brighter.'
        review = self.review(BODY + ' ' + sentence, {'time_of_day': sentence})
        self.assertTrue(review.state_violations)
        self.assertIn('time_of_day', review.updates)

    def test_recognized_actual_or_forced_movement_vetoes_projection_anywhere(self):
        for travel, action in (
            ('You arrive at Copper House.', 'I arrive at Copper House.'),
            ('The boat docks at Copper House.', 'I board the boat and travel to Copper House.'),
            ('A gust hurls you into Copper House.', 'I listen.'),
            ('Inside Copper House, a jeweller opens a tin case.', 'I listen.'),
        ):
            with self.subTest(travel=travel):
                review = self.review(BODY + ' ' + travel, {'location': SENTENCE}, action=action)
                self.assertTrue(review.state_violations)
                self.assertIn('location', review.updates)

    def test_a_whole_arrival_sentence_is_not_a_valid_place_label(self):
        sentence = 'Inside Copper House, a quiet jeweller opens a tin case.'
        review = self.review(sentence, {'location': sentence, 'evidence': {'location': sentence}},
                             action='I travel to Copper House.')
        self.assertTrue(review.state_violations)
        self.assertIn('location', review.updates)

    def test_sentence_with_invented_player_behavior_stays_rejected(self):
        sentence = 'Lysa decides to enter the crowded hall before anyone speaks.'
        review = self.review(BODY + ' ' + sentence, {'location': sentence})
        self.assertTrue(review.violations)
        self.assertIn('location', review.updates)

    def test_inventory_failure_remains_strict_beside_projected_sentence(self):
        review = self.review(updates={'location': SENTENCE, 'inventory_add': ['gold crown']})
        self.assertNotIn('location', review.updates)
        self.assertTrue(review.state_violations)

    def test_visibility_and_routes_do_not_prove_arrival(self):
        for body in (
            "Copper House's roof comes into view beyond the river.",
            'The boat is heading toward Copper House.',
            'Copper House lies ahead beyond a line of willows.',
            'You see Copper House across the harbour.',
        ):
            with self.subTest(body=body):
                self.assertTrue(self.move(body).state_violations)

    def test_future_conditional_negated_or_invited_arrival_is_not_an_endpoint(self):
        for body in (
            'The boat will reach Copper House in three minutes.',
            'If the boat reaches Copper House, its bell will sound.',
            'The boat has not reached Copper House.',
            'You are invited to Copper House after dusk.',
            'You will be carried into Copper House.',
            'You are not carried into Copper House.',
            'You are not at Copper House; the boat remains at Sable Quay.',
            'The boat is not at Copper House; it remains at Sable Quay.',
            'You will be at Copper House after sunset.',
        ):
            with self.subTest(body=body):
                self.assertTrue(self.move(body).state_violations)

    def test_npc_arrival_and_quoted_claim_do_not_grant_player_presence(self):
        for body in (
            'Keeper Neral arrives at Copper House.',
            'The clerk says, "We have arrived at Copper House."',
            'At Copper House, Neral arrives while the boat stays at Sable Quay.',
            'At Copper House, Neral arrives with a folded blue banner.',
        ):
            with self.subTest(body=body):
                self.assertTrue(self.move(body).state_violations)

    def test_actual_arrival_after_visibility_is_valid(self):
        arrival = 'The boat docks at Copper House.'
        body = "Copper House's roof comes into view beyond the river. " + arrival
        self.assertEqual(self.move(body, evidence=arrival).violations, [])

    def test_then_between_vehicle_and_arrival_does_not_lose_the_actor(self):
        body = 'Copper House comes into view. The boat then docks at Copper House.'
        self.assertEqual(self.move(body).violations, [])

    def test_later_coordinated_arrival_is_not_overridden_by_earlier_view_or_negation(self):
        for body in ('You see Copper House, and the boat docks at Copper House.',
                     'The boat was not delayed and now arrives at Copper House.'):
            with self.subTest(body=body):
                self.assertEqual(self.move(body).violations, [])

    def test_authorized_and_forced_arrival_are_valid(self):
        for body, action in (
            ('You arrive at Copper House.', 'I arrive at Copper House.'),
            ('A gust hurls you into Copper House.', 'I listen.'),
            ('You are carried into Copper House.', 'I listen.'),
            ('Inside Copper House, a clerk lays a parcel on the scales.', 'I travel to Copper House.'),
        ):
            with self.subTest(body=body):
                self.assertEqual(self.move(body, action=action).violations, [])

    def test_passive_forced_transport_vetoes_sentence_projection(self):
        for verb in ('carried', 'dragged', 'swept', 'thrown', 'teleported'):
            with self.subTest(verb=verb):
                review = self.review(BODY + ' You are ' + verb + ' into Copper House.',
                                     {'location': SENTENCE})
                self.assertTrue(review.state_violations)
                self.assertIn('location', review.updates)

    def test_player_anchor_then_pronoun_forced_transport_vetoes_projection(self):
        body = BODY + ' Lysa is beside the wagon. She is carried into Copper House by the guards.'
        review = self.review(body, {'location': SENTENCE})
        self.assertTrue(review.state_violations)
        self.assertIn('location', review.updates)

    def test_later_departure_cannot_be_hidden_by_earlier_arrival_quote(self):
        arrival = 'The boat docks at Copper House.'
        body = arrival + ' The boat leaves Copper House for the outer harbour.'
        self.assertTrue(self.move(body, evidence=arrival).state_violations)

    def test_later_npc_departure_does_not_move_the_player(self):
        arrival = 'The boat docks at Copper House.'
        body = arrival + ' Keeper Neral leaves Copper House for the outer harbour.'
        self.assertEqual(self.move(body, evidence=arrival).violations, [])

    def test_later_npc_or_world_arrival_does_not_erase_player_presence(self):
        for later in ('Neral arrives at Copper House.', 'The clock stops at Copper House.',
                      'Neral will arrive at Copper House.'):
            with self.subTest(later=later):
                body = 'The boat arrives at Copper House. ' + later
                self.assertEqual(self.move(body).violations, [])

    def test_literal_place_abbreviation_is_not_a_sentence_boundary(self):
        quote = 'The shuttle arrives at St. Elms.'
        review = self.review(quote, {'location': 'St. Elms', 'evidence': {'location': quote}},
            heading='[St. Elms - Frostford - Noon]', action='I board the shuttle and travel to St. Elms.')
        self.assertEqual(review.violations, [])

    def test_future_arrival_with_abbreviated_place_remains_rejected(self):
        quote = 'The shuttle will arrive at St. Elms in five minutes.'
        review = self.review(quote, {'location': 'St. Elms', 'evidence': {'location': quote}},
            heading='[St. Elms - Frostford - Noon]', action='I board the shuttle and travel to St. Elms.')
        self.assertTrue(review.state_violations)

    def test_quoted_literal_place_name_preserves_arrival_without_granting_npc_claims(self):
        for quote in ('The shuttle arrives at "St. Elms".', "The shuttle arrives at 'St. Elms'."):
            with self.subTest(quote=quote):
                review = self.review(quote, {'location': 'St. Elms', 'evidence': {'location': quote}},
                    heading='[St. Elms - Frostford - Noon]', action='I board the shuttle and travel to St. Elms.')
                self.assertEqual(review.violations, [])
        for quote in ('The clerk says, "I arrive at St. Elms."', 'The clerk answers, "St. Elms".'):
            with self.subTest(quote=quote):
                review = self.review(quote, {'location': 'St. Elms', 'evidence': {'location': quote}},
                    heading='[St. Elms - Frostford - Noon]', action='I board the shuttle and travel to St. Elms.')
                self.assertTrue(review.state_violations)

    def test_item_abbreviation_preserves_explicit_untouched_contradiction(self):
        quote = 'The J. R. seal remains untouched on the counter.'
        review = self.review(quote, {'inventory_add': ['J. R. seal'],
                                  'evidence': {'inventory_add': quote}})
        self.assertTrue(review.state_violations)

    def test_untouched_counter_item_cannot_be_added_from_that_quote(self):
        for quote in ('The brass token remains untouched on the counter.',
                      'The brass token remains on the counter.',
                      'The brass token is still untouched beside the scales.',
                      'The brass token remains untouched on the ticket counter.'):
            with self.subTest(quote=quote):
                review = self.review(quote, {'inventory_add': ['brass token'],
                    'evidence': {'inventory_add': quote}})
                self.assertTrue(review.state_violations)

    def test_later_same_item_acquisition_supersedes_untouched_status(self):
        quote = ('The brass token remains untouched on the counter. '
                 'The clerk puts the brass token into your hand.')
        review = self.review(quote, {'inventory_add': ['brass token'],
            'evidence': {'inventory_add': quote}})
        self.assertEqual(review.violations, [])

    def test_untouched_by_npc_does_not_erase_established_possession(self):
        quote = 'The brass token rests in your hand. The brass token remains untouched by Neral.'
        review = self.review(quote, {'inventory_add': ['brass token'],
            'evidence': {'inventory_add': quote}}, action='I pick up the brass token.')
        self.assertEqual(review.violations, [])

    def test_other_item_acquisition_cannot_override_untouched_target(self):
        quote = ('The brass token remains untouched on the counter. '
                 'The clerk puts a glass bead into your hand.')
        review = self.review(quote, {'inventory_add': ['brass token'],
            'evidence': {'inventory_add': quote}})
        self.assertTrue(review.state_violations)

    def test_later_explicit_retention_blocks_removal(self):
        quote = 'You still carry the folded map.'
        review = self.review(quote, {'inventory_remove': ['folded map'],
            'evidence': {'inventory_remove': quote}}, action='I carry the folded map.')
        self.assertTrue(review.state_violations)

    def test_correct_return_after_retention_is_valid(self):
        quote = 'You still carry the folded map. You return the folded map to the clerk.'
        review = self.review(quote, {'inventory_remove': ['folded map'],
            'evidence': {'inventory_remove': quote}}, action='I carry the folded map and return the folded map to the clerk.')
        self.assertEqual(review.violations, [])

    def test_correct_gain_is_not_erased_by_unrelated_item_status(self):
        quote = ('The brass token remains untouched on the counter. '
                 'The clerk puts a glass bead into your hand.')
        review = self.review(quote, {'inventory_add': ['glass bead'],
            'evidence': {'inventory_add': quote}})
        self.assertEqual(review.violations, [])

    def test_rejected_premature_arrival_leaves_every_database_row_unchanged(self):
        with tempfile.TemporaryDirectory() as directory:
            con = engine.open_db(Path(directory) / 'fixture.db')
            self.addCleanup(con.close)
            world = engine.make_world(con, {'title': 'Frostford', 'description': 'A river port.'})
            campaign = engine.new_campaign(con, {'world_id': world['id'], 'pc_name': 'Lysa'})
            with con:
                con.execute('UPDATE campaigns SET state_json=? WHERE id=?', (json.dumps(BASE), campaign['id']))
            before = list(con.iterdump())
            quote = "Copper House's roof comes into view beyond the river."
            calls = []
            def chat(messages, model, **kwargs):
                calls.append(copy.deepcopy(messages))
                document = {'state_updates': {'location': DESTINATION, 'evidence': {'location': quote}}}
                if len(calls) == 1:
                    document['narration'] = quote
                return json.dumps(document)
            chat.supports_response_schema = True
            chat.requires_state_evidence = True
            with self.assertRaises(ValueError):
                engine.play_turn(con, campaign['id'], 'I board the boat and travel to Copper House.', chat=chat)
            self.assertEqual(len(calls), 2)
            self.assertEqual(list(con.iterdump()), before)


if __name__ == '__main__':
    unittest.main()
