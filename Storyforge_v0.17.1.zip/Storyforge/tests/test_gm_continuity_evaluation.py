"""Synthetic multi-turn integration checks; no measured model-quality claim."""
import io
import json
import logging
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import engine


def synthetic_responder():
    """Authored integration responses, unrelated to any player's campaign."""
    observations = 0
    actions = {case['action']: case['id'] for case in engine.gm_continuity_cases()}

    def respond(messages, _model):
        nonlocal observations
        action = next((message['content'] for message in reversed(messages)
                       if message['role'] == 'user' and message['content'] in actions), None)
        case = actions.get(action)
        changes = {}
        if case == 'approach_without_boarding':
            observations = 0
            text = 'Mara lifts a hand beside the shuttle door. The empty step remains clear, and a canvas curtain flutters behind the driver.'
        elif case == 'npc_dialogue':
            text = '"I run only to North Landing," Mara says. A coil of fresh rope waits beneath her stool.'
        elif case == 'explicit_player_dialogue':
            text = 'The driver taps the unstruck brass bell with a fingernail. A slow queue forms behind the ticket counter.'
        elif case == 'invitation_choice':
            text = 'Mara folds the invitation and slips it into a blue envelope. "Another evening, perhaps," she says.'
        elif case == 'token_pickup':
            span = 'The copper token leaves the ticket counter and rests in your hand.'
            text = span + ' A tiny sailboat is stamped on its reverse.'
            changes = {'inventory_add': ['copper token'], 'evidence': {'inventory_add': span}}
        elif case == 'token_return':
            span = 'The copper token lies on the ticket counter again.'
            text = span + ' Mara adjusts a crooked stack of blank tickets.'
            changes = {'inventory_remove': ['copper token'], 'evidence': {'inventory_remove': span}}
        elif case == 'authorized_travel':
            span = 'The shuttle reaches North Landing in Bellwater, where late afternoon light touches the blue sign.'
            text = span + ' Keeper Dain draws aside a mooring rope.'
            changes = {'location': 'North Landing', 'evidence': {'location': span}}
        elif case == 'landing_retry':
            observations += 1
            text = ('The blue notice reads *"Passengers may wait beneath the awning."* Dain brushes a fallen leaf from the path.'
                    if observations == 1 else
                    'Dain pins a curled corner of the notice beneath a smooth river pebble. A small painted arrow marks the uphill footpath.')
        else:
            raise AssertionError('The evaluator sent an unexpected synthetic action.')
        return json.dumps({'narration': text, 'state_updates': changes})

    return respond


class GMContinuityEvaluationTests(unittest.TestCase):
    def test_dependent_sequence_covers_choices_inventory_travel_and_retry(self):
        cases = engine.gm_continuity_cases()
        self.assertGreaterEqual(len(cases), 8)
        self.assertEqual(len(cases), len({case['id'] for case in cases}))
        self.assertEqual(cases[0]['id'], 'approach_without_boarding')
        self.assertEqual(cases[-1]['operation'], 'retry')
        self.assertEqual(cases[-1]['action'], cases[-2]['action'])
        for case_id in ('npc_dialogue', 'explicit_player_dialogue', 'invitation_choice',
                        'token_pickup', 'token_return', 'authorized_travel', 'landing_observation'):
            self.assertIn(case_id, {case['id'] for case in cases})
        cases[0]['review'].append('test mutation')
        self.assertNotIn('test mutation', engine.gm_continuity_cases()[0]['review'])

    def test_runs_real_dependent_turns_and_retries_without_personal_data(self):
        with tempfile.TemporaryDirectory() as directory:
            personal = Path(directory) / 'private'
            personal.mkdir()
            (personal / 'storyforge.db').write_bytes(b'PRIVATE CAMPAIGNS')
            (personal / 'portrait.png').write_bytes(b'PRIVATE ART')
            (personal / 'settings.json').write_text('{"model":"PRIVATE MODEL"}')
            original_files = {path.name: path.read_bytes() for path in personal.iterdir()}
            opened = []
            original_open = engine.open_db

            def disposable_only(path):
                opened.append(Path(path))
                self.assertNotIn(personal, Path(path).parents)
                return original_open(path)

            with patch.dict(os.environ, {'STORYFORGE_DB': str(personal / 'storyforge.db')}), \
                    patch.object(engine, 'open_db', side_effect=disposable_only), \
                    patch.object(engine, '_gm_evaluation_model_metadata') as metadata, \
                    patch('engine.urllib.request.urlopen') as network:
                report = engine.evaluate_gm_continuity('synthetic:14b', chat=synthetic_responder())
            metadata.assert_not_called()
            network.assert_not_called()
            self.assertEqual(original_files, {path.name: path.read_bytes() for path in personal.iterdir()})
            self.assertEqual(len(opened), 1)
            self.assertTrue(all(not path.exists() for path in opened))
        self.assertEqual(report['execution'], 'offline_test_adapter')
        self.assertTrue(report['manual_review_required'])
        self.assertNotIn('PRIVATE', json.dumps(report))
        self.assertEqual(report['summary']['completed_runs'], 1)
        self.assertEqual(report['summary']['completed'], 9)
        self.assertEqual(report['summary']['generation_requests'], 9)
        self.assertEqual(report['summary']['manual_review_pending'], 9)
        run = report['runs'][0]
        self.assertTrue(run['forced_retry_failure_check']['existing_campaign_preserved'])
        for step in run['steps']:
            self.assertEqual(step['status'], 'completed')
            self.assertEqual(step['manual_review']['status'], 'pending')
            self.assertTrue(all(step['automatic_checks']['state'].values()))
            self.assertTrue(all(step['automatic_checks']['storage'].values()))
        pickup, returned, travel, observed, retried = run['steps'][4:]
        self.assertIn('copper token', pickup['state_after']['inventory'])
        self.assertNotIn('copper token', returned['state_after']['inventory'])
        self.assertEqual(travel['state_after']['location'], 'North Landing')
        self.assertEqual(observed['input']['state_before'], travel['state_after'])
        self.assertIn(travel['narration'], [message['content'] for message in observed['attempts'][0]['messages']])
        self.assertEqual(retried['input']['operation'], 'retry')
        self.assertNotEqual(observed['narration'], retried['narration'])

    def test_failed_turn_preserves_database_and_blocks_dependent_actions(self):
        calls = []

        def unauthorized(messages, model):
            calls.append((messages, model))
            return json.dumps({'narration': 'You decide to attend the ceremony and hurry aboard.', 'state_updates': {}})

        report = engine.evaluate_gm_continuity('synthetic:14b', chat=unauthorized)
        first, *remaining = report['runs'][0]['steps']
        self.assertEqual(first['status'], 'guardrail_rejected')
        self.assertTrue(first['automatic_checks']['campaign_unchanged_on_failure'])
        self.assertLessEqual(len(calls), 2)
        self.assertEqual(len(calls), 2)
        self.assertTrue(all(step['status'] == 'blocked' and not step['attempts'] for step in remaining))
        self.assertTrue(all(step['manual_review']['status'] == 'not_run' for step in remaining))
        self.assertEqual(report['summary']['manual_review_pending'], 1)
        self.assertIn('rejected_reply_diagnostics', first)
        self.assertTrue(report['runs'][0]['forced_retry_failure_check']['existing_campaign_preserved'])

    def test_transport_failure_does_not_spam_later_steps_or_repeats(self):
        calls = []

        def unavailable(messages, model):
            calls.append(model)
            raise RuntimeError('Synthetic local Ollama unavailable')

        report = engine.evaluate_gm_continuity('missing:14b', repeat=3, chat=unavailable)
        self.assertEqual(calls, ['missing:14b'])
        self.assertEqual(report['summary']['transport_error'], 1)
        self.assertEqual(report['summary']['blocked'], 26)
        self.assertEqual(report['summary']['total_runs'], 3)
        self.assertEqual(report['runs'][1]['status'], 'blocked')
        self.assertTrue(report['runs'][0]['steps'][0]['automatic_checks']['campaign_unchanged_on_failure'])

    def test_accepted_but_missing_token_update_blocks_invalid_future_sequence(self):
        accepted = synthetic_responder()

        def forgetful(messages, model):
            response = json.loads(accepted(messages, model))
            if response['state_updates'].get('inventory_add'):
                response['state_updates'] = {}
            return json.dumps(response)

        report = engine.evaluate_gm_continuity('synthetic:14b', chat=forgetful)
        pickup = report['runs'][0]['steps'][4]
        self.assertEqual(pickup['status'], 'state_expectation_failed')
        self.assertTrue(pickup['automatic_checks']['pipeline_accepted'])
        self.assertFalse(pickup['automatic_checks']['state']['expected_token_possession'])
        self.assertTrue(all(step['status'] == 'blocked' for step in report['runs'][0]['steps'][5:]))
        self.assertEqual(report['summary']['generation_requests'], 5)

    def test_label_capitalization_alone_is_not_a_continuity_failure(self):
        accepted = synthetic_responder()

        def varied_case(messages, model):
            response = json.loads(accepted(messages, model))
            if response['state_updates'].get('location') == 'North Landing':
                response['state_updates']['location'] = 'north landing'
            return json.dumps(response)

        report = engine.evaluate_gm_continuity('synthetic:14b', chat=varied_case)
        self.assertEqual(report['summary']['completed_runs'], 1)
        self.assertEqual(report['runs'][0]['steps'][6]['state_after']['location'], 'north landing')

    def test_models_and_repetitions_start_independent_disposable_campaigns(self):
        report = engine.evaluate_gm_continuity(['first:14b', 'second:12b', 'first:14b'], repeat=2,
                                               chat=synthetic_responder())
        self.assertEqual(report['models'], ['first:14b', 'second:12b'])
        self.assertEqual(report['summary']['completed_runs'], 4)
        self.assertEqual(report['summary']['completed'], 36)
        for run in report['runs']:
            self.assertEqual(run['fixture']['initial_state']['location'], 'South Quay')
            self.assertEqual(run['fixture']['initial_state']['inventory'], ['folded city map'])
            self.assertEqual(len(run['fixture']['initial_messages']), 1)

    def test_plain_adapter_does_not_receive_unadvertised_keywords(self):
        accepted = synthetic_responder()
        calls = []

        def plain(messages, model):
            calls.append(model)
            return accepted(messages, model)

        report = engine.evaluate_gm_continuity('plain:14b', chat=plain)
        self.assertEqual(report['summary']['completed_runs'], 1)
        self.assertEqual(len(calls), 9)

    def test_capable_adapter_receives_original_budgeted_timeout(self):
        accepted = synthetic_responder()
        timeouts = []

        def capable(messages, model, *, timeout, response_schema=None):
            timeouts.append(timeout)
            return accepted(messages, model)

        capable.supports_timeout = True
        capable.supports_response_schema = True
        report = engine.evaluate_gm_continuity('capable:14b', chat=capable)
        self.assertEqual(report['summary']['completed_runs'], 1)
        self.assertEqual(len(timeouts), 9)
        self.assertTrue(all(0 < timeout <= 70 for timeout in timeouts))

    def test_live_path_uses_actual_local_transport_and_numeric_load_timings(self):
        accepted = synthetic_responder()
        requests = []

        def reply(request, *, timeout):
            payload = json.loads(request.data)
            requests.append((request, payload, timeout))
            content = accepted(payload['messages'], payload['model'])
            return io.BytesIO(json.dumps({'message': {'content': content}, 'done': True,
                'load_duration': 2_000_000_000 if len(requests) == 1 else 1_000_000,
                'prompt_eval_count': 120, 'eval_count': 45, 'eval_duration': 300_000_000}).encode())

        with patch.object(engine, '_gm_evaluation_model_metadata', return_value={'status': 'available', 'quantization': 'Q4_K_M'}), \
                patch('engine.urllib.request.urlopen', side_effect=reply):
            report = engine.evaluate_gm_continuity('installed:14b')
        self.assertEqual(report['execution'], 'local_ollama')
        self.assertEqual(report['summary']['completed_runs'], 1)
        self.assertEqual(len(requests), 9)
        for request, payload, timeout in requests:
            self.assertEqual(request.full_url, 'http://127.0.0.1:11434/api/chat')
            self.assertEqual(payload['model'], 'installed:14b')
            self.assertIsInstance(payload['format'], dict)
            self.assertFalse(payload['stream'])
            self.assertLessEqual(timeout, 70)
        timing = report['timing']['models']['installed:14b']
        self.assertEqual(timing['first_request']['ollama_metrics'][0]['load_ms'], 2000)
        self.assertEqual(timing['subsequent_requests'][0]['ollama_metrics'][0]['load_ms'], 1)
        self.assertEqual(report['model_metadata']['installed:14b']['quantization'], 'Q4_K_M')

    def test_state_extraction_schema_is_forwarded_and_prose_is_preserved(self):
        accepted = synthetic_responder()
        provisional = []
        requests = []

        def capable(messages, model, *, timeout, response_schema):
            requests.append((messages, response_schema, timeout))
            if response_schema is engine.GM_STATE_RESPONSE_SCHEMA:
                data = json.loads(messages[-1]['content'])
                self.assertEqual(data['provisional_narration'], provisional[0])
                self.assertNotIn('UNSUPPORTED EXTRACTION MARKER', json.dumps(messages))
                self.assertEqual(len(messages), 2)
                return json.dumps({'state_updates': {'location': 'North Landing',
                    'evidence': {'location': 'The shuttle reaches North Landing in Bellwater, where late afternoon light touches the blue sign.'}}})
            response = json.loads(accepted(messages, model))
            if response['state_updates'].get('location') == 'North Landing':
                response['narration'] = '[North Landing - Bellwater - Late afternoon]\n\n' + response['narration']
                provisional.append(response['narration'])
                response['state_updates']['evidence']['location'] = 'UNSUPPORTED EXTRACTION MARKER'
            return json.dumps(response)

        capable.supports_timeout = True
        capable.supports_response_schema = True
        report = engine.evaluate_gm_continuity('capable:14b', chat=capable)
        self.assertEqual(report['summary']['completed_runs'], 1)
        self.assertEqual(report['summary']['generation_requests'], 10)
        self.assertEqual(report['summary']['turns_with_second_call'], 1)
        travel = report['runs'][0]['steps'][6]
        self.assertEqual(travel['narration'], provisional[0])
        self.assertEqual([attempt['phase'] for attempt in travel['attempts']], ['narration', 'state_extraction'])
        self.assertEqual(travel['attempts'][1]['response_schema'], engine.GM_STATE_RESPONSE_SCHEMA)
        self.assertTrue(all(0 < timeout <= 70 for _messages, _schema, timeout in requests))

    def test_malformed_outputs_stop_sequence_without_committing_or_claiming_quality(self):
        report = engine.evaluate_gm_continuity('malformed:14b', chat=lambda _messages, _model: 'not JSON')
        first = report['runs'][0]['steps'][0]
        self.assertEqual(first['status'], 'invalid_response')
        self.assertEqual(len(first['attempts']), 2)
        self.assertTrue(first['automatic_checks']['campaign_unchanged_on_failure'])
        self.assertEqual(report['summary']['blocked'], 8)
        self.assertEqual(report['summary']['completed_runs'], 0)

    def test_progress_reports_status_without_generated_prose(self):
        updates = []
        report = engine.evaluate_gm_continuity('synthetic:14b', chat=synthetic_responder(), progress=updates.append)
        self.assertTrue(updates)
        self.assertNotIn('tiny sailboat', '\n'.join(updates))
        self.assertEqual(report['summary']['completed'], 9)

    def test_logger_configuration_is_restored_after_evaluation(self):
        logger = logging.getLogger('engine.ollama')
        before = (logger.level, list(logger.handlers))
        engine.evaluate_gm_continuity('synthetic:14b', chat=synthetic_responder())
        self.assertEqual((logger.level, logger.handlers), before)

    def test_invalid_arguments_do_not_access_models_or_databases(self):
        invalid = [([], 1), (['x'] * 6, 1), ('', 1), ('bad\nmodel', 1),
                   ('valid:14b', 0), ('valid:14b', 6), ('valid:14b', True), ('valid:14b', 1.5)]
        with patch.object(engine, 'open_db') as database, patch('engine.urllib.request.urlopen') as network:
            for models, repeat in invalid:
                with self.subTest(models=models, repeat=repeat), self.assertRaises(ValueError):
                    engine.evaluate_gm_continuity(models, repeat=repeat, chat=synthetic_responder())
            with self.assertRaises(ValueError):
                engine.evaluate_gm_continuity('valid:14b', chat='not callable')
            database.assert_not_called()
            network.assert_not_called()


if __name__ == '__main__':
    unittest.main()
