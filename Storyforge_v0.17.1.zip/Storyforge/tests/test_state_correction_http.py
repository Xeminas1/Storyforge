"""Real localhost HTTP checks for staged GM repair; model replies are scripted."""
from contextlib import closing
import json
import unittest

import engine
import server
import test_gm_http as gm_http


CURRENT = '[River Gate - Coast - Dusk]'
DESTINATION = '[Beacon Archive - Coast - Dusk]'
MOVE_QUOTE = 'At Beacon Archive, the keeper lights a lamp above the reading desk.'
MOVE = DESTINATION + '\n\n' + MOVE_QUOTE
STABLE = CURRENT + '\n\nA courier unrolls a map beside the customs window.'
STATE = {'location': 'Beacon Archive', 'evidence': {'location': MOVE_QUOTE}}
RAW_MARKER = 'PRIVATE_REJECTED_EXTRACTION_MARKER'


class StateCorrectionHttpTests(unittest.TestCase):
    start_server = gm_http.GameMasterHttpTests.start_server
    post = gm_http.GameMasterHttpTests.post
    dump = gm_http.GameMasterHttpTests.dump

    def setUp(self):
        gm_http.GameMasterHttpTests.setUp(self)
        with closing(engine.open_db(self.path)) as con:
            state = engine.get_campaign(con, self.cid)['state']
            state.update(location='River Gate', parent_area='Coast', time_of_day='Dusk')
            with con:
                con.execute('UPDATE campaigns SET state_json=? WHERE id=?',
                            (json.dumps(state), self.cid))

    def test_real_transport_repairs_state_without_generating_new_narration(self):
        self.model.replies = [gm_http.output(MOVE, location=RAW_MARKER),
                              json.dumps({'state_updates': STATE})]
        result = self.post('/turn', {'action': 'I walk to Beacon Archive.',
                                     'model': 'ministral-3:14b'})
        self.assertEqual(result['narration'], MOVE)
        self.assertEqual(result['state']['location'], 'Beacon Archive')
        self.assertEqual([message['role'] for message in result['messages']], ['player', 'gm'])
        first, second = self.model.requests
        self.assertEqual(first['format'], engine.GM_RESPONSE_SCHEMA)
        self.assertEqual(second['format'], engine.GM_STATE_RESPONSE_SCHEMA)
        self.assertEqual(set(second['format']['properties']), {'state_updates'})
        self.assertIn(MOVE_QUOTE, json.dumps(second['messages']))
        self.assertNotIn(RAW_MARKER, json.dumps(second['messages']))
        for request in (first, second):
            self.assertEqual(request['model'], 'ministral-3:14b')
            self.assertNotIn('think', request)
            self.assertEqual(request['options']['num_ctx'], 8192)
            self.assertEqual(request['options']['num_predict'], 1050)

    def test_failed_state_correction_returns_distinct_private_diagnostic_atomically(self):
        self.model.replies = [gm_http.output(MOVE, location=RAW_MARKER),
                              json.dumps({'state_updates': {**STATE,
                                         'inventory_add': ['unobserved sapphire']}})]
        before = self.dump()
        result = self.post('/turn', {'action': 'I walk to Beacon Archive.',
                                     'model': 'ministral-3:14b'}, expected=400)
        self.assertEqual(self.dump(), before)
        self.assertEqual(len(self.model.requests), 2)
        attempts = result['gm_diagnostics']['attempts']
        self.assertEqual(attempts[1]['phase'], 'state_extraction')
        self.assertEqual(attempts[1]['narration'], MOVE)
        self.assertNotIn(MOVE_QUOTE, result['error'])
        self.assertNotIn(RAW_MARKER, result['error'])

    def test_narrative_retry_can_survive_unrelated_unsupported_scene_metadata(self):
        bad = CURRENT + '\n\nYou decide to board the private coach and depart.'
        self.model.replies = [gm_http.output(bad), gm_http.output(STABLE,
                              location='Unmentioned Northern Observatory')]
        result = self.post('/turn', {'action': 'I approach the public carriage.',
                                     'model': 'ministral-3:14b'})
        self.assertEqual(len(self.model.requests), 2)
        self.assertEqual(result['narration'], STABLE)
        self.assertEqual(result['state']['location'], 'River Gate')
        self.assertEqual(self.model.requests[1]['format'], engine.GM_RESPONSE_SCHEMA)
        self.assertNotIn('You decide to board', json.dumps(self.model.requests[1]['messages']))
        self.assertNotIn('You decide to board', self.dump())

    def test_state_correction_cannot_return_a_replacement_story(self):
        self.model.replies = [gm_http.output(MOVE, location=RAW_MARKER),
                              gm_http.output(STABLE, **STATE)]
        before = self.dump()
        result = self.post('/turn', {'action': 'I walk to Beacon Archive.',
                                     'model': 'ministral-3:14b'}, expected=400)
        self.assertEqual(self.dump(), before)
        self.assertEqual(len(self.model.requests), 2)
        self.assertIn('Nothing was saved', result['error'])


if __name__ == '__main__':
    unittest.main()
