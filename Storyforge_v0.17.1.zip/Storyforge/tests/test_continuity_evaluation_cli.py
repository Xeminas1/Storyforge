"""The connected evaluation command must never launch or read the live game."""
from contextlib import redirect_stderr, redirect_stdout
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import server


class ContinuityEvaluationCliTests(unittest.TestCase):
    def invoke(self, arguments):
        with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
            return server.main(arguments)

    def test_connected_flag_requires_an_explicit_model_without_starting_server(self):
        with patch.object(server, 'run') as run:
            with self.assertRaises(SystemExit) as raised:
                self.invoke(['--evaluate-continuity'])
        self.assertEqual(raised.exception.code, 2)
        run.assert_not_called()

    def test_connected_command_uses_new_evaluator_and_writes_only_new_report(self):
        fixture = {'schema': 'synthetic-connected-test', 'summary': {
            'completed': 9, 'failed': 0, 'not_run': 0}}
        with tempfile.TemporaryDirectory() as directory:
            destination = Path(directory) / 'connected.json'
            with patch.object(server.engine, 'evaluate_gm_continuity', return_value=fixture) as connected, \
                    patch.object(server.engine, 'evaluate_local_gm') as isolated, \
                    patch.object(server, 'run') as run, patch.object(server, 'bootstrap') as bootstrap:
                code = self.invoke(['--evaluate-continuity', '--evaluate-model', 'trial:14b',
                                    '--repeat', '2', '--report', str(destination)])
            self.assertEqual(code, 0)
            self.assertEqual(json.loads(destination.read_text()), fixture)
            self.assertEqual(connected.call_args.args, (['trial:14b'],))
            self.assertEqual(connected.call_args.kwargs['repeat'], 2)
            isolated.assert_not_called()
            run.assert_not_called()
            bootstrap.assert_not_called()

    def test_existing_report_is_preserved_before_any_model_request(self):
        with tempfile.TemporaryDirectory() as directory:
            destination = Path(directory) / 'existing.json'
            destination.write_bytes(b'private previous report')
            with patch.object(server.engine, 'evaluate_gm_continuity') as connected:
                with self.assertRaises(SystemExit) as raised:
                    self.invoke(['--evaluate-continuity', '--evaluate-model', 'trial:14b',
                                 '--report', str(destination)])
            self.assertEqual(raised.exception.code, 2)
            self.assertEqual(destination.read_bytes(), b'private previous report')
            connected.assert_not_called()

    def test_blocked_sequence_returns_failure_status_for_local_review(self):
        fixture = {'summary': {'completed': 2, 'failed': 1, 'not_run': 6}}
        with tempfile.TemporaryDirectory() as directory:
            destination = Path(directory) / 'blocked.json'
            with patch.object(server.engine, 'evaluate_gm_continuity', return_value=fixture):
                code = self.invoke(['--evaluate-continuity', '--evaluate-model', 'trial:14b',
                                    '--report', str(destination)])
            self.assertEqual(code, 1)
            self.assertEqual(json.loads(destination.read_text()), fixture)

    def test_browser_launch_and_invalid_repeats_are_rejected_before_inference(self):
        for extra in (['--open-browser'], ['--repeat', '0'], ['--repeat', '6']):
            with self.subTest(extra=extra), patch.object(server.engine, 'evaluate_gm_continuity') as connected, \
                    patch.object(server, 'run') as run:
                with self.assertRaises(SystemExit) as raised:
                    self.invoke(['--evaluate-continuity', '--evaluate-model', 'trial:14b', *extra])
                self.assertEqual(raised.exception.code, 2)
                connected.assert_not_called()
                run.assert_not_called()


if __name__ == '__main__':
    unittest.main()
