"""Standalone paired-protocol controls, using only invented local model replies.

These checks establish diagnostic isolation and honest outcomes, not the quality
of a model or the equivalence of narrator-only state preservation.
"""
import hashlib
import importlib.util
import json
import os
import sqlite3
import subprocess
import sys
import tempfile
import threading
import unittest
import zipfile
from contextlib import contextmanager
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from unittest.mock import patch


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import engine


def load_repository_tool(name):
    source = ROOT / 'tools' / (name + '.py')
    if not source.exists():
        return None
    spec = importlib.util.spec_from_file_location('test_' + name, source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


protocol = load_repository_tool('protocol_check')
builder = load_repository_tool('build_protocol_check')
INSTALLED_PACKAGE = ROOT / 'dist' / 'Storyforge_v0.17.0.zip'
CASE_IDS = ('approach_without_boarding', 'token_pickup', 'authorized_travel')
CANONICAL = {
    'approach_without_boarding': (
        '[South Quay - Bellwater - Late afternoon]\n\n'
        'Mara hooks a canvas curtain above the shuttle door. '
        '"I keep the step clear for passengers," she says. A gull tugs a loose cord beside her stool.', {}),
    'token_pickup': (
        '[South Quay - Bellwater - Late afternoon]\n\n'
        'The copper token leaves the ticket counter and rests in your hand. '
        'A tiny sailboat is stamped on its reverse. Mara aligns three blank tickets.',
        {'inventory_add': ['copper token'], 'evidence': {
            'inventory_add': 'The copper token leaves the ticket counter and rests in your hand.'}}),
    'authorized_travel': (
        '[North Landing - Bellwater - Late afternoon]\n\n'
        'The shuttle reaches North Landing in Bellwater, where late afternoon light touches the blue sign. '
        'Keeper Dain draws aside a mooring rope. The hill pavilion remains quiet until sunset.',
        {'location': 'North Landing', 'evidence': {
            'location': 'The shuttle reaches North Landing in Bellwater, where late afternoon light touches the blue sign.'}}),
}


def phase_of(schema):
    properties = schema.get('properties', {})
    if 'narration' not in properties:
        return 'state_extraction'
    return 'rich_narration' if 'state_updates' in properties else 'narration_only'


def action_from(messages):
    """Locate the submitted action without knowing authored history formatting."""
    actions = {case['action']: case['id'] for case in engine.gm_continuity_cases()
               if case['id'] in CASE_IDS}
    for message in reversed(messages):
        if message['role'] != 'user':
            continue
        content = message['content']
        if content in actions:
            return actions[content]
        try:
            document = json.loads(content)
        except (ValueError, TypeError):
            continue
        if isinstance(document, dict) and document.get('submitted_action') in actions:
            return actions[document['submitted_action']]
    raise AssertionError('The protocol diagnostic omitted its exact authored final action.')


def response_for(messages, schema):
    case = action_from(messages)
    narration, updates = CANONICAL[case]
    phase = phase_of(schema)
    return {'state_updates': updates} if phase == 'state_extraction' else (
        {'narration': narration} if phase == 'narration_only' else
        {'narration': narration, 'state_updates': updates})


def adapter(transform=None):
    calls = []

    def respond(messages, model, *, timeout, response_schema):
        call = {'messages': json.loads(json.dumps(messages)), 'model': model,
                'timeout': timeout, 'response_schema': json.loads(json.dumps(response_schema))}
        calls.append(call)
        document = response_for(messages, response_schema)
        if transform:
            document = transform(document, phase_of(response_schema), action_from(messages), call)
        return document if isinstance(document, str) else json.dumps(document)

    respond.calls = calls
    return respond


def arms(report, arm=None):
    return [result for pair in report['pairs'] for result in pair['arms']
            if arm is None or result['arm'] == arm]


@contextmanager
def local_protocol_ollama(transform=None):
    calls = []

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, _format, *args):
            pass

        def send_json(self, document):
            content = json.dumps(document).encode()
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(content)))
            self.end_headers()
            self.wfile.write(content)

        def do_GET(self):
            self.send_json({'models': [{'name': 'ministral-3:14b', 'digest': 'synthetic-model-digest',
                                       'details': {'parameter_size': '14B'}}]})

        def do_POST(self):
            document = json.loads(self.rfile.read(int(self.headers['Content-Length'])))
            if self.path != '/api/chat':
                self.send_json({})
                return
            calls.append(document)
            response = response_for(document['messages'], document['format'])
            if transform:
                response = transform(response, phase_of(document['format']), action_from(document['messages']), document)
            content = response if isinstance(response, str) else json.dumps(response)
            self.send_json({'message': {'content': content}, 'done': True, 'done_reason': 'stop',
                'load_duration': 1_000_000, 'eval_count': 25, 'eval_duration': 5_000_000,
                'prompt_eval_count': 100, 'prompt_eval_duration': 2_000_000})

    httpd = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
    worker = threading.Thread(target=httpd.serve_forever, daemon=True)
    worker.start()
    try:
        yield f'http://127.0.0.1:{httpd.server_port}', calls
    finally:
        httpd.shutdown()
        worker.join(timeout=5)
        httpd.server_close()


@unittest.skipUnless(protocol is not None, 'Standalone protocol checker is repository-only.')
class PairedProtocolTests(unittest.TestCase):
    def evaluate(self, respond=None, **kwargs):
        return protocol.evaluate_protocols(engine, ['synthetic:14b'], repeat=kwargs.pop('repeat', 1),
                                           chat=respond or adapter(), **kwargs)

    def test_paired_snapshots_are_independent_and_alternate_order(self):
        respond = adapter()
        report = self.evaluate(respond, repeat=2)
        self.assertEqual(report['schema'], 'storyforge.local-gm-protocol-comparison')
        self.assertEqual(report['execution'], 'offline_test_adapter')
        self.assertEqual(len(report['pairs']), 6)
        self.assertEqual(report['summary']['generation_requests'], 18)
        self.assertEqual(len(respond.calls), 18)
        self.assertEqual({pair['case_id'] for pair in report['pairs']}, set(CASE_IDS))
        orders = [tuple(result['arm'] for result in pair['arms']) for pair in report['pairs']]
        self.assertEqual(set(orders), {('rich', 'narrator_only'), ('narrator_only', 'rich')})
        for index in range(1, len(orders)):
            self.assertNotEqual(orders[index], orders[index - 1])
        for pair in report['pairs']:
            first, second = pair['arms']
            self.assertEqual(first['factual_context_sha256'], second['factual_context_sha256'])
            self.assertEqual(len(first['factual_context_sha256']), 64)
            for result in pair['arms']:
                self.assertEqual(result['status'], 'candidate_ready')
                self.assertEqual(result['candidate_narration'], CANONICAL[pair['case_id']][0])
                self.assertEqual(result['candidate_state']['last_action'], pair['input']['action'])
                self.assertTrue(result['automatic_checks']['database_unchanged'])
                self.assertEqual(result['automatic_checks']['database_write_attempts'], 0)
                self.assertTrue(all(result['automatic_checks']['expected_state'].values()))
                self.assertEqual(result['manual_review']['status'], 'pending')
                self.assertTrue(result['manual_review']['questions'])
                phases = [attempt['phase'] for attempt in result['attempts']]
                self.assertEqual(phases, ['rich_narration'] if result['arm'] == 'rich'
                                 else ['narration_only', 'state_extraction'])
                for attempt in result['attempts']:
                    self.assertTrue(0 < attempt['timeout_seconds'] <= 70)
                    self.assertTrue(attempt['messages'])
                    self.assertTrue(attempt['response_schema'])
        for case_id in CASE_IDS:
            copies = [pair for pair in report['pairs'] if pair['case_id'] == case_id]
            self.assertEqual(copies[0]['input']['action'], copies[1]['input']['action'])
            self.assertEqual(copies[0]['input']['canonical_state'], copies[1]['input']['canonical_state'])
            self.assertEqual([(item['role'], item['content']) for item in copies[0]['input']['authored_history']],
                             [(item['role'], item['content']) for item in copies[1]['input']['authored_history']])
            self.assertEqual(copies[0]['factual_context_sha256'], copies[1]['factual_context_sha256'])
            self.assertEqual(copies[0]['factual_context'], copies[1]['factual_context'])
        self.assertTrue(report['manual_review_required'])
        self.assertIn('not', report['notice'].lower())

    def test_narrator_contract_changes_no_factual_record_or_story_policy(self):
        report = self.evaluate()
        for pair in report['pairs']:
            by_arm = {result['arm']: result for result in pair['arms']}
            rich = by_arm['rich']['attempts'][0]
            narrator = by_arm['narrator_only']['attempts'][0]
            self.assertEqual(rich['messages'][1:], narrator['messages'][1:])
            self.assertEqual(rich['messages'][0]['content'].split('RESPONSE CONTRACT:')[0],
                             narrator['messages'][0]['content'].split('RESPONSE CONTRACT:')[0])
            schema = narrator['response_schema']
            self.assertEqual(set(schema['properties']), {'narration'})
            self.assertEqual(schema['required'], ['narration'])
            self.assertIs(schema['additionalProperties'], False)
            self.assertEqual(schema['properties']['narration']['maxLength'], 12000)
            self.assertEqual(schema['properties']['narration']['minLength'], 1)
            for field in ('temperature', 'num_ctx', 'num_predict'):
                self.assertNotIn(field, schema)

    def test_presentation_cleanup_matches_rich_arm_and_extractor_cannot_change_it(self):
        suffix = ' The notice reads \\*"Later sailings"\\* beside a `blue` tack.'

        def escaped_presentation(document, phase, _case, _call):
            if phase != 'state_extraction':
                document['narration'] = '  ' + document['narration'] + suffix + '  '
            return document

        report = self.evaluate(adapter(escaped_presentation))
        for pair in report['pairs']:
            rich, narrator = (next(result for result in pair['arms'] if result['arm'] == name)
                              for name in ('rich', 'narrator_only'))
            self.assertEqual(rich['status'], 'candidate_ready')
            self.assertEqual(narrator['status'], 'candidate_ready')
            self.assertEqual(rich['candidate_narration'], narrator['candidate_narration'])
            self.assertTrue(narrator['narration_presentation_normalized'])
            self.assertIn('\\*', json.loads(narrator['attempts'][0]['response'])['narration'])
            self.assertIn('*"Later sailings"* beside a blue tack.', narrator['candidate_narration'])
            data = json.loads(narrator['attempts'][1]['messages'][-1]['content'])
            self.assertEqual(data['provisional_narration'], narrator['candidate_narration'])
            self.assertEqual(rich['candidate_state']['last_action'], pair['input']['action'])
            self.assertEqual(rich['candidate_state'], narrator['candidate_state'])

    def test_malformed_narrator_envelope_stops_before_extraction(self):
        def add_state(document, phase, _case, _call):
            if phase == 'narration_only':
                document['state_updates'] = {}
            return document
        respond = adapter(add_state)
        report = self.evaluate(respond)
        for result in arms(report, 'narrator_only'):
            self.assertNotEqual(result['status'], 'candidate_ready')
            self.assertEqual([item['phase'] for item in result['attempts']], ['narration_only'])
            self.assertTrue(result['automatic_checks']['database_unchanged'])
        self.assertEqual(len(respond.calls), 6)

    def test_player_owned_narration_stops_narrator_arm_before_extraction(self):
        def invent_action(document, phase, _case, _call):
            if phase == 'narration_only':
                document['narration'] = '[South Quay - Bellwater - Late afternoon]\n\nI decide to attend the ceremony and hurry aboard.'
            return document
        report = self.evaluate(adapter(invent_action))
        for result in arms(report, 'narrator_only'):
            self.assertNotEqual(result['status'], 'candidate_ready')
            self.assertTrue(result['narrative_findings'])
            self.assertEqual(len(result['attempts']), 1)
            self.assertIsNone(result['candidate_state'])

    def test_two_rejected_rich_drafts_are_reported_without_stopping_other_snapshots(self):
        def invent_rich_action(document, phase, _case, _call):
            if phase == 'rich_narration':
                document['narration'] = '[South Quay - Bellwater - Late afternoon]\n\nYou decide to attend the ceremony and hurry aboard.'
                document['state_updates'] = {}
            return document
        report = self.evaluate(adapter(invent_rich_action))
        self.assertEqual(len(report['pairs']), 3)
        self.assertEqual(len(arms(report)), 6)
        for result in arms(report, 'rich'):
            self.assertEqual(result['status'], 'guardrail_rejected')
            self.assertEqual(len(result['attempts']), 2)
            self.assertEqual(len(result['rejected_reply_diagnostics']['attempts']), 2)
            self.assertTrue(result['automatic_checks']['database_unchanged'])
            self.assertIsNone(result['candidate_state'])
        self.assertTrue(all(result['status'] == 'candidate_ready' for result in arms(report, 'narrator_only')))

    def test_empty_extraction_exposes_missing_token_without_inventing_inventory(self):
        def omit_token(document, phase, case, _call):
            if phase == 'state_extraction' and case == 'token_pickup':
                return {'state_updates': {}}
            return document
        report = self.evaluate(adapter(omit_token))
        pickup = next(pair for pair in report['pairs'] if pair['case_id'] == 'token_pickup')
        result = next(item for item in pickup['arms'] if item['arm'] == 'narrator_only')
        self.assertEqual(result['status'], 'expected_state_failed')
        self.assertEqual(result['state_findings'], [])
        self.assertFalse(all(result['automatic_checks']['expected_state'].values()))
        self.assertNotIn('copper token', result['candidate_state']['inventory'])
        self.assertIn('folded city map', result['candidate_state']['inventory'])
        self.assertEqual(len(result['attempts']), 2)
        travel = next(pair for pair in report['pairs'] if pair['case_id'] == 'authorized_travel')
        self.assertTrue(all(item['status'] == 'candidate_ready' for item in travel['arms']),
                        'Independent authored travel must not be blocked by pickup output.')

    def test_extractor_cannot_rewrite_fiction_or_return_a_third_attempt(self):
        def rewrite(document, phase, _case, _call):
            if phase == 'state_extraction':
                return {'narration': 'REWRITE CANARY', 'state_updates': {}}
            return document
        respond = adapter(rewrite)
        report = self.evaluate(respond)
        for result in arms(report, 'narrator_only'):
            self.assertNotEqual(result['status'], 'candidate_ready')
            self.assertEqual(len(result['attempts']), 2)
            self.assertNotEqual(result['candidate_narration'], 'REWRITE CANARY')
            self.assertIsNone(result['candidate_state'])
            self.assertTrue(result['automatic_checks']['database_unchanged'])
        self.assertEqual(len(respond.calls), 9)

    def test_unsupported_travel_extraction_does_not_change_candidate_scene(self):
        def ungrounded(document, phase, case, _call):
            if phase == 'state_extraction' and case == 'authorized_travel':
                return {'state_updates': {'location': 'North Landing',
                                         'evidence': {'location': 'UNSUPPORTED EVIDENCE CANARY'}}}
            return document
        report = self.evaluate(adapter(ungrounded))
        pair = next(pair for pair in report['pairs'] if pair['case_id'] == 'authorized_travel')
        result = next(item for item in pair['arms'] if item['arm'] == 'narrator_only')
        self.assertNotEqual(result['status'], 'candidate_ready')
        self.assertTrue(result['state_findings'])
        self.assertIsNone(result['candidate_state'])
        self.assertEqual(result['candidate_narration'], CANONICAL['authorized_travel'][0])
        self.assertEqual(len(result['attempts']), 2)

    def test_extraction_receives_unchanged_prose_not_rejected_proposals(self):
        def wrong_rich_patch(document, phase, _case, _call):
            if phase == 'rich_narration':
                document['state_updates'] = {'location': 'REJECTED_PATCH_CANARY',
                                             'evidence': {'location': 'REJECTED_EVIDENCE_CANARY'}}
            return document
        report = self.evaluate(adapter(wrong_rich_patch))
        for pair in report['pairs']:
            for result in pair['arms']:
                self.assertLessEqual(len(result['attempts']), 2)
                if result['attempts'][-1]['phase'] != 'state_extraction':
                    continue
                extraction = result['attempts'][-1]
                self.assertEqual(len(extraction['messages']), 2)
                data = json.loads(extraction['messages'][-1]['content'])
                self.assertEqual(data['provisional_narration'], CANONICAL[pair['case_id']][0])
                self.assertNotIn('REJECTED_PATCH_CANARY', json.dumps(extraction['messages']))
                self.assertNotIn('REJECTED_EVIDENCE_CANARY', json.dumps(extraction['messages']))

    def test_private_environment_data_is_never_read_or_written(self):
        with tempfile.TemporaryDirectory() as temporary:
            personal = Path(temporary) / 'private'
            personal.mkdir()
            files = {'storyforge.db': b'PRIVATE NON SQLITE CAMPAIGN CANARY',
                     'portrait.png': b'PRIVATE ART CANARY', 'settings.json': b'{"model":"PRIVATE MODEL"}'}
            for name, data in files.items():
                (personal / name).write_bytes(data)
            opened = []
            original_open = engine.open_db

            def disposable_only(path):
                self.assertNotIn(personal, Path(path).parents)
                opened.append(Path(path))
                return original_open(path)

            with patch.dict(os.environ, {'STORYFORGE_DB': str(personal / 'storyforge.db')}), \
                    patch.object(engine, 'open_db', side_effect=disposable_only), \
                    patch.object(engine, '_gm_evaluation_model_metadata') as metadata, \
                    patch('engine.urllib.request.urlopen') as network:
                report = self.evaluate()
            metadata.assert_not_called()
            network.assert_not_called()
            self.assertTrue(opened)
            self.assertTrue(all(not path.exists() for path in opened))
            self.assertEqual(files, {path.name: path.read_bytes() for path in personal.iterdir()})
            self.assertNotIn('PRIVATE', json.dumps(report))
        self.assertTrue(all(result['automatic_checks']['database_unchanged'] for result in arms(report)))

    def test_fixture_database_rejects_real_write_attempts_during_both_arms(self):
        connections = []
        original_open = engine.open_db
        valid = adapter()

        def capture(path):
            con = original_open(path)
            connections.append(con)
            return con

        def attempt_write(messages, model, *, timeout, response_schema):
            with self.assertRaises(sqlite3.DatabaseError):
                connections[-1].execute('DELETE FROM messages')
            return valid(messages, model, timeout=timeout, response_schema=response_schema)

        with patch.object(engine, 'open_db', side_effect=capture):
            report = self.evaluate(attempt_write)
        for result in arms(report):
            self.assertEqual(result['status'], 'preservation_failed')
            self.assertTrue(result['automatic_checks']['database_unchanged'])
            self.assertEqual(result['automatic_checks']['database_write_attempts'], len(result['attempts']))

    def test_model_candidates_never_call_storage_or_retry_entry_points(self):
        original_turn = engine.play_turn
        fixtures = []

        def fixture_only(*args, **kwargs):
            self.assertEqual(kwargs.get('model'), 'authored-synthetic-fixture')
            fixtures.append(kwargs['model'])
            return original_turn(*args, **kwargs)

        with patch.object(engine, 'play_turn', side_effect=fixture_only), \
                patch.object(engine, 'retry_message', side_effect=AssertionError('No candidate may be stored.')):
            report = self.evaluate()
        self.assertEqual(len(fixtures), 3)
        self.assertTrue(all(result['status'] == 'candidate_ready' for result in arms(report)))

    def test_second_call_uses_only_the_remaining_shared_deadline(self):
        clock = [1000.0]
        valid = adapter()

        def slow_response(messages, model, *, timeout, response_schema):
            raw = valid(messages, model, timeout=timeout, response_schema=response_schema)
            clock[0] += 61
            return raw

        with patch.object(protocol.time, 'monotonic', side_effect=lambda: clock[0]):
            report = self.evaluate(slow_response)
        for result in arms(report, 'narrator_only'):
            self.assertEqual(len(result['attempts']), 2)
            self.assertEqual(result['attempts'][0]['timeout_seconds'], 70)
            self.assertEqual(result['attempts'][1]['timeout_seconds'], 34)

    def test_exhausted_deadline_cannot_trigger_an_extra_extraction_call(self):
        clock = [1000.0]
        valid = adapter()

        def exceeded(messages, model, *, timeout, response_schema):
            raw = valid(messages, model, timeout=timeout, response_schema=response_schema)
            clock[0] += 96
            return raw

        with patch.object(protocol.time, 'monotonic', side_effect=lambda: clock[0]):
            report = self.evaluate(exceeded)
        for result in arms(report, 'narrator_only'):
            self.assertNotEqual(result['status'], 'candidate_ready')
            self.assertEqual([item['phase'] for item in result['attempts']], ['narration_only'])
            self.assertIsNone(result['candidate_state'])
        self.assertEqual(len(valid.calls), 6)

    def test_invalid_model_and_repeat_are_rejected_before_transport(self):
        respond = adapter()
        for models in ([], [''], ['bad model'], ['x' * 101]):
            with self.subTest(models=models), self.assertRaises(ValueError):
                protocol.evaluate_protocols(engine, models, chat=respond)
        for repeat in (0, 4, True, '2'):
            with self.subTest(repeat=repeat), self.assertRaises(ValueError):
                protocol.evaluate_protocols(engine, ['synthetic:14b'], repeat=repeat, chat=respond)
        self.assertEqual(respond.calls, [])


@unittest.skipUnless(builder is not None, 'Standalone protocol builder is repository-only.')
class ProtocolCheckBundleTests(unittest.TestCase):
    def make_installation(self, directory, *, version=None):
        installation = directory / 'installed'
        installation.mkdir()
        with zipfile.ZipFile(INSTALLED_PACKAGE) as archive:
            for name in ('engine.py', 'updater.py'):
                paths = [value for value in archive.namelist() if value == name or value.endswith('/' + name)]
                self.assertEqual(len(paths), 1)
                (installation / name).write_bytes(archive.read(paths[0]))
        if version:
            updater = installation / 'updater.py'
            updater.write_text(updater.read_text().replace('VERSION = "0.17.0"', 'VERSION = ' + repr(version)))
        data = installation / 'data'
        data.mkdir()
        (data / 'storyforge.db').write_bytes(b'PRIVATE NON-SQLITE SAVE CANARY')
        (data / 'portrait.png').write_bytes(b'PRIVATE ART CANARY')
        (data / 'settings.json').write_text('{"model":"PRIVATE SELECTED MODEL"}')
        return installation

    def invoke(self, artifact, installation, endpoint, *options):
        environment = dict(os.environ, OLLAMA_URL=endpoint,
                           STORYFORGE_DB=str(installation / 'data' / 'storyforge.db'))
        return subprocess.run([sys.executable, str(artifact), *options], cwd=installation,
                              env=environment, text=True, capture_output=True, timeout=30)

    def test_bundle_is_deterministic_and_only_adds_distinct_diagnostic_files(self):
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            first = builder.build(directory / 'one')
            second = builder.build(directory / 'two')
            self.assertEqual(first['sha256'], second['sha256'])
            with zipfile.ZipFile(first['bundle']) as archive:
                self.assertEqual(set(archive.namelist()), {'Storyforge-Protocol-Check.py',
                    'Run-Storyforge-Protocol-Check.cmd', 'README-Protocol-Check.txt'})
                source = archive.read('Storyforge-Protocol-Check.py').decode()
                compile(source, 'Storyforge-Protocol-Check.py', 'exec')
                self.assertIn('sys.dont_write_bytecode = True', source)
                self.assertNotIn('PRIVATE NON-SQLITE SAVE CANARY', source)
                self.assertIn(b'pause\r\n', archive.read('Run-Storyforge-Protocol-Check.cmd'))
                self.assertIn('not an application update', archive.read('README-Protocol-Check.txt').decode())
            self.assertEqual(hashlib.sha256(Path(first['bundle']).read_bytes()).hexdigest(), first['sha256'])

    @unittest.skipUnless(INSTALLED_PACKAGE.exists(), 'Immutable published v0.17.0 ZIP is a local artifact.')
    def test_actual_v0170_loopback_requests_preserve_installed_and_private_files(self):
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            builder.build(directory / 'helper')
            installation = self.make_installation(directory)
            before = {str(path.relative_to(installation)): path.read_bytes()
                      for path in installation.rglob('*') if path.is_file()}
            with local_protocol_ollama() as (endpoint, calls):
                result = self.invoke(directory / 'helper' / 'Storyforge-Protocol-Check.py',
                                     installation, endpoint, '--repeat', '1')
            self.assertEqual(result.returncode, 0, result.stdout[-2000:] + result.stderr)
            self.assertEqual(len(calls), 9)
            for call in calls:
                self.assertEqual(call['model'], 'ministral-3:14b')
                self.assertEqual(call['options'], {'temperature': 0.6, 'num_ctx': 8192, 'num_predict': 1050})
            reports = list((installation / 'data').glob('protocol-check-*.json'))
            self.assertEqual(len(reports), 1)
            report = json.loads(reports[0].read_text())
            self.assertEqual(report['storyforge_version'], '0.17.0')
            self.assertEqual(report['execution'], 'local_ollama')
            self.assertEqual(report['summary']['generation_requests'], 9)
            self.assertTrue(all(item['status'] == 'candidate_ready' for item in arms(report)))
            self.assertNotIn('PRIVATE', reports[0].read_text())
            for name, data in before.items():
                self.assertEqual((installation / name).read_bytes(), data)
            self.assertFalse(list(installation.rglob('*.pyc')))
            self.assertFalse((installation / 'server.py').exists())

    @unittest.skipUnless(INSTALLED_PACKAGE.exists(), 'Immutable published v0.17.0 ZIP is a local artifact.')
    def test_actual_http_rejections_write_complete_report_and_preserve_private_files(self):
        def unsafe_rich(document, phase, _case, _request):
            if phase == 'rich_narration':
                return {'narration': '[South Quay - Bellwater - Late afternoon]\n\n'
                        'You decide to attend the ceremony and hurry aboard.', 'state_updates': {}}
            return document

        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            builder.build(directory / 'helper')
            installation = self.make_installation(directory)
            before = {str(path.relative_to(installation)): path.read_bytes()
                      for path in installation.rglob('*') if path.is_file()}
            output = directory / 'complete-negative-report.json'
            with local_protocol_ollama(unsafe_rich) as (endpoint, calls):
                result = self.invoke(directory / 'helper' / 'Storyforge-Protocol-Check.py', installation,
                                     endpoint, '--repeat', '1', '--report', str(output))
            self.assertEqual(result.returncode, 1, result.stdout[-2000:] + result.stderr)
            self.assertEqual(len(calls), 12)
            report = json.loads(output.read_text())
            self.assertEqual(report['summary']['generation_requests'], 12)
            self.assertEqual(len(arms(report)), 6)
            self.assertTrue(all(item['status'] == 'candidate_ready' for item in arms(report, 'narrator_only')))
            for item in arms(report, 'rich'):
                self.assertEqual(item['status'], 'guardrail_rejected')
                self.assertEqual(len(item['rejected_reply_diagnostics']['attempts']), 2)
                self.assertIsNone(item['candidate_state'])
                self.assertTrue(item['automatic_checks']['database_unchanged'])
            for name, data in before.items():
                self.assertEqual((installation / name).read_bytes(), data)
            self.assertFalse(list(installation.rglob('*.pyc')))
            self.assertNotIn('PRIVATE', output.read_text())

    @unittest.skipUnless(INSTALLED_PACKAGE.exists(), 'Immutable published v0.17.0 ZIP is a local artifact.')
    def test_existing_report_is_refused_before_requests_or_overwrite(self):
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            builder.build(directory / 'helper')
            installation = self.make_installation(directory)
            output = directory / 'existing.json'
            output.write_text('KEEP EXISTING REPORT')
            with local_protocol_ollama() as (endpoint, calls):
                result = self.invoke(directory / 'helper' / 'Storyforge-Protocol-Check.py',
                                     installation, endpoint, '--report', str(output))
            self.assertEqual(result.returncode, 2)
            self.assertEqual(calls, [])
            self.assertEqual(output.read_text(), 'KEEP EXISTING REPORT')
            self.assertIn('existing report', result.stderr.lower())

    @unittest.skipUnless(INSTALLED_PACKAGE.exists(), 'Immutable published v0.17.0 ZIP is a local artifact.')
    def test_unsupported_installed_version_refuses_before_model_requests(self):
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            builder.build(directory / 'helper')
            installation = self.make_installation(directory, version='0.16.7')
            with local_protocol_ollama() as (endpoint, calls):
                result = self.invoke(directory / 'helper' / 'Storyforge-Protocol-Check.py', installation, endpoint)
            self.assertEqual(result.returncode, 2)
            self.assertEqual(calls, [])
            self.assertIn('0.17.0', result.stderr)

    @unittest.skipUnless(INSTALLED_PACKAGE.exists(), 'Immutable published v0.17.0 ZIP is a local artifact.')
    def test_cli_repeat_is_bounded_before_model_requests(self):
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            builder.build(directory / 'helper')
            installation = self.make_installation(directory)
            with local_protocol_ollama() as (endpoint, calls):
                result = self.invoke(directory / 'helper' / 'Storyforge-Protocol-Check.py',
                                     installation, endpoint, '--repeat', '4')
            self.assertEqual(result.returncode, 2)
            self.assertEqual(calls, [])
            self.assertFalse(list((installation / 'data').glob('protocol-check-*.json')))


if __name__ == '__main__':
    unittest.main()
