"""Synthetic production-path controls for redundant composite scene labels.

No personal campaign text or live inference is used. Consequential transitions
and player ownership remain strict even when a harmless location is omitted.
"""
import copy
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import engine


LABELS = {'location': 'Lantern Pier', 'parent_area': 'Greyhaven', 'time_of_day': 'Dusk'}
HEADER = '[Lantern Pier - Greyhaven - Dusk]'
INTRO = (HEADER + '\n\n'
         'A ferryman coils blue rope beside three empty mooring posts. '
         'Two dockworkers argue over a damaged fishing net near the warehouse door.')
BODY = ('Maribel locks the iron cabinet. A sealed parcel awaits collection. '
        'The courier places a cracked compass on the customs counter. '
        '"The sender paid in old copper," the courier tells the quartermaster.')
FRESH = HEADER + '\n\n' + BODY
REPLACEMENT = (HEADER + '\n\n'
               'A glass bead rolls from the parcel onto the scales. '
               'Maribel examines its tiny engraved lighthouse beneath a magnifying lens. '
               'The courier finds a second wax seal inside the wrapping.')
MOVE_BODY = ('At Harbour Archive in Greyhaven, a librarian opens a register. '
             'Night covers the harbour beyond the stained-glass windows. '
             'The librarian sets a copper lamp beside a water-stained chart.')
MOVE_NARRATION = '[Harbour Archive - Greyhaven - Night]\n\n' + MOVE_BODY
COMPOSITE = 'Lantern Pier - Customs awning - Greyhaven - Dusk'


def fact(text):
    return {'text': text, 'evidence': text}


class CompositeSceneRestatementsTests(unittest.TestCase):
    def setUp(self):
        directory = self.enterContext(tempfile.TemporaryDirectory())
        self.con = engine.open_db(Path(directory) / 'synthetic.db')
        self.addCleanup(self.con.close)
        world = engine.make_world(self.con, {
            'title': 'Harbour of Vale',
            'description': 'An original port tale about cargo disputes and lighthouse keepers.'})
        campaign = engine.new_campaign(self.con, {
            'world_id': world['id'], 'pc_name': 'Mira', 'aliases': 'Lady Willow',
            'pronouns': 'she/her', 'species': 'High Elf'})
        self.cid = campaign['id']
        self.prior_memory = {'summary': 'A ferryman guards the western mooring.',
                             'npcs': [], 'events': ['The lighthouse bell sounded twice.'],
                             'open_threads': ['A sealed letter awaits an answer.']}
        state = copy.deepcopy(campaign['state'])
        state.update(LABELS)
        state.update(inventory=['brass key'], journal=['A foghorn sounded beyond the quay.'],
                     scene_memory=copy.deepcopy(self.prior_memory))
        with self.con:
            self.con.execute('UPDATE campaigns SET state_json=? WHERE id=?', (json.dumps(state), self.cid))
            self.opening_id = self.con.execute(
                'INSERT INTO messages (campaign_id,role,content,created_at) VALUES (?,?,?,?)',
                (self.cid, 'gm', INTRO, engine.now())).lastrowid
            self.con.execute('INSERT INTO turn_checkpoints VALUES (?,?,?,?)',
                             (self.opening_id, json.dumps(state), json.dumps(state), '__START__'))

    def set_labels(self, **labels):
        state = engine.get_campaign(self.con, self.cid)['state']
        for field in LABELS:
            state.pop(field, None)
        state.update(labels)
        with self.con:
            self.con.execute('UPDATE campaigns SET state_json=? WHERE id=?', (json.dumps(state), self.cid))
            self.con.execute('UPDATE turn_checkpoints SET state_before=?,state_after=? WHERE gm_message_id=?',
                             (json.dumps(state), json.dumps(state), self.opening_id))

    def snapshot(self):
        return list(self.con.iterdump())

    def scripted(self, narration, changes):
        calls = []
        proposal = copy.deepcopy(changes)

        def chat(messages, model):
            self.assertEqual(model, 'ministral-3:14b')
            calls.append(copy.deepcopy(messages))
            return json.dumps({'narration': narration, 'state_updates': proposal})

        chat.requires_state_evidence = True
        return chat, calls, proposal

    def play(self, narration=FRESH, changes=None, action='I listen.'):
        changes = {'location': COMPOSITE} if changes is None else changes
        chat, calls, proposal = self.scripted(narration, changes)
        original = copy.deepcopy(proposal)
        result = engine.play_turn(self.con, self.cid, action,
                                  model='ministral-3:14b', chat=chat)
        self.assertEqual(len(calls), 1, 'A redundant label must not consume a correction.')
        self.assertEqual(proposal, original)
        return result

    def assert_labels(self, result, labels=None):
        self.assertEqual({field: result['state'].get(field) for field in LABELS}, labels or LABELS)

    def reject(self, narration=FRESH, changes=None):
        changes = {'location': COMPOSITE} if changes is None else changes
        before = self.snapshot()
        chat, calls, proposal = self.scripted(narration, changes)
        original = copy.deepcopy(proposal)
        with self.assertRaisesRegex(ValueError, 'Nothing was saved'):
            engine.play_turn(self.con, self.cid, 'I listen.',
                             model='ministral-3:14b', chat=chat)
        self.assertEqual(len(calls), 2)
        self.assertEqual(self.snapshot(), before)
        self.assertEqual(proposal, original)

    def test_redundant_composite_with_subposition_keeps_canonical_scene(self):
        result = self.play()
        self.assert_labels(result)
        self.assertEqual(result['narration'], FRESH)
        self.assertNotIn(COMPOSITE, json.dumps(result['state']))
        self.assertEqual(result['state']['inventory'], ['brass key'])
        self.assertEqual(result['state']['scene_memory'], self.prior_memory)

    def test_plain_three_component_restatement_needs_no_new_evidence(self):
        result = self.play(changes={'location': 'Lantern Pier - Greyhaven - Dusk'})
        self.assert_labels(result)

    def test_unsupported_composite_evidence_is_disposable_with_its_restatement(self):
        result = self.play(changes={'location': COMPOSITE,
                                    'evidence': {'location': 'An unnecessary unquoted location note.'}})
        self.assert_labels(result)

    def test_valid_journal_and_memory_siblings_survive_location_omission(self):
        observed = 'Maribel locks the iron cabinet.'
        result = self.play(changes={
            'location': COMPOSITE, 'journal_entry': observed,
            'evidence': {'location': 'An unsupported restatement.', 'journal_entry': observed},
            'scene_memory': {'summary': fact(observed), 'events': [fact(observed)],
                             'open_threads': [fact('A sealed parcel awaits collection.')]}})
        self.assert_labels(result)
        self.assertEqual(result['state']['journal'][-1], observed)
        self.assertEqual(result['state']['scene_memory']['summary'], observed)
        self.assertEqual(result['state']['scene_memory']['events'],
                         self.prior_memory['events'] + [observed])
        self.assertEqual(result['state']['scene_memory']['open_threads'],
                         self.prior_memory['open_threads'] + ['A sealed parcel awaits collection.'])

    def test_decoded_source_patch_is_not_mutated_by_normalization(self):
        changes = {'location': COMPOSITE, 'evidence': {'location': 'An unsupported restatement.'},
                   'scene_memory': {'events': [fact('Maribel locks the iron cabinet.')]}}
        original = copy.deepcopy(changes)
        with patch.object(engine, 'parse_gm_response', return_value=(FRESH, changes)):
            result = self.play(changes=changes)
        self.assertEqual(changes, original)
        self.assert_labels(result)

    def test_unknown_location_cannot_be_inferred_from_composite(self):
        self.set_labels(location='Unknown', parent_area='Greyhaven', time_of_day='Dusk')
        self.reject()

    def test_unknown_sibling_fields_stay_unknown_without_header_only_inference(self):
        self.set_labels(location='Lantern Pier')
        result = self.play()
        self.assertEqual(result['state']['location'], 'Lantern Pier')
        self.assertNotIn('parent_area', result['state'])
        self.assertNotIn('time_of_day', result['state'])
        # A later turn also cannot promote those presentation-only labels.
        second = self.play(REPLACEMENT, {})
        self.assertNotIn('parent_area', second['state'])
        self.assertNotIn('time_of_day', second['state'])

    def test_one_unknown_sibling_does_not_hide_a_known_sibling_mismatch(self):
        self.set_labels(location='Lantern Pier', parent_area='Greyhaven')
        self.reject('[Lantern Pier - Northbank - Dusk]\n\n' + BODY,
                    {'location': 'Lantern Pier - Customs awning - Northbank - Dusk'})

    def test_absent_three_part_header_cannot_authorize_composite_omission(self):
        self.reject(BODY)

    def test_changed_header_location_is_not_redundant(self):
        self.reject('[Harbour Archive - Greyhaven - Dusk]\n\n' + BODY)

    def test_changed_header_parent_is_not_redundant(self):
        self.reject('[Lantern Pier - Northbank - Dusk]\n\n' + BODY,
                    {'location': 'Lantern Pier - Customs awning - Northbank - Dusk'})

    def test_changed_header_time_is_not_redundant(self):
        self.reject('[Lantern Pier - Greyhaven - Midnight]\n\n' + BODY,
                    {'location': 'Lantern Pier - Customs awning - Greyhaven - Midnight'})

    def test_composite_terminal_components_must_match_the_displayed_header(self):
        for composite in ('Lantern Pier - Customs awning - Northbank - Dusk',
                          'Lantern Pier - Customs awning - Greyhaven - Midnight'):
            with self.subTest(composite=composite):
                self.reject(changes={'location': composite})

    def test_location_prefix_must_be_the_whole_established_label(self):
        self.reject(changes={'location': 'Lantern Pier Annex - Greyhaven - Dusk'})

    def test_serialized_evidence_object_is_not_a_redundant_location(self):
        self.reject(changes={'location': json.dumps({'location': COMPOSITE})})

    def test_hidden_player_behavior_in_composite_still_rejects(self):
        for action in ('Mira decides to accept the contract', 'Lady Willow smiles',
                       'You walk to the warehouse'):
            with self.subTest(action=action):
                self.reject(changes={'location': 'Lantern Pier - ' + action + ' - Greyhaven - Dusk'})

    def test_narrated_player_behavior_still_rejects_with_redundant_location(self):
        self.reject(FRESH + '\n\nMira decides to accept the contract.')

    def test_real_parent_time_and_inventory_changes_still_need_visible_evidence(self):
        for extra in ({'parent_area': 'Northbank'}, {'time_of_day': 'Midnight'},
                      {'inventory_add': ['ruby seal']}, {'inventory_remove': ['brass key']}):
            with self.subTest(extra=extra):
                self.reject(changes={'location': COMPOSITE, **extra})

    def test_supported_actual_move_still_changes_canonical_location(self):
        result = self.play(MOVE_NARRATION, {
            'location': 'Harbour Archive', 'time_of_day': 'Night',
            'evidence': {'location': MOVE_BODY.split('. ', 1)[0] + '.',
                         'time_of_day': 'Night covers the harbour beyond the stained-glass windows.'}},
            action='I walk to Harbour Archive.')
        self.assert_labels(result, {**LABELS, 'location': 'Harbour Archive', 'time_of_day': 'Night'})

    def test_retry_uses_original_checkpoint_and_preserves_one_authored_action(self):
        first = self.play(changes={})
        target = first['messages'][-1]['id']
        player = first['messages'][-2]
        later = self.play(MOVE_NARRATION, {
            'location': 'Harbour Archive', 'time_of_day': 'Night',
            'evidence': {'location': MOVE_BODY.split('. ', 1)[0] + '.',
                         'time_of_day': 'Night covers the harbour beyond the stained-glass windows.'}},
            action='I walk to Harbour Archive.')
        later_gm = later['messages'][-1]['id']
        changes = {'location': COMPOSITE,
                   'scene_memory': {'events': [fact('A glass bead rolls from the parcel onto the scales.')]}}
        chat, calls, proposal = self.scripted(REPLACEMENT, changes)
        original = copy.deepcopy(proposal)
        result = engine.retry_message(self.con, self.cid, target,
                                      feedback='Keep the original scene and leave my choices open.',
                                      model='ministral-3:14b', chat=chat)
        self.assertEqual(len(calls), 1)
        self.assertEqual(proposal, original)
        self.assert_labels(result)
        self.assertEqual([message['role'] for message in result['messages']], ['gm', 'player', 'gm'])
        self.assertEqual(result['messages'][1]['id'], player['id'])
        self.assertEqual(result['messages'][1]['content'], 'I listen.')
        self.assertNotIn('Harbour Archive', json.dumps(result['state']))
        self.assertNotIn(MOVE_BODY, '\n'.join(message['content'] for message in result['messages']))
        checkpoint = self.con.execute('SELECT * FROM turn_checkpoints WHERE gm_message_id=?',
                                      (result['messages'][-1]['id'],)).fetchone()
        self.assertEqual(checkpoint['source_action'], 'I listen.')
        self.assertEqual(json.loads(checkpoint['state_before'])['location'], 'Lantern Pier')
        self.assertEqual(json.loads(checkpoint['state_after']), result['state'])
        self.assertIsNone(self.con.execute('SELECT 1 FROM turn_checkpoints WHERE gm_message_id IN (?,?)',
                                          (target, later_gm)).fetchone())
        self.assertNotIn('Harbour Archive', '\n'.join(message['content'] for message in calls[0]))

    def test_failed_retry_cannot_omit_a_real_location_change_or_mutate_any_rows(self):
        first = self.play(changes={})
        target = first['messages'][-1]['id']
        before = self.snapshot()
        chat, calls, proposal = self.scripted(REPLACEMENT, {'location': 'Harbour Archive - Greyhaven - Dusk'})
        original = copy.deepcopy(proposal)
        with self.assertRaisesRegex(ValueError, 'Nothing was saved'):
            engine.retry_message(self.con, self.cid, target,
                                 feedback='Keep the original scene.', model='ministral-3:14b', chat=chat)
        self.assertEqual(len(calls), 2)
        self.assertEqual(proposal, original)
        self.assertEqual(self.snapshot(), before)


if __name__ == '__main__':
    unittest.main()
