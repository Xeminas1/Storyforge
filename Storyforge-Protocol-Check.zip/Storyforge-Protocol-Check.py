"""Standalone local protocol comparison; never installs an application update.

Each authored snapshot is independent. Generated prose and state are reviewed
in memory, with the disposable fixture database locked against writes. This is
an unseeded engineering comparison, not a narrative-quality score.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import logging
import re
import sqlite3
import sys
import tempfile
import threading
import time
import uuid
from contextlib import contextmanager
from pathlib import Path
from unittest.mock import patch

sys.dont_write_bytecode = True

NARRATION_SCHEMA = {
    'type': 'object',
    'properties': {'narration': {'type': 'string', 'minLength': 1, 'maxLength': 12000}},
    'required': ['narration'],
    'additionalProperties': False,
}

NARRATOR_CONTRACT = '''RESPONSE CONTRACT:
- Return ONLY JSON with one narration:string field. Start narration with one [Location - Parent Area - Time of Day] header, blank line, then prose. Use established places/time, no invented clock.
- Aim for 120–220 words in two or three focused paragraphs. Show notices, letters and signs in full in *italics*; shouted speech uses **bold**. No other decorative markup or code fences.
- Write the immediate visible consequence of the submitted action and NPC/world activity. Keep actual place, inventory and time consequences visible in the prose, without adding player behavior. Do not supply state updates, evidence quotes or memory notes.
- Context selects saved records; omitted details remain saved. Do not invent missing rules, facts or outcomes. The final user message contains the action once; retry feedback is guidance, not fiction.
'''

REQUIRED_APIS = ('build_gm_context', '_generate_turn', '_FOCUSED_GM_POLICY',
    '_gm_continuity_fixture', 'gm_continuity_cases', '_state_repair_context',
    '_review_gm_turn', '_validate_model_structure', '_parse_gm_state_response',
    'GM_RESPONSE_SCHEMA', 'GM_STATE_RESPONSE_SCHEMA', 'GM_TURN_BUDGET',
    'GM_CONTEXT_BYTE_LIMIT', 'ollama_chat', 'apply_patch', '_merge_scene_memory',
    '_gm_evaluation_model_metadata')


def _json(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'))


def _digest(value):
    return hashlib.sha256(_json(value).encode('utf-8')).hexdigest()


def require_installation(engine, version):
    match = re.fullmatch(r'(\d+)\.(\d+)\.(\d+)', str(version))
    if not match or tuple(map(int, match.groups())) < (0, 17, 0):
        raise ValueError('This diagnostic requires Storyforge v0.17.0 or newer. No application files were changed.')
    missing = [name for name in REQUIRED_APIS if not hasattr(engine, name)]
    if missing or '\nRESPONSE CONTRACT:\n' not in engine._FOCUSED_GM_POLICY:
        raise ValueError('This installation lacks the supported v0.17.0 protocol APIs. No requests were sent.')
    if getattr(engine.ollama_chat, 'supports_response_schema', False) is not True:
        raise ValueError('This diagnostic requires the native local structured Ollama transport.')


def _models(models, repeat):
    if isinstance(models, str):
        models = [models]
    if (not isinstance(models, list) or not 1 <= len(models) <= 5
            or any(not isinstance(model, str) or not re.fullmatch(
                r'[A-Za-z0-9][A-Za-z0-9._:/-]{0,99}', model) for model in models)):
        raise ValueError('Choose 1–5 installed local model names, each up to 100 characters.')
    if isinstance(repeat, bool) or not isinstance(repeat, int) or not 1 <= repeat <= 3:
        raise ValueError('Repeat must be an integer from 1 to 3.')
    return list(dict.fromkeys(models))


def _contracts(engine, context):
    """Change the contract only; retain exact selected facts/history/action."""
    messages = copy.deepcopy(context['messages'])
    policy = engine._FOCUSED_GM_POLICY
    if not messages or not messages[0]['content'].startswith(policy):
        raise ValueError('The installed prompt layout differs from the supported protocol; no requests were sent.')
    common, _ = policy.split('RESPONSE CONTRACT:\n', 1)
    suffix = messages[0]['content'][len(policy):]
    facts = {'system_suffix': suffix, 'history_and_action': copy.deepcopy(messages[1:]),
             'resolved_state': copy.deepcopy(context['resolved_state'])}
    narration_messages = copy.deepcopy(messages)
    narration_messages[0]['content'] = common + NARRATOR_CONTRACT + suffix
    return messages, narration_messages, facts


@contextmanager
def _numeric_metrics(engine):
    """Capture numeric transport diagnostics without changing private logging."""
    rows = []
    owner = threading.get_ident()
    logger = logging.getLogger('engine.ollama')
    previous_level = logger.level
    handler = logging.Handler()

    def collect(record):
        if record.thread == owner and record.getMessage().startswith('Ollama request '):
            try:
                rows.append(json.loads(record.getMessage().split('Ollama request ', 1)[1]))
            except (ValueError, TypeError):
                pass

    handler.emit = collect
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)
    try:
        yield rows
    finally:
        logger.removeHandler(handler)
        logger.setLevel(previous_level)


def _expected_state(engine, state, case):
    inventory = {engine._evidence_text(item) for item in state.get('inventory', []) if isinstance(item, str)}
    return {'expected_location': engine._evidence_text(state.get('location', '')) == engine._evidence_text(case['location']),
            'expected_parent_area': engine._evidence_text(state.get('parent_area', '')) == 'bellwater',
            'existing_city_map_retained': 'folded city map' in inventory,
            'expected_token_possession': ('copper token' in inventory) == case['token']}


def _review_narration(engine, narration, campaign, action, prior):
    # State/heading consistency awaits extraction; prose ownership never does.
    review = engine._review_gm_turn(narration, {}, campaign['state'], campaign['pc_name'], action,
        prior, world_title='Synthetic Bellwater Crossing', require_evidence=True,
        pc_profile=campaign['pc_profile'])
    return list(review.narrative_violations)


def _candidate(engine, campaign, action, updates):
    state = engine.apply_patch(copy.deepcopy(campaign['state']), copy.deepcopy(updates), action)
    if updates.get('scene_memory'):
        state['scene_memory'] = engine._merge_scene_memory(
            campaign['state'].get('scene_memory', {}), updates['scene_memory'])
    return state


def _annotate_attempts(engine, result, campaign, world, case, prior, base):
    """Separate typed findings in the report; never feed drafts back to a model."""
    narration = None
    for row in result['attempts']:
        if not row.get('response'):
            continue
        try:
            if row['phase'] == 'rich_narration':
                narration, updates = engine.parse_gm_response(row['response'])
            elif row['phase'] == 'narration_only':
                document = json.loads(row['response'])
                engine._validate_model_structure(document, NARRATION_SCHEMA)
                narration = engine.preserve_narrative_emphasis(engine.clean(document['narration'], 12000))
                updates = {}
            else:
                updates = engine._parse_gm_state_response(row['response'])
            if narration is None:
                continue
            review = engine._review_gm_turn(narration, updates, base, campaign['pc_name'],
                case['action'], prior, world_title=world['title'], require_evidence=True,
                pc_profile=campaign['pc_profile'])
            row['narrative_findings'] = list(review.narrative_violations)
            # A changed narrator heading awaits extraction; its intermediate
            # state finding is not a verdict on the completed candidate.
            row['state_findings'] = list(review.state_violations)
            row['state_review_provisional'] = row['phase'] == 'narration_only'
            row['omitted_optional_updates'] = review.omitted
        except (ValueError, TypeError, KeyError) as exc:
            row['review_format_error'] = str(exc)[:1500]


def _run_arm(engine, con, campaign, world, case, prior, context, messages,
             arm, model, transport, metrics):
    contract_policy = (engine._FOCUSED_GM_POLICY if arm == 'rich' else
        engine._FOCUSED_GM_POLICY.split('RESPONSE CONTRACT:\n', 1)[0] + NARRATOR_CONTRACT)
    result = {'arm': arm, 'status': 'not_run', 'attempts': [], 'candidate_narration': None,
        'candidate_state': None, 'narrative_findings': [], 'state_findings': [],
        'omitted_optional_updates': {}, 'automatic_checks': {},
        'manual_review': {'status': 'pending', 'questions': case['review']},
        'initial_messages_sha256': _digest(messages),
        'initial_contract_sha256': _digest({'policy': contract_policy,
            'schema': engine.GM_RESPONSE_SCHEMA if arm == 'rich' else NARRATION_SCHEMA})}
    started = time.monotonic()

    def request(request_messages, selected_model, *, timeout=70, response_schema=None):
        remaining = engine.GM_TURN_BUDGET - (time.monotonic() - started)
        if len(result['attempts']) >= 2 or remaining < 1:
            raise RuntimeError('The comparison arm exhausted its two-call or 95-second budget.')
        if sum(len(message['content'].encode('utf-8')) for message in request_messages) > engine.GM_CONTEXT_BYTE_LIMIT:
            raise ValueError('The comparison request exceeds the unchanged local context limit.')
        properties = response_schema.get('properties', {}) if isinstance(response_schema, dict) else {}
        phase = ('state_extraction' if 'narration' not in properties else
                 'rich_narration' if 'state_updates' in properties else 'narration_only')
        row = {'number': len(result['attempts']) + 1, 'phase': phase,
            'messages': copy.deepcopy(request_messages), 'response_schema': copy.deepcopy(response_schema),
            'timeout_seconds': min(70, timeout, remaining)}
        result['attempts'].append(row)
        offset = len(metrics)
        call_started = time.monotonic()
        try:
            raw = transport(request_messages, selected_model, timeout=row['timeout_seconds'],
                            response_schema=response_schema)
            row.update(status='response_received', response=raw[:20000] if isinstance(raw, str) else None,
                       response_truncated=isinstance(raw, str) and len(raw) > 20000)
            # Keep responses within the same model envelope limits even for an
            # explicitly injected offline test adapter.
            if not isinstance(raw, str) or len(raw) > 20000:
                raise ValueError('The model returned an invalid or oversized response.')
            return raw
        except Exception as exc:
            row.update(status='request_failed', error_type=type(exc).__name__, error=str(exc)[:1500])
            raise
        finally:
            row['wall_ms'] = round((time.monotonic() - call_started) * 1000, 2)
            row['diagnostics'] = copy.deepcopy(metrics[offset:])

    request.supports_timeout = True
    request.supports_response_schema = True
    request.requires_state_evidence = True
    try:
        if arm == 'rich':
            frozen = copy.deepcopy(context)
            frozen['messages'] = copy.deepcopy(messages)
            # This is a single-process diagnostic. Restore the module binding
            # even on failure; no source file or installed setting is written.
            with patch.object(engine, 'build_gm_context', return_value=frozen):
                narration, state = engine._generate_turn(con, campaign, world, case['action'],
                    prior, copy.deepcopy(campaign['state']), model=model, chat=request)
            result.update(status='candidate_ready', candidate_narration=narration, candidate_state=state)
            # Accepted raw rich prose stays in attempts; rendering may supply a
            # canonical display heading. Never present that as a fresh draft.
        else:
            raw = request(messages, model, response_schema=NARRATION_SCHEMA)
            document = json.loads(raw)
            engine._validate_model_structure(document, NARRATION_SCHEMA)
            narration = engine.preserve_narrative_emphasis(engine.clean(document['narration'], 12000))
            result['narration_presentation_normalized'] = narration != document['narration']
            if not narration.strip():
                raise ValueError('The narrator returned empty prose.')
            result['candidate_narration'] = narration
            findings = _review_narration(engine, narration, campaign, case['action'], prior)
            result['narrative_findings'] = findings
            if findings:
                result['status'] = 'narrative_rejected'
                return result
            extraction_messages = engine._state_repair_context(campaign, world, case['action'],
                narration, context['resolved_state'], [])
            raw_state = request(extraction_messages, model, response_schema=engine.GM_STATE_RESPONSE_SCHEMA)
            updates = engine._parse_gm_state_response(raw_state)
            # Narrator-only has no initial patch from which to derive current
            # production critical obligations. Expected fixture checks below
            # expose missing token/travel extraction; do not infer missing facts.
            review = engine._review_gm_turn(narration, updates, context['resolved_state'],
                campaign['pc_name'], case['action'], prior, world_title=world['title'],
                require_evidence=True, pc_profile=campaign['pc_profile'])
            result['narrative_findings'] = list(review.narrative_violations)
            result['state_findings'] = list(review.state_violations)
            result['omitted_optional_updates'] = review.omitted
            if review.violations:
                result['status'] = 'state_rejected'
                return result
            resolved_campaign = {**campaign, 'state': context['resolved_state']}
            result.update(status='candidate_ready', candidate_state=_candidate(
                engine, resolved_campaign, case['action'], review.updates))
        checks = _expected_state(engine, result['candidate_state'], case)
        result['automatic_checks']['expected_state'] = checks
        if not all(checks.values()):
            result['status'] = 'expected_state_failed'
    except Exception as exc:
        result.update(status='guardrail_rejected' if isinstance(exc, engine.GMReplyRejected)
            else 'invalid_response' if isinstance(exc, (ValueError, json.JSONDecodeError))
            else 'request_or_pipeline_failed', error_type=type(exc).__name__, error=str(exc)[:1500])
        if isinstance(exc, engine.GMReplyRejected):
            result['rejected_reply_diagnostics'] = copy.deepcopy(exc.diagnostics)
            for attempt in exc.diagnostics.get('attempts', []):
                narrative = _review_narration(engine, attempt.get('narration', ''),
                    campaign, case['action'], prior)
                result['narrative_findings'].extend(narrative)
                result['state_findings'].extend(value for value in attempt.get('violations', [])
                    if value not in narrative)
    finally:
        _annotate_attempts(engine, result, campaign, world, case, prior, context['resolved_state'])
        result['wall_ms'] = round((time.monotonic() - started) * 1000, 2)
    return result


def evaluate_protocols(engine, models, repeat=2, *, chat=None, progress=None):
    """Compare protocols on independent frozen snapshots, never personal saves."""
    models = _models(models, repeat)
    if chat is not None and not callable(chat):
        raise ValueError('The offline test adapter must be callable.')
    transport = engine.ollama_chat if chat is None else chat
    case_ids = ('approach_without_boarding', 'token_pickup', 'authorized_travel')
    cases = [case for case in engine.gm_continuity_cases() if case['id'] in case_ids]
    if {case['id'] for case in cases} != set(case_ids):
        raise ValueError('This installation lacks the expected authored synthetic cases.')
    report = {'schema': 'storyforge.local-gm-protocol-comparison', 'schema_version': 1,
        'created_at': engine.now(), 'execution': 'offline_test_adapter' if chat else 'local_ollama',
        'models': models, 'repeat': repeat, 'manual_review_required': True, 'cases': copy.deepcopy(cases),
        'notice': 'Unseeded engineering comparison of different output contracts with identical selected factual context. '
            'Snapshots are independent, not connected continuity. Automatic acceptance does not prove player agency, '
            'canon, prose quality or parity with another product. No generated candidate is saved.',
        'limitations': ['The narrator-only arm always needs extraction and has no remaining narrative rewrite call.',
            'Narrator-only lacks initial rich-patch critical obligations; explicit expected-state checks detect tested '
            'inventory/travel omissions but do not establish general semantic equivalence.',
            'Two total calls and the shared 95-second arm budget remain; native socket deadlines are approximate.'],
        'limits': {'maximum_calls_per_arm': 2, 'arm_budget_seconds': engine.GM_TURN_BUDGET,
            'socket_timeout_seconds': 70, 'message_bytes': engine.GM_CONTEXT_BYTE_LIMIT,
            'maximum_generation_requests': len(models) * repeat * len(cases) * 4},
        'sampling': {'generic_default_temperature': 0.6, 'num_ctx': 8192, 'num_predict': 1050,
            'settings_source': 'unchanged installed engine.ollama_chat; model-specific overrides can apply',
            'seed': 'not set; native installed transport settings including model-specific overrides apply'},
        'model_metadata': {}, 'pairs': []}
    sequence = 0
    with _numeric_metrics(engine) as metrics, tempfile.TemporaryDirectory(prefix='storyforge-protocol-check-') as temporary:
        for model in models:
            report['model_metadata'][model] = ({'status': 'skipped_offline_adapter'} if chat
                else engine._gm_evaluation_model_metadata(model))
            for repetition in range(1, repeat + 1):
                for case in cases:
                    con = engine.open_db(Path(temporary) / (uuid.uuid4().hex + '.db'))
                    try:
                        # Authored setup is the only fixture write. All model
                        # calls below run after SQLite query_only and authorizer.
                        campaign = engine._gm_continuity_fixture(con)
                        world = engine.get_world(con, campaign['world_id'])
                        prior = engine.get_messages(con, campaign['id'])
                        context = engine.build_gm_context(con, campaign, world, case['action'], prior, campaign['state'])
                        rich_messages, narrator_messages, facts = _contracts(engine, context)
                        snapshot = list(con.iterdump())
                        con.execute('PRAGMA query_only=ON')
                        write_attempts = []
                        write_actions = {getattr(sqlite3, name) for name in (
                            'SQLITE_INSERT', 'SQLITE_UPDATE', 'SQLITE_DELETE', 'SQLITE_ALTER_TABLE',
                            'SQLITE_CREATE_INDEX', 'SQLITE_CREATE_TABLE', 'SQLITE_CREATE_TRIGGER',
                            'SQLITE_CREATE_VIEW', 'SQLITE_DROP_INDEX', 'SQLITE_DROP_TABLE',
                            'SQLITE_DROP_TRIGGER', 'SQLITE_DROP_VIEW')}

                        def readonly(action, name, _column, _database, _source):
                            if action in write_actions:
                                write_attempts.append(action)
                                return sqlite3.SQLITE_DENY
                            return sqlite3.SQLITE_OK

                        con.set_authorizer(readonly)
                        order = ['rich', 'narrator_only'] if sequence % 2 == 0 else ['narrator_only', 'rich']
                        sequence += 1
                        pair = {'model': model, 'repeat': repetition, 'case_id': case['id'], 'order': order,
                            'input': {'action': case['action'], 'canonical_state': copy.deepcopy(campaign['state']),
                                      'authored_history': copy.deepcopy(prior)},
                            'factual_context_sha256': _digest(facts), 'factual_context': facts,
                            'context_measurements': context['context'], 'arms': []}
                        report['pairs'].append(pair)
                        for arm in order:
                            if progress:
                                progress(f'{model}: {case["id"]}, repeat {repetition}/{repeat}, {arm}')
                            writes_before = len(write_attempts)
                            result = _run_arm(engine, con, campaign, world, case, prior, context,
                                rich_messages if arm == 'rich' else narrator_messages, arm, model, transport, metrics)
                            result['factual_context_sha256'] = pair['factual_context_sha256']
                            result['automatic_checks'].update(database_unchanged=snapshot == list(con.iterdump()),
                                database_write_attempts=len(write_attempts) - writes_before)
                            if (not result['automatic_checks']['database_unchanged']
                                    or result['automatic_checks']['database_write_attempts']):
                                result['status'] = 'preservation_failed'
                            pair['arms'].append(result)
                            if progress:
                                progress(f'  {result["status"]}; {result["wall_ms"] / 1000:.2f}s; manual review pending')
                    finally:
                        con.close()
    arms = [arm for pair in report['pairs'] for arm in pair['arms']]
    report['summary'] = {'pairs': len(report['pairs']), 'arms': len(arms),
        'candidate_ready': sum(arm['status'] == 'candidate_ready' for arm in arms),
        'other_outcomes': sum(arm['status'] != 'candidate_ready' for arm in arms),
        'generation_requests': sum(len(arm['attempts']) for arm in arms),
        'manual_reviews_pending': len(arms)}
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description='Compare local GM contracts on frozen synthetic snapshots. '
        'No app update, personal campaigns, model downloads or services are opened.')
    parser.add_argument('--model', action='append', help='Installed local Ollama model; repeat for comparison.')
    parser.add_argument('--repeat', type=int, default=2, help='Unseeded repetitions from 1 to 3 (default: 2).')
    parser.add_argument('--report', type=Path, help='New JSON report; existing files are refused.')
    parser.add_argument('--storyforge-dir', type=Path, help='Installation containing engine.py and updater.py.')
    args = parser.parse_args(argv)
    try:
        models = _models(args.model or ['ministral-3:14b'], args.repeat)
        if args.report is not None and (args.report.suffix.lower() != '.json'
                or args.report.exists() or args.report.is_symlink()):
            raise ValueError('Report must be a NEW .json file; an existing report is never overwritten.')
        script = Path(__file__).resolve()
        candidates = [args.storyforge_dir] if args.storyforge_dir is not None else [Path.cwd(), script.parent]
        if args.storyforge_dir is None and script.name == 'protocol_check.py' and script.parent.name == 'tools':
            candidates.append(script.parent.parent)
        installation = next((candidate.resolve() for candidate in candidates
            if candidate is not None and (candidate / 'engine.py').is_file() and (candidate / 'updater.py').is_file()), None)
        if installation is None:
            raise ValueError('Extract the helper beside Storyforge engine.py or supply --storyforge-dir.')
        destination = args.report or installation / 'data' / ('protocol-check-' + time.strftime('%Y%m%d-%H%M%S')
            + '-' + uuid.uuid4().hex[:8] + '.json')
        if destination.exists() or destination.is_symlink():
            raise ValueError('Report already exists. Choose a new filename.')
        sys.path.insert(0, str(installation))
        import engine
        import updater
        if Path(engine.__file__).resolve() != installation / 'engine.py':
            raise ValueError('A different engine is already imported; restart this standalone helper.')
        require_installation(engine, updater.VERSION)
        source_hashes = {name: hashlib.sha256((installation / name).read_bytes()).hexdigest()
            for name in ('engine.py', 'updater.py')}
        helper_hash = hashlib.sha256(script.read_bytes()).hexdigest()
        print('Comparing protocols with local Ollama and invented frozen snapshots.', flush=True)
        print('No application update or personal campaign is opened. Up to '
            + str(len(models) * args.repeat * 12) + ' requests; leave this window open.', flush=True)
        report = evaluate_protocols(engine, models, args.repeat,
            progress=lambda message: print(message, flush=True))
        report.update(storyforge_version=updater.VERSION,
            source_sha256=source_hashes,
            source_files_unchanged=all(hashlib.sha256((installation / name).read_bytes()).hexdigest() == digest
                for name, digest in source_hashes.items()),
            helper_sha256=helper_hash)
        destination.parent.mkdir(parents=True, exist_ok=True)
        with destination.open('x', encoding='utf-8') as output:
            json.dump(report, output, ensure_ascii=False, indent=2)
            output.write('\n')
        print('Report saved to ' + str(destination.resolve()), flush=True)
        print('Review raw prose and semantic findings separately from automatic state checks.', flush=True)
        return 0 if report['summary']['other_outcomes'] == 0 else 1
    except (ValueError, OSError) as exc:
        parser.error(str(exc))


if __name__ == '__main__':
    raise SystemExit(main())
