Storyforge protocol comparison

This is a diagnostic helper, not an application update. Do not install this ZIP
through Updates. Storyforge v0.17.0 or newer is required.

1. Extract Storyforge-Protocol-Check.py and Run-Storyforge-Protocol-Check.cmd
   beside Storyforge engine.py, usually in C:\Storyforge. These are new files;
   they replace no application source, settings, saves or previous checker.
2. Leave Ollama running with the already-installed ministral-3:14b model.
3. Double-click Run-Storyforge-Protocol-Check.cmd. Leave its window open. The
   default two repetitions of three independent snapshots use up to 24 model
   requests and may take several minutes. No model is downloaded.
4. Share the NEW data/protocol-check-*.json printed by the window. The report
   contains invented test-world context, raw model prose, state extraction,
   separate validation findings, model metadata and timings. No personal
   campaign, portrait, artwork or settings are read or changed.

The comparison keeps identical selected facts, history and actions, then changes
the requested output contract. One arm uses Storyforge's existing rich response;
the other requests narration first and extracts state from that unchanged prose.
Each arm has at most two calls and a shared approximately 95-second budget. A
rejected narrator draft receives no extraction or third rewrite call. Narrator
extraction can omit described critical facts; explicit fixture state checks and
manual review expose that gap, not infer missing facts into a save.

These are unseeded independent snapshots, not a connected campaign or a
scientific model benchmark. Review raw narration for player control, canon,
continuity and originality separately from automatic pipeline/state acceptance.
No candidate is committed to a campaign. Timing includes mandatory extraction
in the narrator-only arm; compare cold loading separately from warm requests.

Optional commands (from Storyforge's folder, only for already-installed models):
py Storyforge-Protocol-Check.py --repeat 1
py Storyforge-Protocol-Check.py --model ministral-3:14b --repeat 3
py Storyforge-Protocol-Check.py --report data/new-protocol-check.json

--model may be repeated (1–5 installed names); --repeat is 1–3.
--storyforge-dir C:\Storyforge selects an installation. Existing reports are
never overwritten. The helper calls only the installed local Ollama transport;
it does not start a server, updater, image generator or voice service. Remove
the two helper files afterwards if desired; keep reports for comparison.
