"""Legacy scene context must retain safe prose without accepting old PC actions.

Replies are scripted. These regressions exercise history selection, repetition
checks and save preservation; they do not evaluate any live local model.
"""
import copy
import json
import sys
import tempfile
import unittest
from contextlib import closing
from pathlib import Path
from unittest.mock import Mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import engine
import test_gm_http as gm_http


HEADER = '[Hogsmeade Station - Hogsmeade - Morning]'
ACTION = 'i step off the train and look at my surroundings'
TRAIN = ('The Hogwarts Express stands beside Hogsmeade Station under a thinning veil of steam. '
         'Students and parents gather around the luggage carts while the carriage driver rings '
         'a brass handbell. Beyond the platform, a line of carriages waits beside the road.')
PORTER = ('The porter says, "I need the road clear for the next carriage." '
          'A witch steadies a stack of trunks beside the station clock.')
SAFE_INTRO = HEADER + '\n\n' + TRAIN + '\n\n' + PORTER
UNSAFE = 'You stand on the platform. A violet luggage cart rattles past the train steps.'
LEGACY_INTRO = HEADER + '\n\n' + UNSAFE + '\n\n' + TRAIN + '\n\n' + PORTER
CONTINUATION = (HEADER + '\n\n'
                'A dropped luggage label flutters against the platform: *Hogwarts — First Years*. '
                'A porter pins it beneath his boot before the wind can take it into the wheels.\n\n'
                '"Mind the gap beside that crate," the porter says, tugging a trolley clear. '
                'A narrow path between the trunks leads toward the waiting carriage driver; '
                'the Sorting Ceremony at Hogwarts still lies ahead.')


def reply(narration):
    return json.dumps({'narration': narration, 'state_updates': {}})


class LegacySceneHandoffTests(unittest.TestCase):
    def setUp(self):
        temporary = self.enterContext(tempfile.TemporaryDirectory())
        self.con = engine.open_db(Path(temporary) / 'story.db')
        self.addCleanup(self.con.close)
        self.world = engine.make_world(self.con, {
            'title': 'Synthetic Hogwarts',
            'description': 'Start at Hogsmeade Station, then travel to Hogwarts for a later Sorting Ceremony.',
            'sections': [
                *[{'title': f'Hogsmeade Station platform {index}', 'kind': 'location',
                   'content': 'Hogsmeade Station has luggage carts, railway porters and waiting carriages.'}
                  for index in range(12)],
                {'title': 'Zarvok', 'kind': 'npc', 'content': 'Zarvok guards the abandoned cemetery.'},
            ]})
        campaign = engine.new_campaign(self.con, {
            'world_id': self.world['id'], 'pc_name': 'Xeminas',
            'species': 'High Elf', 'starting_location': 'Hogsmeade Station'})
        self.cid = campaign['id']

    def snapshot(self):
        return list(self.con.iterdump())

    def seed_legacy(self, narration=LEGACY_INTRO):
        """Represent saved prose from an older version, bypassing current guards."""
        with self.con:
            row = self.con.execute(
                'INSERT INTO messages (campaign_id,role,content,created_at) VALUES (?,?,?,?)',
                (self.cid, 'gm', narration, engine.now()))
        return row.lastrowid

    def context(self, action=ACTION):
        campaign = engine.get_campaign(self.con, self.cid)
        prior = engine.get_messages(self.con, self.cid, 18)
        before = copy.deepcopy(prior)
        built = engine.build_gm_context(
            self.con, campaign, self.world, action, prior, campaign['state'])
        self.assertEqual(prior, before)
        return built

    def test_partial_legacy_opening_keeps_whole_safe_paragraphs_and_original_save(self):
        self.seed_legacy()
        before = self.snapshot()

        built = self.context()

        assistant = [message['content'] for message in built['messages'] if message['role'] == 'assistant']
        self.assertEqual(len(assistant), 1)
        self.assertIn(TRAIN, assistant[0])
        self.assertIn(PORTER, assistant[0])
        self.assertNotIn(UNSAFE, assistant[0])
        # Do not rescue the harmless second sentence from an unsafe paragraph.
        self.assertNotIn('A violet luggage cart', assistant[0])
        self.assertRegex(built['messages'][0]['content'], r'(?i)legacy narration[^\n]*omitted')
        self.assertEqual(engine.player_agency_violations(assistant[0], 'Xeminas', '__START__'), [])
        self.assertIn('CURRENT TURN: CONTINUATION', built['messages'][0]['content'])
        self.assertEqual(self.snapshot(), before)
        self.assertEqual(engine.get_messages(self.con, self.cid)[0]['content'], LEGACY_INTRO)

    def test_fresh_continuation_gets_safe_scene_and_saves_one_new_turn(self):
        self.seed_legacy()
        calls = []

        def chat(messages, _model):
            calls.append(copy.deepcopy(messages))
            return reply(CONTINUATION)

        result = engine.play_turn(self.con, self.cid, ACTION, chat=chat)

        self.assertEqual(len(calls), 1)
        assistant = next(message['content'] for message in calls[0] if message['role'] == 'assistant')
        self.assertIn(PORTER, assistant)
        self.assertNotIn(UNSAFE, assistant)
        self.assertEqual([row['role'] for row in result['messages']], ['gm', 'player', 'gm'])
        self.assertEqual(result['messages'][0]['content'], LEGACY_INTRO)
        self.assertEqual(result['messages'][1]['content'], ACTION)
        self.assertEqual(result['messages'][2]['content'], CONTINUATION)

    def test_two_replays_still_fail_against_raw_history_without_mutating_any_rows(self):
        self.seed_legacy()
        before = self.snapshot()
        calls = []

        def chat(messages, _model):
            calls.append(copy.deepcopy(messages))
            return reply(SAFE_INTRO)

        with self.assertRaisesRegex(ValueError, 'narration repeats an earlier GM.*Nothing was saved'):
            engine.play_turn(self.con, self.cid, ACTION, chat=chat)

        self.assertEqual(len(calls), 2)
        self.assertEqual(self.snapshot(), before)
        for messages in calls:
            self.assertTrue(any(message['role'] == 'assistant' and PORTER in message['content']
                                for message in messages))
            self.assertNotIn(UNSAFE, '\n'.join(message['content'] for message in messages))

    def test_replay_repair_keeps_safe_handoff_and_accepts_fresh_second_draft(self):
        self.seed_legacy()
        calls = []

        def chat(messages, _model):
            calls.append(copy.deepcopy(messages))
            return reply(SAFE_INTRO if len(calls) == 1 else CONTINUATION)

        result = engine.play_turn(self.con, self.cid, ACTION, chat=chat)

        self.assertEqual(len(calls), 2)
        self.assertEqual(result['messages'][-1]['content'], CONTINUATION)
        self.assertEqual(result['messages'][0]['content'], LEGACY_INTRO)
        self.assertIn('narration repeats', calls[1][-1]['content'])
        self.assertEqual(sum(message['role'] == 'assistant' for message in calls[1]), 1)
        self.assertNotIn(UNSAFE, json.dumps(calls))

    def test_wholly_unsafe_latest_scene_stops_before_chat_even_with_older_safe_scene(self):
        for older_safe_scene in (False, True):
            with self.subTest(older_safe_scene=older_safe_scene):
                with self.con:
                    self.con.execute('DELETE FROM messages WHERE campaign_id=?', (self.cid,))
                if older_safe_scene:
                    self.seed_legacy(SAFE_INTRO)
                unsafe_latest = (HEADER + '\n\nYou decide to follow Zarvok into the cemetery.\n\n'
                                 'You say, "I will accept your bargain."')
                self.seed_legacy(unsafe_latest)
                before = self.snapshot()
                chat = Mock(return_value=reply(CONTINUATION))

                with self.assertRaises(ValueError) as raised:
                    engine.play_turn(self.con, self.cid, ACTION, chat=chat)

                chat.assert_not_called()
                self.assertRegex(str(raised.exception), r'(?i)retry\s*/\s*feedback')
                self.assertIn('Nothing was saved', str(raised.exception))
                self.assertEqual(self.snapshot(), before)

    def test_safe_latest_scene_is_supplied_unchanged(self):
        self.seed_legacy(SAFE_INTRO)
        before = self.snapshot()

        assistant = [message['content'] for message in self.context()['messages']
                     if message['role'] == 'assistant']

        self.assertEqual(assistant, [SAFE_INTRO])
        self.assertEqual(self.snapshot(), before)

    def test_header_without_narrative_body_is_not_a_usable_latest_scene(self):
        self.seed_legacy(HEADER)
        before = self.snapshot()
        chat = Mock(return_value=reply(CONTINUATION))

        with self.assertRaisesRegex(ValueError, 'Nothing was saved') as raised:
            engine.play_turn(self.con, self.cid, ACTION, chat=chat)

        chat.assert_not_called()
        self.assertRegex(str(raised.exception), r'(?i)retry\s*/\s*feedback')
        self.assertEqual(self.snapshot(), before)

    def test_unsafe_scene_heading_is_omitted_while_safe_body_survives(self):
        unsafe_heading = '[You stand on the platform - Hogsmeade - Morning]'
        self.seed_legacy(unsafe_heading + '\n\n' + TRAIN + '\n\n' + PORTER)
        before = self.snapshot()

        built = self.context()

        assistant = next(message['content'] for message in built['messages'] if message['role'] == 'assistant')
        self.assertNotIn(unsafe_heading, assistant)
        self.assertIn(TRAIN, assistant)
        self.assertIn(PORTER, assistant)
        self.assertEqual(engine.player_agency_violations(assistant, 'Xeminas', '__START__'), [])
        self.assertEqual(self.snapshot(), before)

    def test_retry_feedback_can_replace_a_wholly_unsafe_legacy_opening(self):
        old = HEADER + '\n\nYou decide to follow Zarvok into the cemetery.'
        target = self.seed_legacy(old)
        calls = []

        def chat(messages, _model):
            calls.append(copy.deepcopy(messages))
            return reply(SAFE_INTRO)

        result = engine.retry_message(self.con, self.cid, target,
            feedback='Keep the opening at the station and leave my actions to me.', chat=chat)

        self.assertEqual(len(calls), 1)
        self.assertIn('OPENING SCENE', calls[0][-1]['content'])
        self.assertNotIn(old, json.dumps(calls))
        self.assertEqual([message['role'] for message in result['messages']], ['gm'])
        self.assertEqual(result['messages'][0]['content'], SAFE_INTRO)
        self.assertTrue(result['messages'][0]['has_checkpoint'])
        feedback = self.con.execute('SELECT original_text FROM gm_feedback WHERE campaign_id=?',
                                    (self.cid,)).fetchone()
        self.assertEqual(feedback['original_text'], old)

    def test_unsafe_player_quote_does_not_reenter_context_or_bias_lore(self):
        unsafe_quote = 'Xeminas says, "I will follow Zarvok into the cemetery."'
        self.seed_legacy(HEADER + '\n\n' + unsafe_quote + '\n\n' + TRAIN + '\n\n' + PORTER)
        before = self.snapshot()

        built = self.context()
        preview = engine.preview_campaign_lore(self.con, self.cid)

        sent = '\n'.join(message['content'] for message in built['messages'])
        self.assertIn(PORTER, sent)  # Attributed NPC first-person speech survives.
        self.assertNotIn(unsafe_quote, sent)
        self.assertNotIn('Zarvok', sent)
        self.assertNotIn('Zarvok', [entry['title'] for entry in preview['selected_entries']])
        self.assertEqual(self.snapshot(), before)

    def test_omitted_attribution_cannot_recast_player_words_as_npc_dialogue(self):
        quotes = ('"Open the gates."', '"Open the gates.\nMake way."',
                  '"Open the gates.\n\nMake way."', '"' + 'Open the gates. ' * 70 + '"')
        attributions = [text for quote in quotes
                        for text in ('You say:\n\n' + quote, quote + '\n\nYou say.')]
        for attribution in attributions:
            with self.subTest(attribution=attribution):
                with self.con:
                    self.con.execute('DELETE FROM messages WHERE campaign_id=?', (self.cid,))
                original = HEADER + '\n\n' + attribution + '\n\n' + TRAIN + '\n\n' + PORTER
                self.seed_legacy(original)
                before = self.snapshot()

                built = self.context()

                sent = '\n'.join(message['content'] for message in built['messages'])
                self.assertNotIn('Open the gates', sent)
                self.assertNotIn('Make way', sent)
                self.assertNotIn('You say', sent)
                self.assertIn(TRAIN, sent)
                self.assertIn(PORTER, sent)
                self.assertEqual(self.snapshot(), before)
                self.assertEqual(engine.get_messages(self.con, self.cid)[0]['content'], original)

    def test_nearby_player_speech_does_not_remove_attributed_npc_dialogue(self):
        unsafe = 'You say:\n\n"Open the gates."'
        npc = 'The porter says, "I need the road clear."'
        self.seed_legacy(HEADER + '\n\n' + unsafe + '\n\nThe guard freezes.\n\n' + npc)
        before = self.snapshot()

        built = self.context()

        sent = '\n'.join(message['content'] for message in built['messages'])
        self.assertNotIn('Open the gates', sent)
        self.assertIn('The guard freezes.', sent)
        self.assertIn(npc, sent)
        self.assertEqual(self.snapshot(), before)

    def test_filtered_scene_keeps_checkpoint_authorized_player_words(self):
        for quotation in ('"Open the gates."', '"Open the gates.\nMake way."',
                          '"' + 'Open the gates. ' * 70 + '"'):
            with self.subTest(quotation=quotation):
                with self.con:
                    self.con.execute('DELETE FROM turn_checkpoints')
                    self.con.execute('DELETE FROM messages WHERE campaign_id=?', (self.cid,))
                source_action = 'I say, ' + quotation
                original = HEADER + '\n\nYou say:\n\n' + quotation + '\n\nYou nod.\n\n' + TRAIN
                message_id = self.seed_legacy(original)
                state = engine.get_campaign(self.con, self.cid)['state']
                with self.con:
                    self.con.execute('INSERT INTO turn_checkpoints VALUES (?,?,?,?)',
                                     (message_id, json.dumps(state), json.dumps(state), source_action))
                before = self.snapshot()

                built = self.context()

                sent = '\n'.join(message['content'] for message in built['messages'])
                self.assertIn(quotation, sent)
                self.assertNotIn('You nod.', sent)
                self.assertIn(TRAIN, sent)
                self.assertEqual(self.snapshot(), before)

    def test_checkpoint_source_action_keeps_authorized_player_acknowledgement(self):
        source_action = 'I step off the train.'
        acknowledgement = 'You step off the train.'
        source_reply = HEADER + '\n\n' + acknowledgement + '\n\n' + TRAIN + '\n\n' + PORTER
        engine.play_turn(self.con, self.cid, source_action, chat=lambda *_: reply(source_reply))
        before = self.snapshot()

        built = self.context(action='I wait.')

        assistant = next(message['content'] for message in built['messages'] if message['role'] == 'assistant')
        self.assertEqual(assistant, source_reply)
        self.assertIn({'role': 'user', 'content': source_action}, built['messages'])
        self.assertEqual(self.snapshot(), before)

    def test_paragraph_seams_cannot_reconstruct_an_unauthorized_player_action(self):
        # Each fragment alone has no actor-plus-predicate claim. Together they
        # assert a PC action, so independent paragraph checks are insufficient.
        self.seed_legacy(HEADER + '\n\nYou\n\nstand beside the violet luggage cart.')
        before = self.snapshot()
        chat = Mock(return_value=reply(CONTINUATION))

        with self.assertRaisesRegex(ValueError, 'Nothing was saved'):
            engine.play_turn(self.con, self.cid, ACTION, chat=chat)

        chat.assert_not_called()
        self.assertEqual(self.snapshot(), before)


class LegacySceneHandoffHttpTests(unittest.TestCase):
    # Reuse only the harness methods. Inheriting GameMasterHttpTests would
    # rediscover its unrelated test methods as duplicate cases in this module.
    setUp = gm_http.GameMasterHttpTests.setUp
    start_server = gm_http.GameMasterHttpTests.start_server
    post = gm_http.GameMasterHttpTests.post
    dump = gm_http.GameMasterHttpTests.dump

    def seed_legacy(self, text):
        with closing(engine.open_db(self.path)) as con:
            with con:
                row = con.execute(
                    'INSERT INTO messages (campaign_id,role,content,created_at) VALUES (?,?,?,?)',
                    (self.cid, 'gm', text, engine.now()))
            return row.lastrowid

    def test_real_http_replay_repair_uses_safe_scene_and_preserves_raw_message(self):
        self.seed_legacy(LEGACY_INTRO)
        self.model.replies = [reply(SAFE_INTRO), reply(CONTINUATION)]

        result = self.post('/turn', {'action': ACTION, 'model': 'qwen3:8b'})

        self.assertEqual(len(self.model.requests), 2)
        self.assertEqual(result['messages'][0]['content'], LEGACY_INTRO)
        self.assertEqual(result['messages'][-1]['content'], CONTINUATION)
        self.assertEqual([message['role'] for message in result['messages']], ['gm', 'player', 'gm'])
        for request in self.model.requests:
            assistant = next(message['content'] for message in request['messages']
                             if message['role'] == 'assistant')
            self.assertIn(TRAIN, assistant)
            self.assertIn(PORTER, assistant)
            self.assertNotIn(UNSAFE, json.dumps(request['messages']))
            self.assertEqual(request['format']['type'], 'object')
        self.assertIn('narration repeats', self.model.requests[1]['messages'][-1]['content'])

    def test_real_http_unusable_scene_avoids_ollama_and_retry_recovers(self):
        old = HEADER + '\n\nYou decide to follow Zarvok into the cemetery.'
        target = self.seed_legacy(old)
        before = self.dump()

        failed = self.post('/turn', {'action': ACTION, 'model': 'qwen3:8b'}, expected=400)

        self.assertEqual(self.model.requests, [])
        self.assertEqual(self.dump(), before)
        self.assertRegex(failed['error'], r'(?i)retry\s*/\s*feedback')
        self.model.replies = [reply(SAFE_INTRO)]

        recovered = self.post(f'/messages/{target}/retry', {
            'feedback': 'Keep this opening at the station without acting for my character.',
            'model': 'qwen3:8b'})

        self.assertEqual(len(self.model.requests), 1)
        self.assertEqual([message['role'] for message in recovered['messages']], ['gm'])
        self.assertEqual(recovered['messages'][0]['content'], SAFE_INTRO)
        self.assertTrue(recovered['messages'][0]['has_checkpoint'])
        self.assertNotIn(old, json.dumps(self.model.requests))


if __name__ == '__main__':
    unittest.main()
