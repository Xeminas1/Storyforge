"""Local-only service controls, nonblocking launch lifecycle and shortcut safety."""
import base64
import io
import json
import subprocess
import sys
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from contextlib import redirect_stdout
from http.server import ThreadingHTTPServer
from pathlib import Path
from unittest.mock import MagicMock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import server


class ServiceControlHttpTests(unittest.TestCase):
    def setUp(self):
        self.temp = self.enterContext(tempfile.TemporaryDirectory())
        self.root = Path(self.temp)
        self.enterContext(patch.object(server, 'ROOT', self.root))
        self.db = self.root/'data/private.db'
        self.enterContext(patch.object(server, 'DB_PATH', self.db))
        self.manager = MagicMock()
        self.snapshot = {'supported': True, 'enabled': True, 'settings': {},
                         'services': [], 'starting': False, 'can_create_shortcut': True}
        for method in ('snapshot', 'save_settings', 'start', 'check'):
            getattr(self.manager, method).return_value = self.snapshot
        self.http = ThreadingHTTPServer(('127.0.0.1', 0), server.Handler)
        self.http.local_services = self.manager
        self.thread = threading.Thread(target=lambda: self.http.serve_forever(poll_interval=0.01), daemon=True)
        self.thread.start()
        self.addCleanup(self.cleanup)
        self.base = 'http://127.0.0.1:'+str(self.http.server_port)

    def cleanup(self):
        self.http.shutdown()
        self.http.server_close()
        self.thread.join(2)

    def request(self, path, body=None, *, origin=True, host=None, raw=None):
        headers = {}
        if origin:
            headers['Origin'] = self.base if origin is True else origin
        if host:
            headers['Host'] = host
        data = raw if raw is not None else json.dumps(body).encode() if body is not None else None
        if data is not None:
            headers['Content-Type'] = 'application/json'
        request = urllib.request.Request(self.base+path, data=data, headers=headers)
        try:
            response = urllib.request.urlopen(request, timeout=3)
        except urllib.error.HTTPError as exc:
            response = exc
        with response:
            return response.status, json.load(response)

    def test_status_is_read_only_and_does_not_open_the_campaign_database(self):
        status, body = self.request('/api/services', origin=False)
        self.assertEqual((status, body), (200, self.snapshot))
        self.manager.snapshot.assert_called_once_with()
        self.manager.start.assert_not_called()
        self.manager.check.assert_not_called()
        self.assertFalse(self.db.exists())

    def test_settings_start_and_health_check_delegate_only_after_local_origin(self):
        payload = {'enabled': True, 'comfyui_path': r'C:\Program Files\Comfy Desktop'}
        self.assertEqual(self.request('/api/services/settings', payload)[0], 200)
        self.manager.save_settings.assert_called_once_with(payload)
        self.assertEqual(self.request('/api/services/start', {})[0], 200)
        self.manager.start.assert_called_once_with(manual=True)
        self.assertEqual(self.request('/api/services/check', {})[0], 200)
        self.manager.check.assert_called_once_with()

    def test_missing_origin_foreign_origin_and_dns_rebinding_hosts_cannot_launch(self):
        for options in ({'origin': False}, {'origin': 'https://attacker.example'},
                        {'origin': 'http://attacker.example', 'host': 'attacker.example'},
                        {'origin': 'http://127.0.0.1.evil', 'host': '127.0.0.1.evil'},
                        {'origin': 'http://name@127.0.0.1', 'host': 'name@127.0.0.1'}):
            for path in ('/api/services/start', '/api/services/settings', '/api/services/check', '/api/services/shortcut'):
                with self.subTest(options=options, path=path):
                    self.assertEqual(self.request(path, {}, **options)[0], 403)
        self.manager.start.assert_not_called()
        self.manager.check.assert_not_called()
        self.manager.save_settings.assert_not_called()

    def test_remote_peer_cannot_use_service_controls_with_a_local_host_header(self):
        handler = server.Handler.__new__(server.Handler)
        handler.client_address = ('10.0.0.5', 1234)
        handler.headers = {'Host': '127.0.0.1:8787', 'Origin': 'http://127.0.0.1:8787'}
        self.assertFalse(handler.local_service_access(write=True))
        self.assertFalse(handler.local_service_access())

    def test_bad_json_and_unknown_routes_do_not_start_any_service(self):
        self.assertEqual(self.request('/api/services/start', raw=b'[]')[0], 400)
        self.assertEqual(self.request('/api/services/start', raw=b'invalid')[0], 400)
        self.assertEqual(self.request('/api/services/unknown', {})[0], 404)
        self.manager.start.assert_not_called()

    def test_shortcut_is_created_only_by_the_explicit_local_action(self):
        with patch('server.create_desktop_shortcut', return_value={'ok': True, 'message': 'Created'}) as create:
            self.assertEqual(self.request('/api/services/shortcut', {}, origin=False)[0], 403)
            create.assert_not_called()
            self.assertEqual(self.request('/api/services/shortcut', {})[0], 200)
            create.assert_called_once_with()


class DesktopLauncherTests(unittest.TestCase):
    def test_desktop_shortcut_uses_fixed_encoded_script_and_escaped_literal_paths(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)/"User's $(literal) folder"
            powershell = root/'System32/WindowsPowerShell/v1.0/powershell.exe'
            powershell.parent.mkdir(parents=True)
            powershell.touch()
            executable = root/'Python/python.exe'
            executable.parent.mkdir()
            executable.touch()
            result = subprocess.CompletedProcess([], 0, '', '')
            with patch.dict(server.os.environ, {'SystemRoot': str(root)}), \
                 patch.object(server, 'ROOT', root), patch.object(sys, 'executable', str(executable)), \
                 patch('server.subprocess.run', return_value=result) as launch:
                value = server.create_desktop_shortcut(windows=True)
            self.assertTrue(value['ok'])
            command = launch.call_args.args[0]
            self.assertEqual(command[:5], [str(powershell), '-NoLogo', '-NoProfile', '-NonInteractive', '-EncodedCommand'])
            script = base64.b64decode(command[5]).decode('utf-16-le')
            self.assertIn("User''s $(literal) folder", script)
            self.assertIn('--open-browser', script)
            self.assertIn("[Environment]::GetFolderPath('Desktop')", script)
            self.assertIn('STORYFORGE_SHORTCUT_CONFLICT', script)
            self.assertNotIn('ExecutionPolicy', script)
            self.assertFalse(launch.call_args.kwargs['shell'])
            self.assertEqual(launch.call_args.kwargs['timeout'], 20)
            self.assertEqual(launch.call_args.kwargs['cwd'], root)

    def test_non_windows_shortcut_request_never_runs_a_command(self):
        with patch('server.subprocess.run') as launch:
            with self.assertRaisesRegex(ValueError, 'Windows'):
                server.create_desktop_shortcut(windows=False)
        launch.assert_not_called()

    def test_second_desktop_click_reuses_existing_server_without_service_launches(self):
        with patch('server.running_storyforge', return_value=True), \
             patch('server.webbrowser.open') as browser, patch('server.run') as run, \
             patch('server.bootstrap') as bootstrap:
            self.assertEqual(server.main(['--open-browser']), 0)
        browser.assert_called_once_with(server._storyforge_url(server.HOST, server.PORT))
        run.assert_not_called()
        bootstrap.assert_not_called()

    def test_new_desktop_click_uses_browser_start_mode(self):
        with patch('server.running_storyforge', return_value=False), patch('server.run') as run:
            self.assertEqual(server.main(['--open-browser']), 0)
        run.assert_called_once_with(open_browser=True)

    def test_evaluation_refuses_browser_mode_without_starting_anything(self):
        with patch('server.run') as run, patch('engine.evaluate_local_gm') as evaluate, \
             patch('server.webbrowser.open') as browser, patch('sys.stderr', io.StringIO()):
            with self.assertRaises(SystemExit):
                server.main(['--evaluate-model', 'qwen3:8b', '--open-browser'])
        run.assert_not_called()
        evaluate.assert_not_called()
        browser.assert_not_called()

    def test_server_lifecycle_starts_background_checks_and_leaves_backend_ownership_to_manager(self):
        http = MagicMock()
        http.serve_forever.side_effect = KeyboardInterrupt
        manager = MagicMock()
        watcher = MagicMock()
        with patch('server.bootstrap'), patch('server.ThreadingHTTPServer', return_value=http), \
             patch('server.engine.LocalServices', return_value=manager), \
             patch('server.updater.UpdateWatcher', return_value=watcher), \
             redirect_stdout(io.StringIO()):
            server.run()
        manager.start.assert_called_once_with()
        manager.close.assert_called_once_with()
        self.assertIs(http.local_services, manager)
        watcher.start.assert_called_once_with()
        watcher.stop.set.assert_called_once_with()
        http.server_close.assert_called_once_with()

    def test_browser_opens_only_after_the_api_becomes_ready(self):
        with patch('server.running_storyforge', side_effect=[False, True]), \
             patch('server.time.sleep') as delay, patch('server.webbrowser.open') as browser:
            server.open_ready_browser('127.0.0.1', 8787)
        delay.assert_called_once_with(0.25)
        browser.assert_called_once_with('http://127.0.0.1:8787')

    def test_bind_race_reuses_a_server_without_creating_another_manager(self):
        with patch('server.bootstrap'), patch('server.ThreadingHTTPServer', side_effect=OSError('busy')), \
             patch('server.running_storyforge', return_value=True), \
             patch('server.webbrowser.open') as browser, patch('server.engine.LocalServices') as manager:
            server.run(open_browser=True)
        browser.assert_called_once()
        manager.assert_not_called()


if __name__ == '__main__':
    unittest.main()
