"""Scene-continuation regressions using the user's reported first action.

The generated replies are scripted: these checks establish request framing,
duplicate rejection and atomic storage, not live qwen3:8b storytelling quality.
"""
import copy
import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import engine


ACTION = 'i step off the train and look at my surroundings'
INTRO = ('[Hogsmeade Station - Hogsmeade - Morning]\n\n'
         'The Hogwarts Express stands beside Hogsmeade Station under a thinning veil of steam. '
         'Students and parents gather around the luggage carts while the carriage driver rings '
         'a brass handbell. Beyond the platform, a line of carriages waits beside the road.\n\n'
         'The driver says, "I need the road clear for the next carriage." '
         'A witch steadies a stack of trunks beside the station clock.')
CONTINUATION = ('[Hogsmeade Station - Hogsmeade - Morning]\n\n'
                'Beside the train steps, a dropped luggage label flutters against the platform: '
                '*Hogwarts — First Years*. A porter pins it beneath his boot before the wind '
                'can take it into the wheels.\n\n'
                '"Mind the gap beside that crate," the porter says, tugging a trolley clear. '
                'A narrow path between the trunks leads toward the waiting carriage driver; '
                'the Sorting Ceremony at Hogwarts still lies ahead.')


def output(narration):
    return json.dumps({'narration': narration, 'state_updates': {}})


class SceneContinuationTests(unittest.TestCase):
    def setUp(self):
        temporary = self.enterContext(tempfile.TemporaryDirectory())
        self.con = engine.open_db(Path(temporary) / 'story.db')
        self.addCleanup(self.con.close)
        self.world = engine.make_world(self.con, {
            'title': 'Harry Potter: Wizarding World',
            'description': 'Attend Hogwarts, choose your house, attend class, learn spells. '
                           'Start at Hogsmeade Station for the introduction and later Sorting Hat selection.'})
        created = engine.new_campaign(self.con, {
            'world_id': self.world['id'], 'pc_name': 'Xeminas',
            'species': 'High Elf', 'appearance': 'Tall, platinum hair, purple eyes and dark robes.'})
        self.cid = created['id']

    def begin(self):
        return engine.play_turn(self.con, self.cid, '__START__',
                                chat=lambda *_: output(INTRO))

    def snapshot(self):
        return list(self.con.iterdump())

    def capture(self, replies, action=ACTION):
        calls = []

        def chat(messages, model):
            calls.append(copy.deepcopy(messages))
            return output(replies[len(calls) - 1])

        result = engine.play_turn(self.con, self.cid, action, chat=chat)
        return result, calls

    def test_existing_station_scene_is_framed_as_continuation_not_another_opening(self):
        self.begin()
        _, calls = self.capture([CONTINUATION])
        system = calls[0][0]['content']
        self.assertIn('CURRENT TURN: CONTINUATION', system)
        self.assertIn('starting instructions are setup', system)
        self.assertIn('immediate consequence', system)
        self.assertIn('newly relevant detail', system)
        self.assertEqual(calls[0][-1], {'role': 'user', 'content': ACTION})
        self.assertEqual(sum(message['content'].count(ACTION) for message in calls[0]), 1)
        self.assertIn(INTRO, '\n'.join(message['content'] for message in calls[0]))

    def test_fresh_opening_still_uses_creator_start_and_keeps_milestones_pending(self):
        _, calls = self.capture([INTRO], action='__START__')
        system = calls[0][0]['content']
        self.assertNotIn('CURRENT TURN: CONTINUATION', system)
        self.assertIn('starting location prescribed by the world premise', calls[0][-1]['content'])
        self.assertIn('Keep future milestones pending', calls[0][-1]['content'])
        self.assertNotIn('__START__', json.dumps(calls))

    def test_station_replay_then_fresh_response_saves_one_action_and_one_continuation(self):
        self.begin()
        result, calls = self.capture([INTRO, CONTINUATION])
        self.assertEqual(len(calls), 2)
        self.assertIn('The saved scene has already happened', calls[1][-1]['content'])
        self.assertIn('new immediate consequence', calls[1][-1]['content'])
        self.assertIn('not another arrival', calls[1][-1]['content'])
        self.assertIn(ACTION, calls[1][-1]['content'])
        self.assertEqual([row['role'] for row in result['messages']], ['gm', 'player', 'gm'])
        self.assertEqual(result['messages'][0]['content'], INTRO)
        self.assertEqual(result['messages'][1]['content'], ACTION)
        self.assertEqual(result['messages'][2]['content'], CONTINUATION)
        self.assertEqual(self.con.execute('SELECT count(*) FROM turn_checkpoints').fetchone()[0], 2)
        # The saved intro is still context. The rejected draft is not added as
        # an extra assistant turn or quoted in the corrective user request.
        self.assertEqual(sum(message['role'] == 'assistant' for message in calls[1]), 1)
        self.assertNotIn(INTRO, calls[1][-1]['content'])
        for request in calls:
            self.assertLessEqual(sum(len(message['content'].encode('utf-8')) for message in request),
                                 engine.GM_CONTEXT_BYTE_LIMIT)

    def test_two_replays_leave_every_saved_row_unchanged(self):
        self.begin()
        before = self.snapshot()
        calls = []

        def chat(messages, _model):
            calls.append(copy.deepcopy(messages))
            return output(INTRO)

        with self.assertRaisesRegex(ValueError, 'narration repeats an earlier GM reply.*Nothing was saved'):
            engine.play_turn(self.con, self.cid, ACTION, chat=chat)
        self.assertEqual(len(calls), 2)
        self.assertEqual(self.snapshot(), before)

    def test_failed_retry_preserves_existing_continuation_and_checkpoints(self):
        self.begin()
        result, _ = self.capture([CONTINUATION])
        before = self.snapshot()
        with self.assertRaisesRegex(ValueError, 'Nothing was saved'):
            engine.retry_message(self.con, self.cid, result['messages'][-1]['id'],
                                 feedback='Continue from my action instead of replaying the station.',
                                 chat=lambda *_: output(INTRO))
        self.assertEqual(self.snapshot(), before)

    def test_new_details_can_reuse_station_and_npc_names_without_replaying_prose(self):
        self.assertEqual(engine.gm_repetition_violations(CONTINUATION, [
            {'role': 'gm', 'content': INTRO}]), [])
        self.assertTrue(engine.gm_repetition_violations(INTRO, [
            {'role': 'gm', 'content': INTRO}]))

    def test_species_or_appearance_does_not_give_model_permission_to_invent_pc_actions(self):
        _, calls = self.capture([INTRO], action='__START__')
        self.assertIn('even when unnamed', calls[0][0]['content'])
        self.assertIn('profile, species, appearance, titles and aliases', calls[0][0]['content'])

    def test_combined_replay_and_evidence_repair_fits_reserved_bytes_with_full_unicode_action(self):
        action = ACTION + ' — I inspect the sign marked "\u7ad9\u53f0".'
        reserved = 1200 + len(action.encode('utf-8'))
        messages = [{'role': 'system', 'content': 'x' * (
            engine.GM_CONTEXT_BYTE_LIMIT - reserved - len(action.encode('utf-8')))},
            {'role': 'user', 'content': action}]
        repair = engine._bounded_gm_repair(messages, [
            'narration repeats an earlier GM reply',
            'state change lacks visible evidence: inventory_remove'], action)
        self.assertIn('narration repeats an earlier GM reply', repair['content'])
        self.assertIn('state change lacks visible evidence: inventory_remove', repair['content'])
        self.assertIn('state_updates.evidence[field]', repair['content'])
        self.assertTrue(repair['content'].endswith(action))
        self.assertLessEqual(sum(len(message['content'].encode('utf-8'))
                                 for message in [*messages, repair]), engine.GM_CONTEXT_BYTE_LIMIT)

    def test_combined_replay_and_evidence_failure_can_be_corrected_in_second_attempt(self):
        self.begin()
        calls = []

        def chat(messages, _model):
            calls.append(copy.deepcopy(messages))
            if len(calls) == 1:
                return json.dumps({'narration': INTRO,
                                   'state_updates': {'location': 'Castle Entrance'}})
            return output(CONTINUATION)

        chat.requires_state_evidence = True
        result = engine.play_turn(self.con, self.cid, ACTION, chat=chat)
        self.assertEqual(result['messages'][-1]['content'], CONTINUATION)
        self.assertEqual(len(calls), 2)
        repair = calls[1][-1]['content']
        self.assertIn('narration repeats an earlier GM reply', repair)
        self.assertIn('state change lacks visible evidence: location', repair)
        self.assertIn('state_updates.evidence[field]', repair)


if __name__ == '__main__':
    unittest.main()
