"""Restart ownership, health-response privacy, and stale-bytecode regressions."""
from __future__ import annotations

import contextlib
import http.server
import json
import os
from pathlib import Path
import sys
import tempfile
import threading
import unittest
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import updater


class _HealthHandler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        server = self.server
        with server.response_lock:
            server.requests.append(self.path)
            status, body, headers = server.responses[min(len(server.requests) - 1, len(server.responses) - 1)]
        self.send_response(status)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Content-Type', 'application/json')
        for key, value in headers.items():
            self.send_header(key, value)
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def log_message(self, *_):
        pass


class _Clock:
    def __init__(self):
        self.now = 0.0

    def monotonic(self):
        return self.now

    def sleep(self, seconds):
        self.now += max(float(seconds), 0.05)


class RestartHealthTests(unittest.TestCase):
    """Use actual loopback HTTP while replacing only retry timing."""
    version = '0.16.2'

    @classmethod
    def setUpClass(cls):
        cls.httpd = http.server.ThreadingHTTPServer(('127.0.0.1', 0), _HealthHandler)
        cls.httpd.daemon_threads = True
        cls.httpd.response_lock = threading.Lock()
        cls.httpd.responses = []
        cls.httpd.requests = []
        cls.thread = threading.Thread(target=cls.httpd.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.httpd.server_close()
        cls.thread.join(timeout=3)

    def setUp(self):
        self.child = mock.Mock()
        self.child.pid = 42121
        self.child.poll.return_value = None
        self.clock = _Clock()
        self.details = {}
        self.stack = contextlib.ExitStack()
        self.addCleanup(self.stack.close)
        self.stack.enter_context(mock.patch.object(updater.time, 'monotonic', self.clock.monotonic))
        self.stack.enter_context(mock.patch.object(updater.time, 'sleep', self.clock.sleep))
        self.log = self.stack.enter_context(mock.patch.object(updater, '_worker_log', create=True))
        with self.httpd.response_lock:
            self.httpd.requests = []
        self.respond(self.healthy())

    def healthy(self, **changes):
        return {'ok': True, 'version': self.version, 'pid': self.child.pid, **changes}

    def respond(self, value, *, status=200, headers=None):
        body = value if isinstance(value, bytes) else json.dumps(value).encode('utf-8')
        with self.httpd.response_lock:
            self.httpd.responses = [(status, body, headers or {})]

    def wait(self, seconds=1):
        return updater.wait_for_health('127.0.0.1', self.httpd.server_port, self.version,
                                       self.child, seconds, details=self.details)

    def diagnostics(self):
        return json.dumps(self.details, default=str) + str(self.log.call_args_list)

    def test_accepts_matching_live_child_and_uses_health_endpoint(self):
        self.assertTrue(self.wait())
        self.assertEqual(self.httpd.requests, ['/api/health'])

    def test_rejects_old_version_even_when_server_is_responding(self):
        self.respond(self.healthy(version='0.16.0'))
        self.assertFalse(self.wait())
        self.assertGreater(len(self.httpd.requests), 0)
        self.assertTrue(self.details, 'An HTTP200/version mismatch needs useful diagnostics')
        self.assertIn('0.16.0', self.diagnostics())

    def test_rejects_wrong_or_missing_process_identity(self):
        for pid in (42122, '42121', 42121.0, None, True):
            with self.subTest(pid=pid):
                self.clock.now = 0
                self.respond(self.healthy(pid=pid))
                self.assertFalse(self.wait())
        value = self.healthy()
        del value['pid']
        self.respond(value)
        self.clock.now = 0
        self.assertFalse(self.wait())

    def test_ok_must_be_the_boolean_true(self):
        for value in (False, None, 1, 'true'):
            with self.subTest(ok=value):
                self.respond(self.healthy(ok=value))
                self.clock.now = 0
                self.assertFalse(self.wait())
        value = self.healthy()
        del value['ok']
        self.respond(value)
        self.clock.now = 0
        self.assertFalse(self.wait())

    def test_non_object_json_and_invalid_json_are_not_health(self):
        for value in ([self.healthy()], None, 'private narrative', b'{not json'):
            with self.subTest(value=type(value).__name__):
                self.respond(value)
                self.clock.now = 0
                self.assertFalse(self.wait())

    def test_dead_child_is_not_replaced_by_another_server_on_same_port(self):
        self.child.poll.return_value = 7
        self.assertFalse(self.wait())
        self.assertEqual(self.httpd.requests, [])

    def test_child_that_exits_after_successful_response_is_not_ready(self):
        self.child.poll.side_effect = [None, 7, 7]
        self.assertFalse(self.wait())
        self.assertEqual(self.httpd.requests, ['/api/health'])

    def test_polling_can_recover_from_stale_response_before_deadline(self):
        old = json.dumps(self.healthy(version='0.16.0')).encode()
        good = json.dumps(self.healthy()).encode()
        with self.httpd.response_lock:
            self.httpd.responses = [(200, old, {}), (200, good, {})]
        self.assertTrue(self.wait(seconds=2))
        self.assertEqual(self.httpd.requests, ['/api/health', '/api/health'])

    def test_loopback_health_ignores_external_proxy_configuration(self):
        # No bypass variables are available: a default proxy-aware opener fails here.
        with mock.patch.dict(os.environ, {'http_proxy': 'http://127.0.0.1:1',
                                         'https_proxy': 'http://127.0.0.1:1',
                                         'HTTP_PROXY': 'http://127.0.0.1:1',
                                         'HTTPS_PROXY': 'http://127.0.0.1:1',
                                         'NO_PROXY': '', 'no_proxy': ''}):
            self.assertTrue(self.wait())
        self.assertEqual(self.httpd.requests, ['/api/health'])

    def test_health_does_not_follow_redirects(self):
        self.respond(b'', status=302, headers={'Location': '/private-redirect-target'})
        self.assertFalse(self.wait())
        self.assertTrue(self.httpd.requests)
        self.assertNotIn('/private-redirect-target', self.httpd.requests)

    def test_oversized_body_cannot_pass_as_a_truncated_valid_prefix(self):
        prefix = json.dumps(self.healthy()).encode()
        self.respond(prefix + b' ' * (4096 - len(prefix)) + b'PRIVATE_OVERSIZED_BODY')
        self.assertFalse(self.wait())
        self.assertNotIn('PRIVATE_OVERSIZED_BODY', self.diagnostics())

    def test_wrong_response_details_do_not_copy_story_text_or_private_fields(self):
        self.respond(self.healthy(version='0.16.0', narrative='PRIVATE_STORY_CANARY',
                                  local_path='PRIVATE_PATH_CANARY'))
        self.assertFalse(self.wait())
        output = self.diagnostics()
        self.assertNotIn('PRIVATE_STORY_CANARY', output)
        self.assertNotIn('PRIVATE_PATH_CANARY', output)

    def test_error_body_and_url_details_are_not_copied_to_diagnostics(self):
        self.respond(b'PRIVATE_HTTP_ERROR_BODY', status=503)
        self.assertFalse(self.wait())
        self.assertTrue(self.details)
        self.assertNotIn('PRIVATE_HTTP_ERROR_BODY', self.diagnostics())

    def test_malformed_version_and_pid_values_do_not_leak_arbitrary_strings(self):
        self.respond(self.healthy(version={'private': 'PRIVATE_VERSION_CANARY'},
                                  pid='PRIVATE_PID_CANARY'))
        self.assertFalse(self.wait())
        self.assertNotIn('PRIVATE_VERSION_CANARY', self.diagnostics())
        self.assertNotIn('PRIVATE_PID_CANARY', self.diagnostics())

    def test_timeout_is_bounded_and_repeated_identical_state_is_not_logged_each_poll(self):
        self.respond(self.healthy(version='0.16.0'))
        self.assertFalse(self.wait(seconds=3))
        self.assertGreaterEqual(self.clock.now, 3)
        self.assertLess(self.clock.now, 4)
        self.assertGreater(len(self.httpd.requests), 3)
        self.assertLess(self.log.call_count, len(self.httpd.requests),
                        'Identical health failures should not flood updater.log')
        self.assertTrue(self.details)


class RestartCacheTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name) / 'install'
        self.root.mkdir()

    def put(self, name, body=b'KEEP'):
        path = self.root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(body)
        return path

    def test_removes_only_changed_approved_module_caches_across_python_versions(self):
        remove = [self.put('__pycache__/updater.cpython-312.pyc'),
                  self.put('__pycache__/updater.cpython-313.pyc'),
                  self.put('__pycache__/updater.cpython-313.opt-1.pyc'),
                  self.put('__pycache__/updater.pypy310.pyc'),
                  self.put('tools/__pycache__/build_release.cpython-313.pyc'),
                  self.put('tests/__pycache__/test_updater.cpython-313.opt-2.pyc')]
        keep = [self.put('updater.py', b'raise RuntimeError("do not execute")'),
                self.put('engine.py'), self.put('__pycache__/engine.cpython-313.pyc'),
                self.put('__pycache__/updater.cpython-313.txt'),
                self.put('__pycache__/nested/updater.cpython-313.pyc'),
                self.put('data/storyforge.db'),
                self.put('data/__pycache__/updater.cpython-313.pyc'),
                self.put('static/app.js'), self.put('static/__pycache__/app.cpython-313.pyc')]
        with mock.patch.object(Path, 'read_bytes', side_effect=AssertionError('No source reads')), \
             mock.patch.object(Path, 'read_text', side_effect=AssertionError('No source reads')):
            updater._purge_update_caches(self.root, ['updater.py', 'tools/build_release.py',
                                                     'tests/test_updater.py', 'static/app.js'])
        for path in remove:
            self.assertFalse(path.exists(), path)
        for path in keep:
            self.assertTrue(path.exists(), path)
        self.assertEqual((self.root / 'data/storyforge.db').read_bytes(), b'KEEP')

    def test_noninstallable_or_private_paths_cannot_trigger_cache_deletion(self):
        keep = [self.put('data/__pycache__/private.cpython-313.pyc'),
                self.put('private/__pycache__/malware.cpython-313.pyc'),
                self.put('static/__pycache__/fake.cpython-313.pyc')]
        updater._purge_update_caches(self.root, ['data/private.py', 'private/malware.py',
                                                'static/fake.py', '../outside.py',
                                                '/tmp/outside.py', r'data\private.py'])
        self.assertTrue(all(path.exists() for path in keep))

    def make_symlink(self, link, target, *, directory=False):
        try:
            link.symlink_to(target, target_is_directory=directory)
        except (OSError, NotImplementedError) as exc:
            self.skipTest(f'Symbolic links unavailable: {type(exc).__name__}')

    def test_symlinked_cache_directory_is_never_followed(self):
        outside = Path(self.temp.name) / 'external-cache'
        outside.mkdir()
        canary = outside / 'updater.cpython-313.pyc'
        canary.write_bytes(b'PRIVATE CACHE')
        self.make_symlink(self.root / '__pycache__', outside, directory=True)
        updater._purge_update_caches(self.root, ['updater.py'])
        self.assertEqual(canary.read_bytes(), b'PRIVATE CACHE')
        self.assertTrue((self.root / '__pycache__').is_symlink())

    def test_symlinked_cache_file_is_not_unlinked_or_read(self):
        canary = Path(self.temp.name) / 'private-file'
        canary.write_bytes(b'PRIVATE FILE')
        cache = self.root / '__pycache__'
        cache.mkdir()
        link = cache / 'updater.cpython-313.pyc'
        self.make_symlink(link, canary)
        updater._purge_update_caches(self.root, ['updater.py'])
        self.assertTrue(link.is_symlink())
        self.assertEqual(canary.read_bytes(), b'PRIVATE FILE')

    def test_symlinked_parent_directory_is_not_followed(self):
        outside = Path(self.temp.name) / 'external-tools'
        (outside / '__pycache__').mkdir(parents=True)
        canary = outside / '__pycache__/build_release.cpython-313.pyc'
        canary.write_bytes(b'PRIVATE CACHE')
        self.make_symlink(self.root / 'tools', outside, directory=True)
        updater._purge_update_caches(self.root, ['tools/build_release.py'])
        self.assertEqual(canary.read_bytes(), b'PRIVATE CACHE')

    def test_absent_caches_are_harmless(self):
        updater._purge_update_caches(self.root, ['server.py', 'engine.py', 'updater.py'])
        self.assertEqual(list(self.root.iterdir()), [])


class RestartLaunchTests(unittest.TestCase):
    def test_child_runs_unbuffered_without_writing_bytecode_and_keeps_update_log(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / 'data/updates').mkdir(parents=True)
            with mock.patch.object(updater.subprocess, 'Popen') as popen:
                child = updater.launch_server(root, '127.0.0.1', 8787)
            args, kwargs = popen.call_args
            self.assertIs(child, popen.return_value)
            self.assertEqual(args[0], [sys.executable, '-u', '-B', str(root / 'server.py')])
            self.assertEqual(kwargs['cwd'], str(root))
            self.assertEqual(kwargs['env']['STORYFORGE_HOST'], '127.0.0.1')
            self.assertEqual(kwargs['env']['STORYFORGE_PORT'], '8787')
            self.assertEqual(Path(kwargs['stdout'].name), root / 'data/updates/server.log')
            self.assertTrue(kwargs['stdout'].closed)
            self.assertEqual(kwargs['stderr'], updater.subprocess.STDOUT)
            self.assertEqual(kwargs['stdin'], updater.subprocess.DEVNULL)
            self.assertFalse(kwargs.get('shell', False))




class HealthUrlTests(unittest.TestCase):
    def test_custom_bind_hostname_resolves_to_numeric_ipv4_like_the_server(self):
        with mock.patch('socket.gethostbyname',return_value='127.0.0.1') as lookup:
            self.assertEqual(updater._health_url('storyforge-pc',8787),'http://127.0.0.1:8787/api/health')
        lookup.assert_called_once_with('storyforge-pc')

    def test_hostnames_cannot_inject_url_credentials_or_paths(self):
        for host in ('user@host','http://localhost','localhost/private','localhost?key=value'):
            with self.subTest(host=host),mock.patch('socket.gethostbyname') as lookup:
                with self.assertRaises(ValueError):updater._health_url(host,8787)
                lookup.assert_not_called()


if __name__ == '__main__':
    unittest.main()
