"""Execute rejected-draft inspection and privacy boundaries in the real browser code."""
import subprocess
import unittest

import test_story_request_ui as story_ui


HARNESS = story_ui.HARNESS.replace(
    "  request=async(url,options)=>",
    "  var actualRequest=request,actualRenderMessages=renderMessages;\n  request=async(url,options)=>",
) + r"""
// Extend the existing DOM fake with connected child nodes and text-only rendering.
const htmlWrites=[],downloads=[],blobs=[],revoked=[],timers=[],storageWrites=[];
const originalHtml=Object.getOwnPropertyDescriptor(Element.prototype,'innerHTML');
Object.defineProperty(Element.prototype,'innerHTML',{set(value){
  htmlWrites.push(value);this.children=[];this._text='';originalHtml.set.call(this,value);
}});
Object.defineProperty(Element.prototype,'textContent',{
  get(){return (this._text||'')+this.children.map(node=>node.textContent).join('');},
  set(value){this._text=String(value);for(const child of this.children||[])child.parentNode=null;this.children=[];}
});
for(const node of nodes.values()){
  const text=node.textContent;delete node.textContent;node.textContent=text;
}
Element.prototype.appendChild=function(node){node.parentNode=this;node.removed=false;this.children.push(node);return node;};
Element.prototype.remove=function(){
  this.removed=true;
  if(this.parentNode)this.parentNode.children=this.parentNode.children.filter(child=>child!==this);
  this.parentNode=null;
};
Element.prototype.click=function(){downloads.push({href:this.href,name:this.download});};
document.createElement=tag=>{const node=new Element();node.tagName=tag.toUpperCase();return node;};
document.contains=node=>{
  if(!node||node.removed)return false;
  return nodes.get(node.id)===node||Boolean(node.parentNode&&document.contains(node.parentNode));
};
context.Blob=class{constructor(parts,options){this.parts=parts;this.options=options;blobs.push(this);}};
context.URL={createObjectURL:blob=>'blob:diagnostic-'+blobs.indexOf(blob),revokeObjectURL:url=>revoked.push(url)};
context.setTimeout=(fn,delay)=>{timers.push({fn,delay});return timers.length;};
context.localStorage={setItem:(...args)=>storageWrites.push(args),getItem:()=>null};
const ui=vm.runInContext('({request:actualRequest,renderMessages:actualRenderMessages})',context);
function descendants(node){return node.children.flatMap(child=>[child,...descendants(child)]);}
function panels(){return [...nodes.values()].flatMap(descendants).filter(node=>node.className==='gm-rejected-replies');}
function panel(){const result=panels();assert.equal(result.length,1);return result[0];}
function downloadButton(){return descendants(panel()).find(node=>node.tagName==='BUTTON');}
function nextResponse(){
  context.responsePromise=new Promise((resolve,reject)=>{resolveResponse=resolve;rejectResponse=reject;});
}
const privateText='<img src=x onerror="globalThis.attacked=true"> I decide to open the forbidden gate.';
function rejectedError(){
  const error=new Error('The GM reply failed its player-control check.');
  error.gmDiagnostics={storyforge_version:'0.16.6',requested_model:'ministral-3:14b',attempts:[
    {attempt:1,narration:privateText,violations:['first-person narration <script>bad()</script>'],
     state_updates_json:'{"location":"<img src=x onerror=bad()>"}',state_updates_truncated:false},
    {attempt:2,narration:'A second private draft.',violations:['unrequested player thought'],
     state_updates_json:'{"journal_entry":"unsaved"}',state_updates_truncated:true}
  ]};
  return error;
}
"""


@unittest.skipUnless(story_ui.NODE, 'Node is required for rejected-draft browser checks')
class GmDiagnosticsUiTests(unittest.TestCase):
    def run_js(self, script):
        completed = subprocess.run(
            [story_ui.NODE, '-e', HARNESS + '\n(async()=>{\n' + script +
             '\n})().then(()=>console.log("UI_TEST_COMPLETE")).catch(error=>{console.error(error);process.exitCode=1;});'],
            cwd=story_ui.ROOT, capture_output=True, text=True, timeout=15,
        )
        self.assertEqual(completed.returncode, 0, completed.stdout + completed.stderr)
        self.assertIn('UI_TEST_COMPLETE', completed.stdout)

    def test_http_error_retains_diagnostics_without_saving_or_fetching_again(self):
        self.run_js(r"""
const error=rejectedError();let requests=0;
context.fetch=async()=>{requests++;return {ok:false,json:async()=>({error:error.message,gm_diagnostics:error.gmDiagnostics})};};
const caught=await ui.request('/api/campaigns/first/turn').catch(error=>error);
assert.equal(caught.message,error.message);assert.equal(caught.gmDiagnostics,error.gmDiagnostics);
assert.equal(requests,1);assert.equal(blobs.length,0);assert.equal(storageWrites.length,0);
assert.equal(panels().length,0);
""")

    def test_retry_inspection_is_literal_closed_unsaved_and_retains_feedback(self):
        self.run_js(r"""
get('autoplay').checked=true;
const original=app.state.messages,originalState=JSON.stringify(app.state.active.state);
app.openStoryMessageAction(2,'retry');get('story-correction-reason').value='Keep my character under my control.';
const pending=get('confirm-story-correction').onclick();rejectResponse(rejectedError());await pending;
const details=panel();assert.notEqual(details.open,true);
assert.ok(details.textContent.includes('These rejected drafts were not saved'));
assert.ok(details.textContent.includes('0.16.6 · Model: ministral-3:14b'));
assert.ok(details.textContent.includes(privateText));
assert.ok(details.textContent.includes('Proposed state updates (not saved)'));
assert.ok(details.textContent.includes('shortened for this diagnostic'));
assert.equal(get('story-correction-reason').value,'Keep my character under my control.');
assert.equal(get('story-correction-reason').disabled,false);
assert.equal(app.state.messages,original);assert.equal(JSON.stringify(app.state.active.state),originalState);
assert.equal(app.spoken.length,0);assert.equal(app.painted.length,0);assert.equal(context.attacked,undefined);
assert.ok(!htmlWrites.some(html=>html.includes(privateText)||html.includes('<script>bad()')));
assert.equal(blobs.length,0);assert.deepEqual(storageWrites,[['sf_model','qwen3:8b']]);
""")

    def test_failed_send_has_ephemeral_card_and_preserves_new_draft_and_story(self):
        self.run_js(r"""
get('action').value='I wait.';get('autoplay').checked=true;
const messages=app.state.messages,campaign=app.state.active;
const pending=app.sendAction();get('action').value='I look towards the bell.';
rejectResponse(rejectedError());await pending;
assert.equal(panel().parentNode.className,'gm-rejection-card');
assert.equal(panel().parentNode.parentNode,get('story-feed'));
assert.equal(get('action').value,'I look towards the bell.');
assert.equal(app.state.messages,messages);assert.equal(campaign.state.location,'Before');
assert.equal(app.spoken.length,0);assert.equal(app.painted.length,0);
assert.deepEqual(storageWrites,[['sf_model','qwen3:8b']]);assert.equal(blobs.length,0);
""")

    def test_download_requires_click_contains_only_report_and_revokes_object_url(self):
        self.run_js(r"""
get('action').value='I wait.';const pending=app.sendAction();rejectResponse(rejectedError());await pending;
assert.equal(downloads.length,0);assert.equal(blobs.length,0);assert.equal(app.calls.length,1);
downloadButton().onclick();
assert.equal(downloads.length,1);assert.equal(downloads[0].name,'Storyforge-rejected-replies.json');
assert.equal(blobs[0].options.type,'application/json');
const report=JSON.parse(blobs[0].parts[0]);
assert.deepEqual(Object.keys(report),['error','gm_diagnostics']);
assert.equal(report.gm_diagnostics.attempts[0].narration,privateText);
assert.equal(report.gm_diagnostics.requested_model,'ministral-3:14b');
assert.equal(JSON.stringify(report).includes('"campaign_id"'),false);
assert.equal(revoked.length,0);assert.ok(timers.some(timer=>timer.delay>=1000));
for(const timer of timers)timer.fn();
assert.deepEqual(revoked,[downloads[0].href]);
assert.equal(app.calls.length,1);assert.deepEqual(storageWrites,[['sf_model','qwen3:8b']]);
""")

    def test_missing_download_api_keeps_inspection_available_and_explains_failure(self):
        self.run_js(r"""
get('action').value='I wait.';const pending=app.sendAction();rejectResponse(rejectedError());await pending;
context.URL=undefined;downloadButton().onclick();
assert.ok(app.notices.some(notice=>notice.fail&&notice.text.includes('could not download')));
assert.ok(panel().textContent.includes(privateText));assert.equal(downloads.length,0);
""")

    def test_next_send_clears_diagnostics_before_response(self):
        self.run_js(r"""
get('action').value='I wait.';let pending=app.sendAction();rejectResponse(rejectedError());await pending;
const oldPanel=panel();nextResponse();pending=app.sendAction();
assert.equal(document.contains(oldPanel),false);assert.equal(panels().length,0);
rejectResponse(new Error('Offline'));await pending;assert.equal(panels().length,0);
""")

    def test_next_retry_clears_diagnostics_and_keeps_feedback(self):
        self.run_js(r"""
app.openStoryMessageAction(2,'retry');get('story-correction-reason').value='Do not replay the opening.';
let pending=get('confirm-story-correction').onclick();rejectResponse(rejectedError());await pending;
const oldPanel=panel();nextResponse();pending=get('confirm-story-correction').onclick();
assert.equal(document.contains(oldPanel),false);assert.equal(panels().length,0);
assert.equal(get('story-correction-reason').value,'Do not replay the opening.');
rejectResponse(new Error('Offline'));await pending;
""")

    def test_rendering_saved_messages_clears_ephemeral_diagnostics(self):
        self.run_js(r"""
get('action').value='I wait.';const pending=app.sendAction();rejectResponse(rejectedError());await pending;
const oldPanel=panel();ui.renderMessages();
assert.equal(document.contains(oldPanel),false);assert.equal(panels().length,0);
assert.ok(!htmlWrites.at(-1).includes(privateText));
assert.equal(app.state.lastNarration,'A guard watches.');
""")

    def test_navigation_removes_visible_private_draft_and_disables_stale_download(self):
        self.run_js(r"""
get('action').value='I wait.';const pending=app.sendAction();rejectResponse(rejectedError());await pending;
const oldPanel=panel(),download=downloadButton().onclick;app.toLibrary();
assert.equal(document.contains(oldPanel),false);assert.equal(panels().length,0);
download();assert.equal(downloads.length,0);assert.equal(blobs.length,0);
""")

    def test_opening_campaign_clears_private_panel_before_campaign_fetch_finishes(self):
        self.run_js(r"""
get('action').value='I wait.';const pending=app.sendAction();rejectResponse(rejectedError());await pending;
const oldPanel=panel(),download=downloadButton().onclick;
nextResponse();const opening=app.openCampaign('second');
assert.equal(document.contains(oldPanel),false);assert.equal(panels().length,0);
download();assert.equal(downloads.length,0);
rejectResponse(new Error('Campaign temporarily unavailable'));await opening;
""")

    def test_pending_send_failure_cannot_expose_previous_campaign_draft(self):
        self.run_js(r"""
get('action').value='I wait.';const pending=app.sendAction();
const next={id:'second',state:{location:'Other town'}},messages=[{id:99,role:'gm',content:'Other story.'}];
app.state.active=next;app.state.messages=messages;
rejectResponse(rejectedError());await pending;
assert.equal(panels().length,0);assert.equal(app.state.messages,messages);
assert.equal(next.state.location,'Other town');assert.equal(app.spoken.length,0);
assert.ok(app.notices.some(notice=>notice.text==='The previous adventure could not be updated. Reopen it to retry.'));
""")

    def test_leaving_and_returning_same_campaign_during_retry_does_not_attach_old_draft(self):
        self.run_js(r"""
app.openStoryMessageAction(2,'retry');const status=get('story-correction-status');
const pending=get('confirm-story-correction').onclick();app.toLibrary();
// Home retains the active campaign object, so the view counter must also protect this case.
rejectResponse(rejectedError());await pending;
assert.equal(panels().length,0);assert.ok(!status.textContent.includes(privateText));
assert.ok(!status.textContent.includes('failed its player-control check'));
""")

    def test_replaced_modal_cannot_receive_pending_retry_diagnostics(self):
        self.run_js(r"""
app.openStoryMessageAction(2,'retry');const pending=get('confirm-story-correction').onclick();
app.showModal('OTHER','Other settings','<p id="other-content">Settings</p>');
rejectResponse(rejectedError());await pending;
assert.equal(panels().length,0);assert.equal(get('modal-title').textContent,'Other settings');
assert.equal(get('story-correction-status'),null);
""")

    def test_opening_and_closing_modal_clear_existing_diagnostics(self):
        self.run_js(r"""
get('action').value='I wait.';let pending=app.sendAction();rejectResponse(rejectedError());await pending;
app.openStoryMessageAction(2,'retry');assert.equal(panels().length,0);
nextResponse();pending=get('confirm-story-correction').onclick();rejectResponse(rejectedError());await pending;
const oldPanel=panel();app.closeModal();assert.equal(document.contains(oldPanel),false);
assert.equal(panels().length,0);assert.equal(get('modal').classList.contains('hidden'),true);
""")


if __name__ == '__main__':
    unittest.main()
