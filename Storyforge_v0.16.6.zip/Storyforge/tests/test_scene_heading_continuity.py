"""Established scene labels survive unchanged turns and legacy sparse state.

All story content here is synthetic. No user's submitted prose is included.
"""
import copy
import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import engine


LABELS = {'location': 'Lantern Pier', 'parent_area': 'Greyhaven', 'time_of_day': 'Dusk'}
HEADER = '[Lantern Pier - Greyhaven - Dusk]'
INTRO = (HEADER + '\n\n'
         'At Lantern Pier in Greyhaven, dusk gathers beneath the harbour cranes. '
         'Dockhands lower a canvas-wrapped crate onto the wet stones while a customs clerk '
         'counts three unclaimed parcels. A small brass bell hangs beside the locked warehouse.')
FRESH = ('Under the customs awning, a courier breaks the wax seal on a parcel. '
         'Inside rests a cracked compass; its needle points inland rather than north.\n\n'
         '"The sender paid for an answer before sunset," the courier tells the quartermaster. '
         'The quartermaster places a blank receipt beside the compass.')
ALTERNATIVE = ('A brass token clatters from the parcel onto the counter. '
               'Its worn rim bears a miniature lighthouse with a red enamel flame.\n\n'
               'The quartermaster checks the token against a ledger, then turns the book '
               'toward the courier. "This consignment was cancelled yesterday," the quartermaster says.')
MOVE_BODY = ('The Customs Office stands in Greyhaven beneath a sky now dark with night. '
             'A ledger lies open on the reception desk; the final entry is crossed out in green ink.\n\n'
             'Behind the desk, the inspector unlocks a narrow drawer and removes a copper seal. '
             '"That compass was registered to a vessel that never sailed," the inspector says.')
MOVE = {'location': 'Customs Office', 'parent_area': 'Greyhaven', 'time_of_day': 'Night',
        'evidence': {key: MOVE_BODY.split('\n\n')[0] for key in ('location', 'parent_area', 'time_of_day')}}


def output(narration, changes=None):
    return json.dumps({'narration': narration, 'state_updates': changes or {}})


class SceneHeadingContinuityTests(unittest.TestCase):
    def setUp(self):
        directory = self.enterContext(tempfile.TemporaryDirectory())
        self.con = engine.open_db(Path(directory) / 'synthetic.db')
        self.addCleanup(self.con.close)
        self.world = engine.make_world(self.con, {
            'title': 'Harbour of Vale',
            'description': 'A story about Greyhaven, its cargo disputes and the lighthouse keepers.'})
        campaign = engine.new_campaign(self.con, {'world_id': self.world['id'], 'pc_name': 'Riven'})
        self.cid = campaign['id']
        self.insert_legacy(INTRO)

    def insert_legacy(self, narration):
        with self.con:
            self.con.execute('INSERT INTO messages (campaign_id,role,content,created_at) VALUES (?,?,?,?)',
                             (self.cid, 'gm', narration, engine.now()))

    def set_labels(self, **labels):
        state = engine.get_campaign(self.con, self.cid)['state']
        for field in LABELS:
            state.pop(field, None)
        state.update(labels)
        with self.con:
            self.con.execute('UPDATE campaigns SET state_json=? WHERE id=?', (json.dumps(state), self.cid))

    def snapshot(self):
        return list(self.con.iterdump())

    def turn(self, narration=FRESH, changes=None, action='I inspect the parcel.'):
        calls = []

        def chat(messages, _model):
            calls.append(copy.deepcopy(messages))
            return output(narration, changes)

        chat.requires_state_evidence = True
        result = engine.play_turn(self.con, self.cid, action, chat=chat)
        return result, calls

    def assert_labels(self, result, labels=None):
        labels = labels or LABELS
        expected = '[' + ' - '.join(labels[field] for field in LABELS) + ']'
        self.assertTrue(result['narration'].startswith(expected + '\n\n'), result['narration'])
        self.assertEqual(result['narration'].count('['), 1)
        self.assertEqual({field: result['state'].get(field) for field in LABELS}, labels)

    def test_empty_updates_and_missing_header_recover_labels_from_the_safe_legacy_scene(self):
        self.set_labels(location='Unknown')
        result, calls = self.turn()
        self.assert_labels(result)
        self.assertEqual(len(calls), 1)
        self.assertEqual(result['messages'][0]['content'], INTRO)

    def test_placeholder_model_header_does_not_erase_established_place_and_time(self):
        self.set_labels(location='Unknown')
        result, _ = self.turn('[Unknown - Harbour of Vale - Time unspecified]\n\n' + FRESH)
        self.assert_labels(result)
        self.assertNotIn('Time unspecified', result['narration'])
        self.assertNotIn('[Unknown', result['narration'])

    def test_matching_valid_model_header_remains_single_and_updates_sparse_legacy_state(self):
        self.set_labels()
        result, _ = self.turn(HEADER + '\n\n' + FRESH)
        self.assert_labels(result)

    def test_meaningful_canonical_state_takes_precedence_over_an_older_heading(self):
        canonical = {'location': 'Harbour Archive', 'parent_area': 'Greyhaven', 'time_of_day': 'Dawn'}
        self.set_labels(**canonical)
        result, _ = self.turn()
        self.assert_labels(result, canonical)

    def test_canonical_fields_and_safe_heading_fill_only_the_missing_components(self):
        self.set_labels(location='Harbour Archive', parent_area='Greyhaven')
        result, _ = self.turn()
        self.assert_labels(result, {**LABELS, 'location': 'Harbour Archive'})

    def test_latest_safe_prior_heading_wins_when_canonical_labels_are_missing(self):
        self.set_labels(location='Unknown')
        recent = ('[Tide Chapel - Greyhaven - Dawn]\n\n'
                  'Inside the Tide Chapel, a sacristan extinguishes the last funeral candle. '
                  'At dawn, daylight spills across Greyhaven through the glass roof onto a row of empty benches.')
        self.insert_legacy(recent)
        result, _ = self.turn()
        self.assert_labels(result, {'location': 'Tide Chapel', 'parent_area': 'Greyhaven', 'time_of_day': 'Dawn'})

    def test_unsafe_heading_is_not_promoted_into_canonical_scene_labels(self):
        self.set_labels(location='Unknown')
        self.insert_legacy('[You decide to sail - Greyhaven - Midnight]\n\n'
                           'A harbour guard folds a tide chart beside the customs lantern. '
                           'Two empty barges knock against their mooring posts.')
        result, _ = self.turn()
        self.assert_labels(result)
        self.assertNotIn('You decide', json.dumps(result['state']))

    def test_evidence_backed_move_replaces_the_old_heading_and_state_after_acceptance(self):
        self.set_labels(**LABELS)
        result, _ = self.turn('[Customs Office - Greyhaven - Night]\n\n' + MOVE_BODY,
                              MOVE, action='I walk into the Customs Office.')
        self.assert_labels(result, {'location': 'Customs Office', 'parent_area': 'Greyhaven', 'time_of_day': 'Night'})

    def test_rejected_state_proposal_does_not_persist_recovered_legacy_labels(self):
        self.set_labels(location='Unknown')
        before = self.snapshot()
        calls = []

        def chat(messages, _model):
            calls.append(copy.deepcopy(messages))
            return output(FRESH, {'location': 'High Tower', 'evidence': {'location': 'A nonexistent sentence.'}})

        chat.requires_state_evidence = True
        with self.assertRaisesRegex(ValueError, 'Nothing was saved'):
            engine.play_turn(self.con, self.cid, 'I inspect the parcel.', chat=chat)
        self.assertEqual(len(calls), 2)
        self.assertEqual(self.snapshot(), before)

    def test_retry_uses_its_checkpoint_and_prior_scene_instead_of_a_later_location(self):
        self.set_labels(location='Unknown')
        first, _ = self.turn()
        target = first['messages'][-1]['id']
        self.turn('[Customs Office - Greyhaven - Night]\n\n' + MOVE_BODY,
                  MOVE, action='I walk into the Customs Office.')
        result = engine.retry_message(self.con, self.cid, target,
            feedback='Describe the parcel from the same established scene.',
            chat=lambda *_: output(ALTERNATIVE))
        self.assert_labels(result)
        self.assertEqual([message['role'] for message in result['messages']], ['gm', 'player', 'gm'])
        self.assertEqual(result['messages'][0]['content'], INTRO)
        self.assertNotIn(MOVE_BODY, '\n'.join(message['content'] for message in result['messages']))

    def test_checkpointed_header_only_values_do_not_become_state_on_a_later_turn(self):
        with self.con:
            self.con.execute('DELETE FROM messages WHERE campaign_id=?', (self.cid,))
        self.set_labels(location='Lantern Pier')
        first, _ = self.turn('[Lantern Pier - Imaginary District - Midnight]\n\n' + FRESH,
                              action='__START__')
        self.assertTrue(first['messages'][-1]['has_checkpoint'])
        second, _ = self.turn(ALTERNATIVE)
        self.assertNotIn('parent_area', second['state'])
        self.assertNotIn('time_of_day', second['state'])
        self.assertNotIn('Imaginary District', second['narration'])

    def test_checkpointed_body_supported_legacy_labels_can_be_recovered(self):
        state = engine.get_campaign(self.con, self.cid)['state']
        message_id = engine.get_messages(self.con, self.cid)[0]['id']
        with self.con:
            self.con.execute('INSERT INTO turn_checkpoints VALUES (?,?,?,?)',
                             (message_id, json.dumps(state), json.dumps(state), '__START__'))
        result, _ = self.turn()
        self.assert_labels(result)

    def test_heading_cannot_move_an_established_scene_without_a_supported_patch(self):
        self.set_labels(**LABELS)
        before = self.snapshot()
        with self.assertRaisesRegex(ValueError, 'scene heading.*Nothing was saved'):
            self.turn('[High Tower - Greyhaven - Dusk]\n\n' + FRESH)
        self.assertEqual(self.snapshot(), before)

    def test_placeholder_state_patch_cannot_erase_an_established_scene(self):
        self.set_labels(**LABELS)
        before = self.snapshot()
        changes = {'location': 'Unknown', 'evidence': {'location': 'The clerk writes Unknown on the label.'}}
        with self.assertRaisesRegex(ValueError, 'placeholder.*Nothing was saved'):
            self.turn(FRESH + '\n\nThe clerk writes Unknown on the label.', changes)
        self.assertEqual(self.snapshot(), before)


if __name__ == '__main__':
    unittest.main()
