"""Private rejected-draft inspection through real local HTTP and SQLite.

The Ollama endpoint is scripted and all campaign content is synthetic. Drafts
may return to the requesting browser after final semantic rejection, but must
not reach saved history, ordinary errors/logs or later model requests.
"""
from contextlib import closing, redirect_stderr
import io
import json
import unittest
from unittest.mock import patch

import engine
import server
import test_gm_http as gm_http


MODEL = 'ministral-3:14b'
HEADER = '[River Gate - Coast - Dusk]'
PROFILE_SECRET = 'PROFILE_SECRET_ONLY_IN_CONTEXT'
WORLD_SECRET = 'WORLD_SECRET_ONLY_IN_CONTEXT'
OLD_SCENE_SECRET = 'OLD_SCENE_SECRET_ONLY_IN_CONTEXT'
OTHER_CAMPAIGN_SECRET = 'OTHER_CAMPAIGN_SECRET_ONLY_IN_OTHER_SAVE'
ACTION_SECRET = 'ACTION_SECRET_ONLY_IN_REQUEST'
FEEDBACK_SECRET = 'FEEDBACK_SECRET_ONLY_IN_CONTEXT'
FIRST_MARKER = 'REJECTED_DRAFT_ONE_PRIVATE'
SECOND_MARKER = 'REJECTED_DRAFT_TWO_PRIVATE'
FIRST = HEADER + '\n\nI survey the quay. ' + FIRST_MARKER + '.'
SECOND = HEADER + '\n\nYou decide to trust the captain. ' + SECOND_MARKER + '.'
GOOD = (HEADER + '\n\nThe sentry lifts a brass lantern from the window ledge. '
        'A blue cargo seal lies beneath it. "The clerk left this before dusk," the sentry says.')
LATER = (HEADER + '\n\nThe boatman lowers a gangplank beside an empty mooring post. '
         'A gull circles above the warehouse roof while two porters check the passenger list.')


class DiagnosticScriptedOllama(gm_http.ScriptedOllama):
    """Add a real HTTP failure case without mocking the application adapter."""
    def do_POST(self):
        reply = self.server.replies[0]
        if isinstance(reply, dict) and '_http_status' in reply:
            request = json.loads(self.rfile.read(int(self.headers['Content-Length'])))
            self.server.requests.append(request)
            reply = self.server.replies.pop(0)
            body = reply.get('body', '').encode('utf-8')
            self.send_response(reply['_http_status'])
            self.send_header('Content-Type', 'text/plain')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        super().do_POST()


class GmRejectionDiagnosticsTests(unittest.TestCase):
    start_server = gm_http.GameMasterHttpTests.start_server
    post = gm_http.GameMasterHttpTests.post
    dump = gm_http.GameMasterHttpTests.dump

    def setUp(self):
        gm_http.GameMasterHttpTests.setUp(self)
        # Reuse the fixture's loopback endpoint with our extended handler.
        self.model.RequestHandlerClass = DiagnosticScriptedOllama
        self.console = io.StringIO()
        self.enterContext(redirect_stderr(self.console))
        with closing(engine.open_db(self.path)) as con:
            campaign = engine.get_campaign(con, self.cid)
            profile = {**campaign['pc_profile'], 'appearance': PROFILE_SECRET}
            state = {**campaign['state'], 'location': 'River Gate', 'parent_area': 'Coast',
                     'time_of_day': 'Dusk', 'scene_memory': {
                         'summary': 'A customs inquiry remains pending.', 'npcs': [],
                         'events': ['The lighthouse bell sounded twice.'],
                         'open_threads': ['A sealed letter awaits an answer.']}}
            con.execute('UPDATE campaigns SET pc_profile=?,state_json=? WHERE id=?',
                        (json.dumps(profile), json.dumps(state), self.cid))
            con.execute('UPDATE worlds SET description=? WHERE id=?',
                        ('The coast maintains a customs post. ' + WORLD_SECRET, campaign['world_id']))
            intro = (HEADER + '\n\nAt River Gate on the Coast, Dusk settles over the customs post. '
                     'The toll board bears a faded inventory number: ' + OLD_SCENE_SECRET + '.')
            first = con.execute('INSERT INTO messages (campaign_id,role,content,created_at) VALUES (?,?,?,?)',
                                (self.cid, 'gm', intro, engine.now())).lastrowid
            con.execute('INSERT INTO turn_checkpoints VALUES (?,?,?,?)',
                        (first, json.dumps(state), json.dumps(state), '__START__'))
            con.execute('INSERT INTO gm_feedback '
                        '(campaign_id,message_id,message_role,operation,reason,original_text,created_at) '
                        'VALUES (?,?,?,?,?,?,?)',
                        (self.cid, first, 'gm', 'retry',
                         'Keep the ferryman independent. ' + FEEDBACK_SECRET, intro, engine.now()))
            other = engine.new_campaign(con, {'world_id': campaign['world_id'],
                                             'pc_name': 'Unrelated Keeper',
                                             'appearance': OTHER_CAMPAIGN_SECRET})
            con.execute('INSERT INTO messages (campaign_id,role,content,created_at) VALUES (?,?,?,?)',
                        (other['id'], 'gm', OTHER_CAMPAIGN_SECRET, engine.now()))
            con.commit()

    def reject_twice(self, suffix='/turn', payload=None):
        self.model.replies = [gm_http.output(FIRST, location='Silver Tower'), gm_http.output(SECOND)]
        request = {'action': 'I listen. ' + ACTION_SECRET, 'model': MODEL} if payload is None else payload
        before = self.dump()
        with self.assertLogs(level='INFO') as logs:
            result = self.post(suffix, request, expected=400)
        self.assertEqual(self.dump(), before)
        self.assertEqual(len(self.model.requests), 2)
        self.assertNotIn(FIRST_MARKER, result['error'])
        self.assertNotIn(SECOND_MARKER, result['error'])
        self.assertNotIn(FIRST_MARKER, '\n'.join(logs.output) + self.console.getvalue())
        self.assertNotIn(SECOND_MARKER, '\n'.join(logs.output) + self.console.getvalue())
        return result

    def assert_diagnostics(self, result):
        self.assertEqual(set(result), {'error', 'gm_diagnostics'})
        diagnostics = result['gm_diagnostics']
        self.assertEqual(set(diagnostics), {'storyforge_version', 'requested_model', 'attempts'})
        self.assertEqual(diagnostics['storyforge_version'], server.updater.VERSION)
        self.assertEqual(diagnostics['requested_model'], MODEL)
        self.assertEqual([attempt['attempt'] for attempt in diagnostics['attempts']], [1, 2])
        self.assertEqual([attempt['narration'] for attempt in diagnostics['attempts']], [FIRST, SECOND])
        first, second = diagnostics['attempts']
        self.assertTrue(any('first-person' in issue for issue in first['violations']))
        self.assertIn('state change lacks visible evidence: location', first['violations'])
        self.assertTrue(any('unrequested player' in issue for issue in second['violations']))
        self.assertEqual(json.loads(first['state_updates_json']), {'location': 'Silver Tower'})
        self.assertEqual(json.loads(second['state_updates_json']), {})
        for attempt in diagnostics['attempts']:
            self.assertEqual(set(attempt), {'attempt', 'narration', 'violations', 'state_updates_json',
                                            'state_updates_truncated'})
            self.assertLessEqual(len(attempt['narration']), 12000)
            self.assertLessEqual(len(attempt['state_updates_json']), 8000)
            self.assertLessEqual(len(attempt['violations']), 30)
            self.assertTrue(all(isinstance(issue, str) and len(issue) < 500 for issue in attempt['violations']))
            self.assertFalse(attempt['state_updates_truncated'])

    def test_final_semantic_rejection_returns_both_bounded_drafts_and_exact_model_and_version(self):
        self.assert_diagnostics(self.reject_twice())
        for request in self.model.requests:
            self.assertEqual(request['model'], MODEL)
            self.assertNotIn('think', request)

    def test_diagnostics_exclude_context_profile_action_and_unrelated_campaign(self):
        result = self.reject_twice()
        self.assert_diagnostics(result)
        serialized = json.dumps(result)
        for secret in (PROFILE_SECRET, WORLD_SECRET, OLD_SCENE_SECRET, OTHER_CAMPAIGN_SECRET,
                       ACTION_SECRET, FEEDBACK_SECRET):
            self.assertNotIn(secret, serialized)
        # Verify that the positive controls really were supplied as context,
        # while an unrelated campaign's private content never entered it.
        first_request = json.dumps(self.model.requests[0]['messages'])
        for secret in (PROFILE_SECRET, WORLD_SECRET, OLD_SCENE_SECRET, ACTION_SECRET, FEEDBACK_SECRET):
            self.assertIn(secret, first_request)
        self.assertNotIn(OTHER_CAMPAIGN_SECRET, first_request)

    def test_rejected_drafts_are_absent_from_repair_requests_and_every_database_row(self):
        self.reject_twice()
        repair = json.dumps(self.model.requests[1]['messages'])
        saved = self.dump()
        for marker in (FIRST_MARKER, SECOND_MARKER):
            self.assertNotIn(marker, repair)
            self.assertNotIn(marker, saved)
        self.assertIn('REWRITE THIS TURN', repair)
        self.assertLessEqual(sum(len(message['content'].encode('utf-8'))
                                 for message in self.model.requests[1]['messages']), engine.GM_CONTEXT_BYTE_LIMIT)

    def test_exception_string_and_repr_do_not_expose_drafts_or_updates(self):
        self.model.replies = [gm_http.output(FIRST, location='Silver Tower'), gm_http.output(SECOND)]
        before = self.dump()
        with closing(engine.open_db(self.path)) as con:
            with self.assertRaises(engine.GMReplyRejected) as caught:
                engine.play_turn(con, self.cid, 'I listen.', model=MODEL)
        self.assertEqual(self.dump(), before)
        ordinary = str(caught.exception) + repr(caught.exception)
        for secret in (FIRST_MARKER, SECOND_MARKER, 'Silver Tower', PROFILE_SECRET, WORLD_SECRET):
            self.assertNotIn(secret, ordinary)
        self.assertIn('Nothing was saved', ordinary)
        self.assertEqual(caught.exception.diagnostics['requested_model'], MODEL)

    def test_large_validly_shaped_proposals_are_clipped_and_original_notes_remain_inspectable(self):
        long_body = (HEADER + '\n\nI survey the quay. ' + 'BOUND_ONLY_PRIVATE ' * 700)[:12000]
        events = [{'text': 'Private event ' + str(i) + ' ' + 'x' * 320,
                   'evidence': 'Private evidence ' + str(i) + ' ' + 'y' * 570} for i in range(8)]
        updates = {'location': 'Silver Tower', 'scene_memory': {'events': events},
                   'evidence': {'location': 'Silver Tower ' + 'z' * 950}}
        self.assertGreater(len(engine._gm_json(updates)), 8000)
        self.model.replies = [gm_http.output(long_body, **updates)] * 2
        before = self.dump()
        result = self.post('/turn', {'action': 'I listen.', 'model': MODEL}, expected=400)
        self.assertEqual(self.dump(), before)
        self.assertEqual(len(self.model.requests), 2)
        for attempt in result['gm_diagnostics']['attempts']:
            self.assertEqual(attempt['narration'], long_body)
            self.assertEqual(len(attempt['narration']), 12000)
            self.assertEqual(len(attempt['state_updates_json']), 8000)
            self.assertTrue(attempt['state_updates_truncated'])
            self.assertEqual(attempt['state_updates_json'], engine._gm_json(updates)[:8000])
            self.assertLessEqual(len(attempt['violations']), 30)

    def test_failed_retry_preserves_all_messages_memory_feedback_and_checkpoints(self):
        self.model.replies = [gm_http.output(GOOD)]
        first = self.post('/turn', {'action': 'I listen.', 'model': MODEL})
        target = first['messages'][-1]['id']
        event = 'The boatman lowers a gangplank beside an empty mooring post.'
        self.model.replies = [gm_http.output(LATER, journal_entry=event, evidence={'journal_entry': event})]
        self.post('/turn', {'action': 'I watch the boatman.', 'model': MODEL})
        self.model.requests.clear()
        result = self.reject_twice(f'/messages/{target}/retry',
                                  {'feedback': 'Preserve the scene and leave my choices open.', 'model': MODEL})
        self.assert_diagnostics(result)

    def test_successful_repair_returns_no_diagnostics_or_rejected_prose(self):
        self.model.replies = [gm_http.output(FIRST), gm_http.output(GOOD)]
        result = self.post('/turn', {'action': 'I listen.', 'model': MODEL})
        self.assertEqual(len(self.model.requests), 2)
        self.assertNotIn('gm_diagnostics', result)
        self.assertIn(GOOD.split('\n\n', 1)[1], result['narration'])
        self.assertNotIn(FIRST_MARKER, json.dumps(result))
        self.assertNotIn(FIRST_MARKER, self.dump())
        self.assertNotIn(FIRST_MARKER, json.dumps(self.model.requests[1]['messages']))

    def test_later_success_has_no_stale_diagnostics_after_an_earlier_rejected_request(self):
        self.reject_twice()
        self.model.requests.clear()
        self.model.replies = [gm_http.output(GOOD)]
        result = self.post('/turn', {'action': 'I listen.', 'model': MODEL})
        self.assertEqual(len(self.model.requests), 1)
        self.assertNotIn('gm_diagnostics', result)
        for marker in (FIRST_MARKER, SECOND_MARKER):
            self.assertNotIn(marker, json.dumps(result))
            self.assertNotIn(marker, json.dumps(self.model.requests[0]['messages']))

    def test_invalid_json_does_not_export_unparsed_partial_text(self):
        partial = '{"narration":"UNPARSED_PARTIAL_PRIVATE_STORY'
        self.model.replies = [partial] * 2
        before = self.dump()
        result = self.post('/turn', {'action': 'I listen.', 'model': MODEL}, expected=400)
        self.assertEqual(self.dump(), before)
        self.assertEqual(set(result), {'error'})
        self.assertNotIn('UNPARSED_PARTIAL_PRIVATE_STORY', json.dumps(result))
        self.assertNotIn('UNPARSED_PARTIAL_PRIVATE_STORY', json.dumps(self.model.requests[1]['messages']))

    def test_semantic_draft_then_invalid_json_does_not_export_earlier_diagnostics(self):
        self.model.replies = [gm_http.output(FIRST), '{"narration":"UNPARSED_CORRECTION_PRIVATE']
        before = self.dump()
        result = self.post('/turn', {'action': 'I listen.', 'model': MODEL}, expected=400)
        self.assertEqual(self.dump(), before)
        self.assertEqual(set(result), {'error'})
        self.assertNotIn(FIRST_MARKER, json.dumps(result))
        self.assertNotIn('UNPARSED_CORRECTION_PRIVATE', json.dumps(result))

    def test_incomplete_output_does_not_export_unsafe_partial_text(self):
        partial = '{"narration":"OUTPUT_LIMIT_PRIVATE_STORY'
        self.model.replies = [gm_http.at_output_limit(partial)] * 2
        before = self.dump()
        with self.assertLogs('engine.ollama', level='WARNING') as logs:
            result = self.post('/turn', {'action': 'I listen.', 'model': MODEL}, expected=503)
        self.assertEqual(self.dump(), before)
        self.assertEqual(set(result), {'error'})
        self.assertNotIn('OUTPUT_LIMIT_PRIVATE_STORY', json.dumps(result) + '\n'.join(logs.output))
        self.assertNotIn('OUTPUT_LIMIT_PRIVATE_STORY', json.dumps(self.model.requests[1]['messages']))

    def test_semantic_draft_then_transport_error_has_no_diagnostics_or_remote_body(self):
        self.model.replies = [gm_http.output(FIRST), {'_http_status': 503, 'body': 'REMOTE_ERROR_BODY_PRIVATE'}]
        before = self.dump()
        with self.assertLogs('engine.ollama', level='WARNING') as logs:
            result = self.post('/turn', {'action': 'I listen.', 'model': MODEL}, expected=503)
        self.assertEqual(self.dump(), before)
        self.assertEqual(set(result), {'error'})
        self.assertEqual(len(self.model.requests), 2)
        safe = json.dumps(result) + '\n'.join(logs.output)
        self.assertNotIn(FIRST_MARKER, safe)
        self.assertNotIn('REMOTE_ERROR_BODY_PRIVATE', safe)

    def test_truncation_then_semantic_rejection_exports_only_the_complete_second_attempt(self):
        partial = '{"narration":"UNSAFE_PARTIAL_FIRST_ATTEMPT'
        self.model.replies = [gm_http.at_output_limit(partial), gm_http.output(SECOND)]
        before = self.dump()
        with self.assertLogs('engine.ollama', level='WARNING') as logs:
            result = self.post('/turn', {'action': 'I listen.', 'model': MODEL}, expected=400)
        self.assertEqual(self.dump(), before)
        self.assertEqual(len(self.model.requests), 2)
        attempts = result['gm_diagnostics']['attempts']
        self.assertEqual(len(attempts), 1)
        self.assertEqual(attempts[0]['attempt'], 2)
        self.assertEqual(attempts[0]['narration'], SECOND)
        self.assertNotIn('UNSAFE_PARTIAL_FIRST_ATTEMPT', json.dumps(result) + '\n'.join(logs.output))
        self.assertNotIn('UNSAFE_PARTIAL_FIRST_ATTEMPT', json.dumps(self.model.requests[1]['messages']))

    def test_budget_error_has_no_diagnostics_and_does_not_contact_the_model(self):
        before = self.dump()
        with patch.object(engine, 'GM_TURN_BUDGET', 0):
            result = self.post('/turn', {'action': 'I listen.', 'model': MODEL}, expected=503)
        self.assertEqual(self.dump(), before)
        self.assertEqual(set(result), {'error'})
        self.assertEqual(self.model.requests, [])

    def test_attributed_single_quoted_npc_contractions_pass_the_actual_model_protocol(self):
        dialogue = (HEADER + "\n\nThe sentry says, 'I don't keep the western key. I'll fetch the clerk.' "
                    'The boatman folds the passenger list beside a closed customs ledger.')
        self.model.replies = [gm_http.output(dialogue)]
        result = self.post('/turn', {'action': 'I listen.', 'model': MODEL})
        self.assertEqual(len(self.model.requests), 1)
        self.assertEqual(result['narration'], dialogue)
        self.assertNotIn('gm_diagnostics', result)
        self.assertTrue(result['messages'][-1]['has_checkpoint'])

    def test_attributed_curly_quoted_npc_contractions_pass_the_actual_model_protocol(self):
        dialogue = (HEADER + '\n\nThe sentry says, ‘I don’t keep the western key. I’ll fetch the clerk.’ '
                    'The boatman folds the passenger list beside a closed customs ledger.')
        self.model.replies = [gm_http.output(dialogue)]
        result = self.post('/turn', {'action': 'I listen.', 'model': MODEL})
        self.assertEqual(len(self.model.requests), 1)
        self.assertEqual(result['narration'], dialogue)
        self.assertNotIn('gm_diagnostics', result)


if __name__ == '__main__':
    unittest.main()
