"""Opening-scene agency false positives with controls for real player authorship.

The user's failing model reply is unavailable. These are independently
reproduced grammar cases, not a reconstruction of that private response.
"""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import engine


class OpeningAgencyRegressionTests(unittest.TestCase):
    def violations(self, narration, action='__START__'):
        return engine.player_agency_violations(narration, 'Xeminas', action)

    def test_direct_questions_offer_player_choices(self):
        for narration in (
            'What do you say to the porter?',
            'Will you turn toward the voice, or stay here?',
            'Which path will you choose?',
        ):
            with self.subTest(narration=narration):
                self.assertEqual(self.violations(narration), [])

    def test_question_marks_do_not_exempt_separate_player_actions(self):
        for narration in (
            'You choose the footbridge. What do you say to the porter?',
            'Will you turn toward the voice? You step onto the train.',
            'You say that you will join the school. Why would you wait?',
            "You turn to the porter, don't you?",
        ):
            with self.subTest(narration=narration):
                self.assertTrue(self.violations(narration))

    def test_named_npc_dialogue_labels_remain_first_person(self):
        for narration in (
            'Hagrid: "I am here to collect the first-years."',
            '**Hagrid:** "I am here to collect the first-years."',
        ):
            with self.subTest(narration=narration):
                self.assertEqual(self.violations(narration), [])

    def test_npc_dialogue_attribution_can_add_or_murmur(self):
        for narration in (
            'Professor Rowan adds, "I teach astronomy."',
            'Professor Rowan murmurs, "I teach astronomy."',
            '"I teach astronomy," Professor Rowan adds.',
        ):
            with self.subTest(narration=narration):
                self.assertEqual(self.violations(narration), [])

    def test_npc_attribution_allowance_does_not_authorize_player_words(self):
        for narration in (
            'Xeminas: "I am here to join the school."',
            '**Xeminas:** "I am here to join the school."',
            'The Dark Monarch: "I am here to join the school."',
            'You add, "I am here to join the school."',
            'Xeminas murmurs, "I am here to join the school."',
            '"I am here to join the school," Xeminas adds.',
        ):
            with self.subTest(narration=narration):
                self.assertTrue(self.violations(narration))

    def test_player_viewpoint_labels_cannot_masquerade_as_npc_names(self):
        for narration in (
            'Your Thoughts: "I choose to join the school."',
            'Your Mind: "I choose to join the school."',
            'Your Character: "I choose to join the school."',
            'Xeminas POV: "I choose to join the school."',
            'Xeminas\'s Thoughts: "I choose to join the school."',
            '**Your Thoughts:** "I choose to join the school."',
        ):
            with self.subTest(narration=narration):
                self.assertTrue(self.violations(narration))

    def test_exact_authored_added_and_murmured_dialogue_remains_allowed(self):
        for action, narration in (
            ('I add "I am ready."', '"I am ready," you add.'),
            ('I murmur "I am ready."', '"I am ready," you murmur.'),
        ):
            with self.subTest(action=action):
                self.assertEqual(self.violations(narration, action), [])

    def test_adding_an_object_does_not_authorize_spoken_action_substrings(self):
        for narration in (
            '"A coin," you add.',
            'You add, "A coin."',
        ):
            with self.subTest(narration=narration):
                self.assertTrue(self.violations(narration, 'I add a coin to the purse.'))

    def test_quoted_period_cannot_hide_a_coordinated_player_action(self):
        for narration in (
            'You say "Hello." and raise your hand.',
            'You say "Hello!" and choose the footbridge.',
        ):
            with self.subTest(narration=narration):
                self.assertTrue(self.violations(narration, 'I say "Hello."'))

    def test_partial_player_names_and_viewpoint_pronouns_are_not_npc_labels(self):
        for label in ('Harry', 'Potter', 'He', 'She', 'They'):
            with self.subTest(label=label):
                self.assertTrue(engine.player_agency_violations(
                    label+': "I choose the footbridge."', 'Harry Potter', '__START__'))
        self.assertEqual(engine.player_agency_violations(
            'Hagrid: "I look after the grounds."', 'Harry Potter', '__START__'), [])

    def test_opening_does_not_authorize_player_posture_or_motion(self):
        for narration in (
            'You stand on the platform at Hogsmeade Station. Rain taps against the canopy.',
            'You are standing beneath the station canopy. A porter raises his lantern.',
            'You stand up from the bench.',
            'You stand aside to let the porter pass.',
            'You stand on the platform and choose the footbridge.',
            'You stand on the platform and say, "Take me to Hogwarts."',
            'You step onto the platform.',
            'You turn toward the voice.',
        ):
            with self.subTest(narration=narration):
                self.assertTrue(self.violations(narration))

    def test_first_person_player_prose_is_never_static_position_or_dialogue(self):
        for narration in (
            'I stand on the platform at Hogsmeade Station.',
            'I choose the footbridge.',
            'I turn toward the voice.',
            'I say that I am here to join the school.',
            'My feet rest on the station platform while I choose the footbridge.',
        ):
            with self.subTest(narration=narration):
                self.assertTrue(self.violations(narration))


if __name__ == '__main__':
    unittest.main()
