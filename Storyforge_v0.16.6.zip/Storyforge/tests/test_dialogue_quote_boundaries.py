"""Bounded NPC quotations must distinguish apostrophes from closing quotes.

These are synthetic grammar cases. The owner's latest rejected model draft was
not available, so they do not establish the cause of that individual failure.
"""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import engine


class DialogueQuoteBoundaryTests(unittest.TestCase):
    profile = {'aliases': 'Lady Willow', 'pronouns': 'she/her', 'species': 'High Elf'}

    def findings(self, narration, action='I watch the porter.'):
        return engine.player_agency_violations(
            narration, 'Mira', action, pc_profile=self.profile)

    def test_ambiguous_closers_cannot_swallow_player_actions_into_later_possessives(self):
        for subject in ('You', 'you', 'Mira', 'Lady Willow', 'I'):
            predicate = 'choose' if subject in ('You', 'you', 'I') else 'chooses'
            for ending in (' beside the porters’ luggage.',
                           ". The guard says, 'Good.’",
                           '. The guard says, ‘Good.’'):
                narration = ('The porter says, ‘I’ll help’' + subject + ' '
                             + predicate + ' the carriage' + ending)
                with self.subTest(subject=subject, ending=ending):
                    self.assertTrue(self.findings(narration), narration)

    def test_common_apostrophe_names_remain_inside_npc_dialogue(self):
        for narration in ("The porter says, 'I'll find O'Brien's pass in my carriage.'",
                          'The porter says, ‘I’ll find O’Brien’s pass in my carriage.’',
                          'The porter says, ‘I’ll find D’Artagnan in my carriage.’'):
            with self.subTest(narration=narration):
                self.assertEqual(self.findings(narration), [])

    def test_surname_prefix_cannot_hide_an_explicit_player_clause(self):
        for opener, apostrophe, closer in (("'", "'", "'"), ('‘', '’', '’')):
            for prefix, actor, verb in (('D', 'You', 'choose'), ('O', 'Mira', 'chooses'),
                                         ('O', 'Lady Willow', 'chooses'), ('D', 'I', 'choose')):
                text = ('The porter says, ' + opener + 'I was speaking with ' + prefix
                        + apostrophe + actor + ' ' + verb + ' the carriage beside the porters'
                        + closer + ' luggage.')
                with self.subTest(text=text):
                    self.assertTrue(self.findings(text))

    def test_single_letter_name_does_not_authorize_boundary_swallowing(self):
        for name in ('D', 'S'):
            text = 'The porter says, ‘I’ll help’' + name + ' chooses the carriage beside the porters’ luggage.'
            self.assertTrue(engine.player_agency_violations(text, name, 'I wait.'))
        for name, spoken in (('D', 'I’d choose the blue carriage.'), ('S', 'The driver’s waiting by my carriage.')):
            text = 'The porter says, ‘' + spoken + '’'
            self.assertEqual(engine.player_agency_violations(text, name, 'I wait.'), [])

    def test_npc_straight_single_quotes_allow_contractions(self):
        for narration in (
            "The porter says, 'I'll show you my carriage.'",
            "'I'll show you my carriage,' the porter says.",
            "Porter: 'I'll show you my carriage.'",
            "The porter says, 'I can't carry all our trunks.'",
        ):
            with self.subTest(narration=narration):
                self.assertEqual(self.findings(narration), [])

    def test_npc_curly_single_quotes_allow_contractions(self):
        for narration in (
            'The porter says, ‘I’ll show you my carriage.’',
            '‘I’ll show you my carriage,’ the porter says.',
            'Porter: ‘I’ll show you my carriage.’',
            'The porter says, ‘I can’t carry all our trunks.’',
        ):
            with self.subTest(narration=narration):
                self.assertEqual(self.findings(narration), [])

    def test_mixed_apostrophe_styles_inside_single_quotes_are_allowed(self):
        for narration in (
            "The porter says, 'I’ll show you my carriage.'",
            "The porter says, ‘I'll show you my carriage.’",
        ):
            with self.subTest(narration=narration):
                self.assertEqual(self.findings(narration), [])

    def test_word_internal_possessives_do_not_end_npc_quotations(self):
        for narration in (
            "The porter says, 'I have the driver's pass in my pocket.'",
            'The porter says, ‘I have the driver’s pass in my pocket.’',
            "The porter says, 'I have O'Brien's pass in my pocket.'",
            'The porter says, ‘I have O’Brien’s pass in my pocket.’',
        ):
            with self.subTest(narration=narration):
                self.assertEqual(self.findings(narration), [])

    def test_quote_match_contains_whole_contraction_and_possessive(self):
        for quotation in (
            "'I'll collect the driver's trunks from my carriage.'",
            '‘I’ll collect the driver’s trunks from my carriage.’',
        ):
            with self.subTest(quotation=quotation):
                match = engine._QUOTED_OR_WRITTEN.fullmatch(quotation)
                self.assertIsNotNone(match)
                self.assertEqual(match.group(), quotation)

    def test_exact_authorized_player_dialogue_keeps_contractions(self):
        for narration in (
            "Mira says, 'I'll wait here.'",
            'Mira says, ‘I’ll wait here.’',
            "'I'll wait here,' you say.",
        ):
            with self.subTest(narration=narration):
                self.assertEqual(self.findings(narration, 'I say "I\'ll wait here."'), [])

    def test_player_name_and_alias_cannot_gain_invented_contracted_dialogue(self):
        for name in ('Mira', 'Lady Willow', 'You'):
            for quotation in ("'I'll follow you.'", '‘I’ll follow you.’'):
                with self.subTest(name=name, quotation=quotation):
                    self.assertIn('invented player dialogue',
                                  self.findings(name + ' says, ' + quotation))

    def test_unattributed_first_person_single_quotes_still_fail(self):
        for quotation in ("'I'll choose my carriage.'", '‘I’ll choose my carriage.’'):
            with self.subTest(quotation=quotation):
                self.assertIn('unattributed first-person dialogue', self.findings(quotation))

    def test_unmatched_quotes_cannot_close_on_internal_apostrophes(self):
        for narration in (
            "The porter says, 'I'll show you my carriage.",
            'The porter says, ‘I’ll show you my carriage.',
            "The porter says, 'I have the driver's pass in my pocket.",
            'The porter says, ‘I have the driver’s pass in my pocket.',
        ):
            with self.subTest(narration=narration):
                self.assertIsNone(engine._QUOTED_OR_WRITTEN.search(narration))
                self.assertTrue(self.findings(narration))

    def test_internal_apostrophes_in_player_prose_are_not_quote_openers(self):
        for narration in (
            "I'll choose the carriage because you're waiting.",
            'I’ll choose the carriage because you’re waiting.',
            "My driver's lantern illuminates my chosen path.",
        ):
            with self.subTest(narration=narration):
                self.assertTrue(self.findings(narration))

    def test_player_actions_after_npc_quotations_still_fail(self):
        for narration in (
            "The porter says, 'I'll help.' You choose the carriage.",
            'The porter says, ‘I’ll help.’ Lady Willow chooses the carriage.',
            "The porter says, 'I'll help.' I choose the carriage.",
        ):
            with self.subTest(narration=narration):
                self.assertTrue(self.findings(narration))

    def test_player_actions_before_npc_quotations_still_fail(self):
        self.assertTrue(self.findings(
            "You choose the carriage. The porter says, 'I'll help.'"))

    def test_adjacent_quote_closer_cannot_swallow_player_actions_between_quotes(self):
        for opener, apostrophe, closer in (("'", "'", "'"), ('‘', '’', '’')):
            for actor in ('You', 'you', 'Mira', 'Lady Willow'):
                narration = ('The porter says, ' + opener + 'I' + apostrophe + 'll help' + closer +
                             actor + ' choose' + ('' if actor.lower() == 'you' else 's') +
                             ' the carriage. The guard says, ' + opener + 'Good.' + closer)
                with self.subTest(opener=opener, actor=actor):
                    self.assertTrue(self.findings(narration))

    def test_curly_quote_cannot_extend_through_another_opening_quote(self):
        for action in ('You choose the carriage.', 'I choose my carriage.',
                       'Lady Willow says, "I will follow you."'):
            narration = 'The porter says, ‘I’ll help’' + action + ' The guard says, ‘Good.’'
            with self.subTest(action=action):
                first = engine._QUOTED_OR_WRITTEN.search(narration)
                self.assertTrue(first is None or action not in first.group())
                self.assertTrue(self.findings(narration))

    def test_single_quotes_keep_the_existing_character_and_newline_bounds(self):
        for opener, closer in (("'", "'"), ('‘', '’')):
            quotation = opener + 'I ' + 'a' * 698 + closer
            self.assertIsNotNone(engine._QUOTED_OR_WRITTEN.fullmatch(quotation))
            self.assertIsNone(engine._QUOTED_OR_WRITTEN.fullmatch(
                opener + 'I ' + 'a' * 699 + closer))
            self.assertIsNone(engine._QUOTED_OR_WRITTEN.search(
                opener + 'I can help.\nMy carriage waits.' + closer))

    def test_legacy_filter_retains_npc_speech_and_removes_invented_player_speech(self):
        for opener, apostrophe, closer in (("'", "'", "'"), ('‘', '’', '’')):
            npc = ('The porter says, ' + opener + 'I' + apostrophe +
                   'll show you my carriage.' + closer)
            pc = ('Lady Willow says, ' + opener + 'I' + apostrophe +
                  'll pledge my loyalty.' + closer)
            source = pc + '\n\n' + npc
            with self.subTest(opener=opener):
                retained = engine._grounded_gm_prose(
                    source, 'Mira', '__START__', pc_profile=self.profile)
                self.assertEqual(retained, npc)
                self.assertEqual(self.findings(retained), [])


if __name__ == '__main__':
    unittest.main()
