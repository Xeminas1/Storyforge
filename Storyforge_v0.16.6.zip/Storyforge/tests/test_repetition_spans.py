"""Copied prose spans must not pass merely because surrounding prose is new.

All examples here are synthetic. These checks concern deterministic duplicate
detection, not the storytelling quality of any local model.
"""
import copy
import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import engine


HEADER = '[Northbridge Wharf - Alder Reach - Dusk]\n\n'
PASSAGE = (
    'Beyond the warehouse doors, three ferrymen wrestle a dripping fishing net onto the stones '
    'while their foreman argues with a tax collector over the missing copper seal on a battered '
    'wooden cargo chest near the landing stairs.')
OLD_PREFIX = (
    'The evening ferry reaches the outer landing beneath a sky streaked with orange clouds. '
    'Market stalls crowd the narrow causeway, their awnings sagging under the weight of rain. ')
OLD_END = (
    'A weathered bell marks the closing of the customs gate, and an apprentice hurries to gather '
    'the remaining lanterns before the night watch takes its place along the seawall.')
NEW_PREFIX = (
    'A child discovers a silver button beneath the bench and holds it toward the lamplight. '
    'The watch captain pauses beside the fountain to examine its unfamiliar crest. ')
NEW_END = (
    'From the courtyard comes a sudden clatter of crockery; the innkeeper emerges carrying '
    'a folded blanket and calling for the missing stable boy.')


def prior(text, role='gm'):
    return [{'role': role, 'content': HEADER + text}]


class RepetitionSpanTests(unittest.TestCase):
    def test_long_copied_passage_is_rejected_inside_different_surrounding_paragraphs(self):
        old = OLD_PREFIX + PASSAGE + ' ' + OLD_END
        new = NEW_PREFIX + PASSAGE + ' ' + NEW_END

        self.assertTrue(engine.gm_repetition_violations(HEADER + new, prior(old)))

    def test_changed_paragraph_breaks_and_quote_punctuation_do_not_hide_copied_prose(self):
        old = OLD_PREFIX + PASSAGE + ' "By lantern and law," the foreman says. ' + OLD_END
        new = (NEW_PREFIX + '\n\n' + PASSAGE.replace('doors,', 'doors —')
               + '\n\n“By lantern and law,” the foreman says. ' + NEW_END)

        self.assertTrue(engine.gm_repetition_violations(HEADER + new, prior(old)))

    def test_two_near_verbatim_sentences_are_rejected_without_one_long_exact_span(self):
        first = ('A stooped clerk sorts the sailors\' brass tokens into wooden trays while a red-haired '
                 'apprentice checks the names against yesterday\'s water-stained ledger.')
        second = ('Beside the customs window, a shaggy black dog noses a discarded glove and waits '
                  'patiently for its owner beneath the hanging scales.')
        old = OLD_PREFIX + first + ' ' + second + ' ' + OLD_END
        new_first = first.replace('red-haired', 'fair-haired').replace('wooden', 'painted')
        new_second = second.replace('black dog', 'brown dog').replace('patiently', 'silently')
        new = NEW_PREFIX + new_first + '\n\n' + new_second + ' ' + NEW_END

        self.assertTrue(engine.gm_repetition_violations(HEADER + new, prior(old)))

    def test_late_copied_passage_is_checked_beyond_the_old_similarity_prefix(self):
        old_padding = ' '.join(
            f'The northern customs office lists shipment {number} beside a blue wax stamp.'
            for number in range(45))
        new_padding = ' '.join(
            f'An eastern orchard worker gathers basket {number} under the yellow autumn leaves.'
            for number in range(45))
        self.assertGreater(len(old_padding), 3000)
        self.assertGreater(len(new_padding), 3000)
        old = old_padding + ' ' + PASSAGE + ' ' + OLD_END
        new = new_padding + ' ' + PASSAGE + ' ' + NEW_END

        self.assertTrue(engine.gm_repetition_violations(HEADER + new, prior(old)))

    def test_short_callback_with_reused_names_and_heading_remains_allowed(self):
        old = ('Captain Merrow still carries the brass whistle. ' + OLD_PREFIX + OLD_END)
        new = ('Captain Merrow still carries the brass whistle. ' + NEW_PREFIX + NEW_END)

        self.assertEqual(engine.gm_repetition_violations(HEADER + new, prior(old)), [])

    def test_recurring_npc_catchphrase_does_not_make_fresh_events_a_duplicate(self):
        old = OLD_PREFIX + 'The foreman says, "By lantern and law." ' + OLD_END
        new = NEW_PREFIX + '“By lantern and law,” the foreman says. ' + NEW_END

        self.assertEqual(engine.gm_repetition_violations(HEADER + new, prior(old)), [])

    def test_long_player_authored_quoted_question_is_not_counted_as_copied_narration(self):
        question = (
            'Which merchant last carried the sealed chest through the northern customs gate, '
            'who signed the disputed ledger beside the old ferry landing, and why was the '
            'missing copper seal never reported to the watch captain before yesterday evening?')
        old = OLD_PREFIX + 'The clerk repeats the question: "' + question + '" ' + OLD_END
        new = NEW_PREFIX + 'The captain reads the recorded question: “' + question + '” ' + NEW_END
        history = [{'role': 'player', 'content': 'I ask, "' + question + '"'}, *prior(old)]

        self.assertEqual(engine.gm_repetition_violations(HEADER + new, history), [])

    def test_one_recalled_substantial_sentence_does_not_trigger_multi_sentence_rule(self):
        callback = ('A narrow brass plaque above the window identifies the warehouse as the '
                    'property of the northern ferrymen\'s guild.')
        old = OLD_PREFIX + callback + ' ' + OLD_END
        new = NEW_PREFIX + callback + ' ' + NEW_END

        self.assertEqual(engine.gm_repetition_violations(HEADER + new, prior(old)), [])

    def test_two_short_recalled_sentences_are_insufficient_for_rejection(self):
        callback = 'The customs gate remains closed. The ferrymen still lack their copper seal.'
        old = OLD_PREFIX + callback + ' ' + OLD_END
        new = NEW_PREFIX + callback + ' ' + NEW_END

        self.assertEqual(engine.gm_repetition_violations(HEADER + new, prior(old)), [])

    def test_same_setting_vocabulary_in_different_events_is_not_repeated_narration(self):
        old = ('The customs clerk carries the ledger past the ferry landing. A tax collector '
               'waits beside the northern gate while a ferryman searches the wooden chest '
               'for his missing brass tokens. ' + OLD_END)
        new = ('At the ferry landing, the tax collector tears a page from the ledger. The customs '
               'clerk calls toward the northern gate; beneath a wooden chest, the ferryman '
               'finds a pair of broken scales instead of the missing brass tokens. ' + NEW_END)

        self.assertEqual(engine.gm_repetition_violations(HEADER + new, prior(old)), [])

    def test_player_messages_alone_do_not_count_as_earlier_gm_narration(self):
        old = OLD_PREFIX + PASSAGE + ' ' + OLD_END
        new = NEW_PREFIX + PASSAGE + ' ' + NEW_END

        self.assertEqual(engine.gm_repetition_violations(HEADER + new, prior(old, role='player')), [])

    def test_existing_exact_duplicate_and_within_reply_paragraph_checks_remain(self):
        complete = HEADER + OLD_PREFIX + PASSAGE + ' ' + OLD_END
        self.assertTrue(engine.gm_repetition_violations(complete, [{'role': 'gm', 'content': complete}]))
        self.assertTrue(engine.gm_repetition_violations(HEADER + PASSAGE + '\n\n' + PASSAGE, []))


class RepetitionSpanTurnTests(unittest.TestCase):
    def setUp(self):
        temporary = self.enterContext(tempfile.TemporaryDirectory())
        self.con = engine.open_db(Path(temporary) / 'story.db')
        self.addCleanup(self.con.close)
        world = engine.make_world(self.con, {
            'title': 'Alder Reach', 'description': 'Begin beside the Northbridge Wharf customs office.'})
        self.cid = engine.new_campaign(self.con, {'world_id': world['id'], 'pc_name': 'Wren'})['id']
        self.opening = HEADER + OLD_PREFIX + PASSAGE + ' ' + OLD_END
        engine.play_turn(self.con, self.cid, '__START__', chat=lambda *_: self.reply(self.opening))
        self.replay = HEADER + NEW_PREFIX + PASSAGE + ' ' + NEW_END

    @staticmethod
    def reply(text):
        return json.dumps({'narration': text, 'state_updates': {}})

    def test_partial_copy_is_repaired_without_adding_the_rejected_draft_to_history(self):
        calls = []
        fresh = HEADER + NEW_PREFIX + NEW_END

        def chat(messages, _model):
            calls.append(copy.deepcopy(messages))
            return self.reply(self.replay if len(calls) == 1 else fresh)

        result = engine.play_turn(self.con, self.cid, 'I inspect the crest on the button.', chat=chat)

        self.assertEqual(len(calls), 2)
        self.assertIn('narration repeats a substantial earlier GM passage', calls[1][-1]['content'])
        self.assertIn('not another arrival or introduction', calls[1][-1]['content'])
        self.assertEqual(sum(message['role'] == 'assistant' for message in calls[1]), 1)
        self.assertNotIn(self.replay, [message['content'] for message in calls[1]])
        self.assertEqual([message['role'] for message in result['messages']], ['gm', 'player', 'gm'])
        self.assertEqual(result['messages'][0]['content'], self.opening)
        self.assertEqual(result['messages'][-1]['content'], fresh)

    def test_two_partial_copies_fail_without_changing_messages_state_or_checkpoints(self):
        before = list(self.con.iterdump())
        calls = []

        def chat(messages, _model):
            calls.append(copy.deepcopy(messages))
            return self.reply(self.replay)

        with self.assertRaisesRegex(ValueError, 'substantial earlier GM passage.*Nothing was saved'):
            engine.play_turn(self.con, self.cid, 'I inspect the crest on the button.', chat=chat)

        self.assertEqual(len(calls), 2)
        self.assertEqual(list(self.con.iterdump()), before)


if __name__ == '__main__':
    unittest.main()
