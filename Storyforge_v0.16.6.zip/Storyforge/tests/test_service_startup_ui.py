"""Exercise local service startup controls without starting local programs."""
import unittest

import test_story_request_ui as story_ui


SERVICE_HARNESS = r"""
// Track markup and toggle state as well as the existing small request DOM fake.
const innerHtml=Object.getOwnPropertyDescriptor(Element.prototype,'innerHTML');
Object.defineProperty(Element.prototype,'innerHTML',{
  get(){return this.markup||'';},
  set(value){
    this.markup=value;innerHtml.set.call(this,value);
    for(const node of nodes.values())node.classList.toggle=(name,force)=>{
      const add=force===undefined?!node.classes.has(name):!!force;
      if(add)node.classes.add(name);else node.classes.delete(name);
      return add;
    };
  }
});
const timers=new Map();let nextTimer=0;
context.setTimeout=(callback,delay)=>{const id=++nextTimer;timers.set(id,{callback,delay});return id;};
context.clearTimeout=id=>timers.delete(id);
for(const id of ['neural-status','voice-engine','voices','installed-models','open-services'])nodes.set(id,new Element(id));
const serviceReplies=[];
context.serviceReply=(url,options)=>{
  assert.ok(serviceReplies.length,'Unexpected request: '+url);
  const reply=serviceReplies.shift();
  if(reply instanceof Error)throw reply;
  return typeof reply==='function'?reply(url,options):reply;
};
vm.runInContext(`request=async(url,options)=>{calls.push({url,options});return await serviceReply(url,options);}`,context);
const serviceUi=vm.runInContext('({openServicesModal,renderServiceStatus,watchServiceStartup,refreshInstalledModels})',context);
const serviceSnapshot={supported:true,enabled:true,starting:false,can_create_shortcut:true,
  settings:{enabled:true,ollama:true,kokoro:true,comfyui:true,comfyui_mode:'desktop',comfyui_path:'C:\\Program Files\\Comfy Desktop',comfyui_python:''},
  services:[{id:'ollama',name:'Ollama',state:'ready',detail:'Game Master connected.'},{id:'kokoro',name:'Kokoro',state:'offline',detail:'Voice service is not running.'}]
};
function copySnapshot(){return JSON.parse(JSON.stringify(serviceSnapshot));}
async function openServices(snapshot=copySnapshot()){
  serviceReplies.push(snapshot);await serviceUi.openServicesModal();
}
function deferred(){let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b;});return {promise,resolve,reject};}
"""


@unittest.skipUnless(story_ui.NODE, 'Node is required for service startup browser checks')
class ServiceStartupUiTests(unittest.TestCase):
    def run_js(self, script):
        story_ui.StoryRequestUiTests.run_js(self, SERVICE_HARNESS + '\n' + script)

    def test_status_text_is_escaped_and_state_classes_are_allowlisted(self):
        self.run_js(r"""
const html=serviceUi.renderServiceStatus([{id:'<img src=x>',name:'<script>bad()</script>',state:'ready" onclick="bad()',detail:'<svg onload="bad()"> & danger'}]);
assert.ok(!/<(?:img|script|svg)\b/.test(html));
assert.ok(html.includes('&lt;script&gt;'));
assert.ok(html.includes('&lt;svg'));
assert.ok(html.includes('service-state-offline'));
assert.ok(!html.includes('onclick'));
""")

    def test_saved_windows_settings_populate_comfyui_and_mode_fields(self):
        self.run_js(r"""
await openServices();
assert.equal(app.calls.length,1);assert.equal(app.calls[0].url,'/api/services');
assert.equal(get('services-enabled').checked,true);
assert.equal(get('services-comfyui-path').value,'C:\\Program Files\\Comfy Desktop');
assert.equal(get('services-options').disabled,false);
assert.equal(get('services-start').disabled,false);
assert.equal(get('services-shortcut').disabled,false);
assert.equal(get('services-comfyui-python-field').classList.contains('hidden'),true);
get('services-comfyui-mode').value='python';get('services-comfyui-mode').onchange();
assert.equal(get('services-comfyui-python-field').classList.contains('hidden'),false);
assert.ok(get('services-comfyui-path-label').textContent.includes('MAIN.PY'));
get('services-comfyui').checked=false;get('services-comfyui').onchange();
assert.equal(get('services-comfyui-settings').classList.contains('hidden'),true);
assert.equal(timers.size,0);
""")

    def test_save_and_start_use_typed_settings_then_one_start_request(self):
        self.run_js(r"""
await openServices();
get('services-enabled').checked=false;get('services-kokoro').checked=false;
get('services-comfyui-mode').value='python';
get('services-comfyui-path').value='  C:\\Art Studio\\ComfyUI\\main.py  ';
get('services-comfyui-python').value=' C:\\Art Studio\\venv\\Scripts\\python.exe ';
const saving=deferred();
serviceReplies.push(saving.promise,{...copySnapshot(),starting:true,services:[{id:'comfyui',name:'ComfyUI',state:'starting',detail:'Starting artwork backend.'}]});
const pending=get('services-form').onsubmit({preventDefault(){}});
await get('services-form').onsubmit({preventDefault(){}});
assert.equal(app.calls.length,2);assert.equal(get('services-start').disabled,true);
const savedCall=app.calls[1];
assert.equal(savedCall.url,'/api/services/settings');assert.equal(savedCall.options.method,'POST');
assert.deepEqual(JSON.parse(JSON.stringify(savedCall.options.body)),{enabled:false,ollama:true,kokoro:false,comfyui:true,comfyui_mode:'python',comfyui_path:'C:\\Art Studio\\ComfyUI\\main.py',comfyui_python:'C:\\Art Studio\\venv\\Scripts\\python.exe'});
saving.resolve({...copySnapshot(),settings:savedCall.options.body});await pending;
assert.equal(app.calls.length,3);assert.equal(app.calls[2].url,'/api/services/start');
assert.equal(app.calls[2].options.method,'POST');
assert.equal(JSON.stringify(app.calls[2].options.body),'{}');
assert.equal(get('services-start').disabled,false);assert.equal(timers.size,1);
assert.ok(get('services-result').textContent.includes('Starting selected programs'));
""")

    def test_polling_preserves_unsaved_edits_and_stops_after_ready_or_close(self):
        self.run_js(r"""
await openServices({...copySnapshot(),starting:true});
assert.equal(timers.size,1);
get('services-comfyui-path').value='An unsaved edited folder';
get('services-kokoro').checked=false;
const timer=[...timers.values()][0];timers.clear();
serviceReplies.push(copySnapshot());await timer.callback();
assert.equal(app.calls.length,2);
assert.equal(get('services-comfyui-path').value,'An unsaved edited folder');
assert.equal(get('services-kokoro').checked,false);assert.equal(timers.size,0);
serviceReplies.push({...copySnapshot(),starting:true});await get('services-check').onclick();
assert.equal(timers.size,1);app.closeModal();assert.equal(timers.size,0);
""")

    def test_stale_status_reply_cannot_modify_a_reopened_modal(self):
        self.run_js(r"""
const old=deferred();serviceReplies.push(old.promise);
const pending=serviceUi.openServicesModal();
app.closeModal();
await openServices();
get('services-result').textContent='New view remains visible';
const markup=get('services-status').innerHTML;
old.resolve({...copySnapshot(),starting:true,services:[{name:'Old service',state:'error',detail:'Old request'}]});
await pending;
assert.equal(get('services-status').innerHTML,markup);
assert.equal(get('services-result').textContent,'New view remains visible');
assert.equal(timers.size,0);
""")

    def test_requested_start_continues_after_panel_closes_without_repainting_it(self):
        self.run_js(r"""
await openServices();
const saving=deferred();serviceReplies.push(saving.promise,copySnapshot());
const pending=get('services-form').onsubmit({preventDefault(){}});
app.closeModal();app.showModal('OTHER','Other panel','<p id="other-panel">Kept</p>');
saving.resolve(copySnapshot());await pending;
assert.equal(app.calls.length,3);assert.equal(app.calls[2].url,'/api/services/start');
assert.ok(get('other-panel'));assert.equal(get('services-result'),null);assert.equal(timers.size,0);
""")

    def test_first_status_failure_is_recoverable_and_save_failure_does_not_start(self):
        self.run_js(r"""
serviceReplies.push(new Error('Service settings unavailable.'));
await serviceUi.openServicesModal();
assert.equal(get('services-result').textContent,'Service settings unavailable.');
assert.equal(get('services-check').disabled,false);assert.equal(get('services-start').disabled,true);
serviceReplies.push(copySnapshot());await get('services-check').onclick();
assert.equal(get('services-start').disabled,false);
serviceReplies.push(new Error('Choose an existing ComfyUI folder.'));
await get('services-form').onsubmit({preventDefault(){}});
assert.equal(app.calls.length,3);
assert.ok(!app.calls.some(call=>call.url==='/api/services/start'));
assert.equal(get('services-start').disabled,false);
assert.equal(get('services-result').textContent,'Choose an existing ComfyUI folder.');
""")

    def test_non_windows_shows_status_but_disables_automatic_launch(self):
        self.run_js(r"""
await openServices({...copySnapshot(),supported:false,can_create_shortcut:false});
assert.equal(get('services-options').disabled,true);
assert.equal(get('services-start').disabled,true);assert.equal(get('services-save').disabled,true);
assert.equal(get('services-check').disabled,false);
assert.equal(get('services-shortcut-section').classList.contains('hidden'),true);
assert.ok(get('services-platform').textContent.includes('available on Windows'));
assert.ok(get('services-status').innerHTML.includes('Game Master connected.'));
assert.equal(app.calls.length,1);
""")

    def test_ready_kokoro_updates_the_narration_status_without_extra_requests(self):
        self.run_js(r"""
await openServices({...copySnapshot(),services:[{id:'kokoro',name:'Kokoro',state:'ready',detail:'Neural voice connected.'}]});
assert.equal(app.state.neuralAvailable,true);
assert.equal(get('neural-status').textContent,'Kokoro neural voice server connected.');
assert.equal(get('voice-engine').value,'kokoro');
assert.equal(app.calls.length,1);
""")

    def test_shortcut_creation_requires_its_button_and_does_not_start_services(self):
        self.run_js(r"""
await openServices();assert.equal(app.calls.length,1);
serviceReplies.push({ok:true,message:'Desktop shortcut created.'});
await get('services-shortcut').onclick();
assert.equal(app.calls.length,2);assert.equal(app.calls[1].url,'/api/services/shortcut');
assert.equal(app.calls[1].options.method,'POST');
assert.equal(get('services-result').textContent,'Desktop shortcut created.');
assert.equal(get('services-shortcut').disabled,false);assert.equal(timers.size,0);
""")

    def test_explicit_check_probes_again_while_background_poll_reads_cached_status(self):
        self.run_js(r"""
await openServices();
serviceReplies.push({...copySnapshot(),starting:true});await get('services-check').onclick();
assert.equal(app.calls[1].url,'/api/services/check');assert.equal(app.calls[1].options.method,'POST');
assert.equal(JSON.stringify(app.calls[1].options.body),'{}');
const timer=[...timers.values()][0];timers.clear();
serviceReplies.push(copySnapshot());await timer.callback();
assert.equal(app.calls[2].url,'/api/services');assert.equal(app.calls[2].options,undefined);
assert.ok(!app.calls.some(call=>call.url==='/api/services/start'));
""")

    def test_page_warmup_refreshes_models_and_voice_when_their_apis_become_ready(self):
        self.run_js(r"""
serviceReplies.push({models:[]});await serviceUi.refreshInstalledModels(false);
assert.equal(app.notices.length,0);
const warming={...copySnapshot(),starting:true,services:[{id:'ollama',state:'starting'},{id:'kokoro',state:'starting'}]};
serviceReplies.push(warming);await serviceUi.watchServiceStartup();
assert.equal(timers.size,1);assert.ok(get('open-services').textContent.includes('starting'));
const timer=[...timers.values()][0];timers.clear();
serviceReplies.push({...copySnapshot(),services:[{id:'ollama',state:'ready'},{id:'kokoro',state:'ready'}]},{models:['qwen3:8b']});
await timer.callback();
assert.equal(get('model').value,'qwen3:8b');
assert.ok(get('installed-models').innerHTML.includes('qwen3:8b'));
assert.equal(app.state.neuralAvailable,true);assert.equal(get('voice-engine').value,'kokoro');
assert.equal(timers.size,0);assert.equal(get('open-services').textContent,'◉ Services');
assert.deepEqual(Array.from(app.calls,call=>call.url),['/api/models','/api/services','/api/services','/api/models']);
assert.ok(app.calls.every(call=>!call.options||call.options.method==='GET'));
""")

    def test_readiness_preserves_selected_model_and_explicit_browser_voice(self):
        self.run_js(r"""
context.localStorage={getItem:key=>key==='sf_engine'?'browser':null};
get('voice-engine').value='browser';get('model').value='another-local-model';
serviceReplies.push({...copySnapshot(),services:[{id:'ollama',state:'ready'},{id:'kokoro',state:'ready'}]},
  {models:['qwen3:8b','another-local-model','<img src=x onerror="bad()">']});
await serviceUi.watchServiceStartup();
assert.equal(get('model').value,'another-local-model');assert.equal(get('voice-engine').value,'browser');
assert.ok(!get('installed-models').innerHTML.includes('<img'));
assert.ok(get('installed-models').innerHTML.includes('&lt;img'));
assert.equal(timers.size,0);
""")

    def test_page_polling_is_bounded_and_never_launches_programs(self):
        self.run_js(r"""
const warming={...copySnapshot(),starting:true,services:[{id:'ollama',state:'starting'}]};
for(let i=0;i<90;i++)serviceReplies.push(warming);
await serviceUi.watchServiceStartup();
let ticks=0;
while(timers.size){
  const timer=[...timers.values()][0];timers.clear();
  assert.equal(timer.delay,2000);await timer.callback();
  assert.ok(++ticks<90);
}
assert.equal(app.calls.length,90);
assert.ok(app.calls.every(call=>call.url==='/api/services'&&!call.options));
assert.equal(get('open-services').textContent,'◉ Services');assert.equal(app.notices.length,0);
""")

    def test_stale_page_poll_cannot_replace_a_newer_readiness_check(self):
        self.run_js(r"""
const old=deferred();serviceReplies.push(old.promise);
const pending=serviceUi.watchServiceStartup();
serviceReplies.push({...copySnapshot(),services:[]});await serviceUi.watchServiceStartup();
old.resolve({...copySnapshot(),starting:true,services:[{id:'kokoro',state:'ready'}]});await pending;
assert.equal(timers.size,0);assert.equal(app.state.neuralAvailable,false);
assert.equal(get('open-services').textContent,'◉ Services');
""")


if __name__ == '__main__':
    unittest.main()
