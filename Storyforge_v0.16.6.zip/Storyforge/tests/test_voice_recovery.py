"""Voice failure guidance fits the in-app service recovery path."""
import io
import sys
import unittest
import urllib.error
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import narration


class VoiceRecoveryTests(unittest.TestCase):
    def test_connection_failure_points_to_services_without_silently_changing_voices(self):
        with patch('narration.urllib.request.urlopen', side_effect=urllib.error.URLError('connection refused')):
            with self.assertRaisesRegex(RuntimeError, 'Open Services') as raised:
                narration.synthesize({'text': 'The porter opens the gate.'})
        self.assertIn('Browser / Windows', str(raised.exception))

    def test_wrapped_timeout_is_distinct_from_an_offline_server(self):
        with patch('narration.urllib.request.urlopen', side_effect=urllib.error.URLError(TimeoutError())):
            with self.assertRaisesRegex(RuntimeError, 'timed out.*Replay last') as raised:
                narration.synthesize({'text': 'The porter opens the gate.'})
        self.assertNotIn('offline', str(raised.exception))

    def test_http_error_response_is_closed_without_exposing_its_private_body(self):
        body = io.BytesIO(b'PRIVATE STORY IN SERVICE ERROR')
        error = urllib.error.HTTPError('http://127.0.0.1:7860/v1/audio/speech', 503, 'Unavailable', {}, body)
        with patch('narration.urllib.request.urlopen', side_effect=error):
            with self.assertRaisesRegex(RuntimeError, 'HTTP 503') as raised:
                narration.synthesize({'text': 'The porter opens the gate.'})
        self.assertTrue(body.closed)
        self.assertNotIn('PRIVATE', str(raised.exception))


if __name__ == '__main__':
    unittest.main()
