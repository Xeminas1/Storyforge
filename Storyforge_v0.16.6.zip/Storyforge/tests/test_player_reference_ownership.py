"""Synthetic player-reference ownership cases; no private campaign prose.

These exercise bounded reference resolution rather than live model quality.
Player identity may survive a name-to-description or name-to-pronoun change,
while a clearly introduced NPC must retain ownership of their own behavior.
"""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import engine


class PlayerReferenceOwnershipTests(unittest.TestCase):
    pc_name = 'Mira'
    profile = {'species': 'High Elf', 'pronouns': 'she/her', 'aliases': 'Lady Willow'}
    step = 'I step off the train.'

    def findings(self, narration, action=None, *, name=None, profile=None):
        return engine.player_agency_violations(
            narration, name or self.pc_name, self.step if action is None else action,
            pc_profile=self.profile if profile is None else profile)

    def assert_owned(self, narration, action=None, **kwargs):
        self.assertTrue(self.findings(narration, action, **kwargs),
                        'An unrequested player behavior must remain player-owned')

    def assert_allowed(self, narration, action=None, **kwargs):
        self.assertEqual(self.findings(narration, action, **kwargs), [])

    def test_definite_species_subject_after_named_player_keeps_player_ownership(self):
        self.assert_owned('Mira steps off the train. The elf watches the road.')

    def test_extra_attention_after_authorized_looking_is_not_a_new_npc(self):
        self.assert_owned(
            'Mira steps off the train and looks at her surroundings. The elf watches the conductor.',
            'I step off the train and look at my surroundings.')

    def test_female_pronoun_cannot_add_a_decision_after_authorized_movement(self):
        self.assert_owned('Mira steps off the train. She decides to follow the conductor.')

    def test_male_pronoun_cannot_add_a_decision_after_authorized_movement(self):
        self.assert_owned(
            'Rowan steps off the train. He decides to follow the conductor.',
            name='Rowan', profile={'species': 'High Elf', 'pronouns': 'he/him'})

    def test_pronoun_cannot_change_the_object_of_an_authored_action(self):
        self.assert_owned('Mira looks at the clock. She looks at the porter.',
                          'I look at the clock.')

    def test_player_alias_is_an_actor_even_without_the_primary_name(self):
        self.assert_owned('Lady Willow watches the conductor.')

    def test_player_alias_can_anchor_a_later_pronoun(self):
        self.assert_owned('Lady Willow steps off the train. She decides to follow the conductor.')

    def test_named_player_cannot_gain_an_unauthored_expression(self):
        self.assert_owned('Mira steps off the train, her expression serene.')

    def test_possessive_expression_after_player_subject_keeps_player_ownership(self):
        self.assert_owned('Mira steps off the train. Her expression remains unreadable.')

    def test_male_possessive_expression_after_player_subject_keeps_player_ownership(self):
        self.assert_owned(
            'Rowan steps off the train. His expression remains unreadable.',
            name='Rowan', profile={'species': 'High Elf', 'pronouns': 'he/him'})

    def test_species_subject_cannot_gain_an_unauthored_expression(self):
        self.assert_owned('Mira steps off the train. The elf waits, her expression serene.')

    def test_authored_movement_and_looking_still_pass_in_second_person(self):
        self.assert_allowed('You step off the train and look at your surroundings.',
                            'I step off the train and look at my surroundings.')

    def test_authored_movement_and_looking_still_pass_with_the_player_name(self):
        self.assert_allowed('Mira steps off the train and looks at her surroundings.',
                            'I step off the train and look at my surroundings.')

    def test_authored_movement_can_be_acknowledged_through_a_profile_alias(self):
        self.assert_allowed('Lady Willow steps off the train.')

    def test_authorized_looking_survives_a_resolved_player_pronoun(self):
        self.assert_allowed('Mira steps off the train. She looks at her surroundings.',
                            'I step off the train and look at my surroundings.')

    def test_species_alone_does_not_turn_an_introduced_npc_into_the_player(self):
        self.assert_allowed('An elven conductor lifts a lantern. The elf watches the train.',
                            'I look at my surroundings.')

    def test_new_named_elf_supersedes_an_earlier_player_reference(self):
        self.assert_allowed(
            'Mira steps off the train. An elf named Toren stands by the gate. '
            'The elf watches the road.')

    def test_definite_species_with_a_new_name_or_role_is_still_an_npc(self):
        for introduction in ('The elf named Toren stands by the gate.',
                             'The elf guard stands by the gate.'):
            with self.subTest(introduction=introduction):
                self.assert_allowed('Mira steps off the train. ' + introduction
                                    + ' The elf watches the road.')

    def test_npc_subject_supersedes_player_for_a_female_pronoun(self):
        self.assert_allowed(
            'Mira steps off the train. The witch turns toward the road. '
            'She decides to follow the conductor.')

    def test_npc_subject_supersedes_player_for_a_male_pronoun(self):
        self.assert_allowed(
            'Rowan steps off the train. The porter turns toward the road. '
            'He decides to follow the conductor.',
            name='Rowan', profile={'species': 'High Elf', 'pronouns': 'he/him'})

    def test_npc_facial_expression_remains_npc_owned(self):
        self.assert_allowed(
            'Mira steps off the train. The witch turns toward the road, her expression serene.')

    def test_npc_possessive_expression_after_explicit_subject_is_allowed(self):
        self.assert_allowed(
            'Rowan steps off the train. The porter turns toward the road. '
            'His expression remains unreadable.',
            name='Rowan', profile={'species': 'High Elf', 'pronouns': 'he/him'})

    def test_npc_observing_the_player_is_not_authoring_the_players_expression(self):
        self.assert_allowed('The porter studies your expression.')

    def test_npc_uncertainty_is_not_an_assertion_of_the_players_feelings(self):
        self.assert_allowed('The porter cannot read your expression.')

    def test_npc_dialogue_may_offer_an_action_without_claiming_the_player_did_it(self):
        self.assert_allowed('The porter says, "Watch the road before the next cart arrives."')

    def test_environmental_contact_is_not_a_voluntary_player_action(self):
        self.assert_allowed('Rain splashes your face while the carriage wheels rattle past.')

    def test_different_profile_pronoun_does_not_capture_an_earlier_npc(self):
        self.assert_allowed('The porter whistles. Mira steps off the train. He raises his lantern.')

    def test_explicit_npc_in_a_while_clause_owns_the_following_expression(self):
        self.assert_allowed('Mira steps off the train while the witch lifts her lantern. '
                            'Her expression is worried.')

    def test_authored_expression_can_accompany_the_submitted_movement(self):
        self.assert_allowed('Mira steps off the train, her expression calm.',
                            'I step off the train with a calm expression.')

    def test_explicitly_authored_expression_remains_allowed(self):
        self.assert_allowed('Your expression remains unreadable.',
                            'My expression remains unreadable.')

    def test_named_and_alias_possessives_cannot_assign_an_expression(self):
        for name in ('Mira', 'Lady Willow'):
            with self.subTest(name=name):
                self.assert_owned(name + "'s expression is serene.", 'I wait.')

    def test_they_pronouns_keep_player_ownership_without_becoming_his(self):
        self.assert_owned('Rowan steps off the train. Their expression is serene.',
                          name='Rowan', profile={'species': 'High Elf', 'pronouns': 'they/them'})

    def test_authorized_quote_does_not_end_the_player_reference_chain(self):
        self.assert_owned('Mira says:\n\n"Open the gates."\n\nShe decides to follow the conductor.',
                          'I say, "Open the gates."')


if __name__ == '__main__':
    unittest.main()
