"""Startup must execute installed source and own one unambiguous endpoint."""
import importlib
import io
import json
import os
import py_compile
import sys
import tempfile
import types
import unittest
from unittest import mock
from contextlib import redirect_stdout
from pathlib import Path
from unittest.mock import MagicMock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import server


class SourceStartupTests(unittest.TestCase):
    fixture_name = '_storyforge_startup_fixture'

    def setUp(self):
        self.directory = self.enterContext(tempfile.TemporaryDirectory())
        self.root = Path(self.directory)
        self.source = self.root / (self.fixture_name + '.py')
        self.addCleanup(sys.modules.pop, self.fixture_name, None)

    def test_installed_source_wins_over_an_actually_valid_stale_bytecode_cache(self):
        self.source.write_text('VERSION = "0.16.0"\n', encoding='utf-8')
        os.utime(self.source, (1700000000, 1700000000))
        cache = Path(py_compile.compile(str(self.source), doraise=True))
        original_cache = cache.read_bytes()
        self.source.write_text('VERSION = "0.16.2"\n', encoding='utf-8')
        os.utime(self.source, (1700000000, 1700000000))
        with patch.object(sys, 'path', [self.directory] + sys.path):
            cached = importlib.import_module(self.fixture_name)
        self.assertEqual(cached.VERSION, '0.16.0', 'Fixture must reproduce standard stale-cache loading')
        del sys.modules[self.fixture_name]

        fresh = server.load_application_module(self.fixture_name, self.root)

        self.assertEqual(fresh.VERSION, '0.16.2')
        self.assertIs(sys.modules[self.fixture_name], fresh)
        self.assertEqual(Path(fresh.__file__), self.source)
        self.assertEqual(fresh.__spec__.origin, str(self.source))
        self.assertEqual(fresh.__package__, '')
        self.assertIsNone(fresh.__cached__)
        self.assertEqual(cache.read_bytes(), original_cache, 'Startup must not rewrite cached code')

    def test_source_loading_creates_no_bytecode_when_cache_does_not_exist(self):
        self.source.write_text('VALUE = 42\n', encoding='utf-8')
        module = server.load_application_module(self.fixture_name, self.root)
        self.assertEqual(module.VALUE, 42)
        self.assertFalse((self.root / '__pycache__').exists())

    def test_an_already_loaded_local_module_keeps_its_identity_and_patches(self):
        self.source.write_text('raise AssertionError("Must not execute twice")\n', encoding='utf-8')
        existing = types.ModuleType(self.fixture_name)
        existing.__file__ = str(self.source)
        existing.test_patch = object()
        sys.modules[self.fixture_name] = existing
        self.assertIs(server.load_application_module(self.fixture_name, self.root), existing)

    def test_a_module_from_another_folder_is_rejected_instead_of_silently_reused(self):
        self.source.write_text('VALUE = "installed"\n', encoding='utf-8')
        elsewhere = self.root / 'another-install' / self.source.name
        elsewhere.parent.mkdir()
        elsewhere.write_text('VALUE = "other install"\n', encoding='utf-8')
        existing = types.ModuleType(self.fixture_name)
        existing.__file__ = str(elsewhere)
        sys.modules[self.fixture_name] = existing
        with self.assertRaisesRegex(ImportError, 'unexpected location'):
            server.load_application_module(self.fixture_name, self.root)
        self.assertIs(sys.modules[self.fixture_name], existing)

    def test_failed_source_loading_does_not_leave_a_partial_module_registered(self):
        self.source.write_text('raise RuntimeError("broken startup")\n', encoding='utf-8')
        with self.assertRaisesRegex(RuntimeError, 'broken startup'):
            server.load_application_module(self.fixture_name, self.root)
        self.assertNotIn(self.fixture_name, sys.modules)


class ExclusiveEndpointTests(unittest.TestCase):
    def make_unbound_windows_server(self):
        value = server.ThreadingHTTPServer.__new__(server.ThreadingHTTPServer)
        value.windows_exclusive = True
        value.socket = MagicMock()
        return value

    def test_windows_requests_exclusive_use_before_binding_and_disables_reuse(self):
        value = self.make_unbound_windows_server()
        order = []
        value.socket.setsockopt.side_effect = lambda *args: order.append(('option', args))

        def bind(instance):
            self.assertFalse(instance.allow_reuse_address)
            self.assertFalse(instance.allow_reuse_port)
            order.append(('bind',))

        with patch.object(server.socket, 'SO_EXCLUSIVEADDRUSE', 0x1234, create=True), \
             patch.object(server._BaseThreadingHTTPServer, 'server_bind', bind):
            value.server_bind()
        self.assertEqual(order, [('option', (server.socket.SOL_SOCKET, 0x1234, 1)), ('bind',)])

    def test_windows_exclusivity_failure_never_falls_back_to_a_shared_listener(self):
        value = self.make_unbound_windows_server()
        value.socket.setsockopt.side_effect = OSError('exclusive bind refused')
        with patch.object(server.socket, 'SO_EXCLUSIVEADDRUSE', 0x1234, create=True), \
             patch.object(server._BaseThreadingHTTPServer, 'server_bind') as bind:
            with self.assertRaisesRegex(OSError, 'exclusive bind refused'):
                value.server_bind()
        bind.assert_not_called()

    def test_missing_windows_exclusivity_support_fails_before_binding(self):
        value = self.make_unbound_windows_server()
        with patch.object(server.socket, 'SO_EXCLUSIVEADDRUSE', None, create=True), \
             patch.object(server._BaseThreadingHTTPServer, 'server_bind') as bind:
            with self.assertRaisesRegex(OSError, 'unavailable'):
                value.server_bind()
        bind.assert_not_called()
        value.socket.setsockopt.assert_not_called()

    def test_real_second_listener_is_rejected_on_the_same_endpoint(self):
        with server.ThreadingHTTPServer(('127.0.0.1', 0), server.Handler) as first:
            with self.assertRaises(OSError):
                server.ThreadingHTTPServer(first.server_address, server.Handler)


class StartupProvenanceTests(unittest.TestCase):
    def test_failure_before_listening_retains_flushed_process_and_version_details(self):
        class Output(io.StringIO):
            flush_count = 0

            def flush(self):
                self.flush_count += 1

        output = Output()
        with patch('server.bootstrap', side_effect=OSError('database unavailable')), \
             patch('server.ThreadingHTTPServer') as listener, redirect_stdout(output):
            with self.assertRaisesRegex(OSError, 'database unavailable'):
                server.run()
        listener.assert_not_called()
        record = json.loads(output.getvalue().removeprefix('Storyforge startup '))
        self.assertEqual(record['stage'], 'bootstrapping')
        self.assertEqual(record['pid'], os.getpid())
        self.assertEqual(record['python'], sys.version.split()[0])
        self.assertEqual(record['executable'], sys.executable)
        self.assertEqual(record['version'], server.updater.VERSION)
        self.assertEqual(record['modules']['updater'], server.updater.__file__)
        self.assertGreater(output.flush_count, 0)

    def test_second_desktop_launcher_reuses_the_existing_process(self):
        with patch('server.running_storyforge', return_value=True), \
             patch('server.webbrowser.open') as browser, patch('server.run') as run:
            self.assertEqual(server.main(['--open-browser']), 0)
        run.assert_not_called()
        browser.assert_called_once_with(server._storyforge_url(server.HOST, server.PORT))




class PortReleaseGraceTests(unittest.TestCase):
    def failure(self, code=10048):
        error=OSError('synthetic occupied port')
        error.winerror=code
        return error

    def test_windows_port_release_retries_then_binds_without_reusing_a_live_server(self):
        expected=mock.Mock()
        with mock.patch.object(server,'WINDOWS',True), \
             mock.patch.object(server,'ThreadingHTTPServer',side_effect=[self.failure(),expected]) as factory, \
             mock.patch.object(server,'running_storyforge',return_value=False), \
             mock.patch.object(server,'startup_log') as log, \
             mock.patch.object(server.time,'monotonic',return_value=0), \
             mock.patch.object(server.time,'sleep') as sleep:
            self.assertIs(server.bind_storyforge_server('127.0.0.1',8787),expected)
        self.assertEqual(factory.call_count,2)
        sleep.assert_called_once_with(.25)
        log.assert_called_once_with('waiting_for_port_release','127.0.0.1',8787)

    def test_existing_healthy_storyforge_is_never_overlapped_by_a_retry(self):
        failure=self.failure()
        with mock.patch.object(server,'WINDOWS',True), \
             mock.patch.object(server,'ThreadingHTTPServer',side_effect=failure) as factory, \
             mock.patch.object(server,'running_storyforge',return_value=True), \
             mock.patch.object(server.time,'sleep') as sleep:
            with self.assertRaises(OSError):server.bind_storyforge_server('127.0.0.1',8787)
        self.assertEqual(factory.call_count,1);sleep.assert_not_called()

    def test_windows_grace_period_is_bounded(self):
        with mock.patch.object(server,'WINDOWS',True), \
             mock.patch.object(server,'ThreadingHTTPServer',side_effect=self.failure(10013)) as factory, \
             mock.patch.object(server,'running_storyforge',return_value=False), \
             mock.patch.object(server.time,'monotonic',side_effect=[0,11]), \
             mock.patch.object(server.time,'sleep') as sleep:
            with self.assertRaises(OSError):server.bind_storyforge_server('127.0.0.1',8787)
        self.assertEqual(factory.call_count,1);sleep.assert_not_called()

    def test_other_platforms_do_not_retry_an_occupied_port(self):
        with mock.patch.object(server,'WINDOWS',False), \
             mock.patch.object(server,'ThreadingHTTPServer',side_effect=self.failure()) as factory, \
             mock.patch.object(server,'running_storyforge') as probe, \
             mock.patch.object(server.time,'sleep') as sleep:
            with self.assertRaises(OSError):server.bind_storyforge_server('127.0.0.1',8787)
        self.assertEqual(factory.call_count,1);probe.assert_not_called();sleep.assert_not_called()


if __name__ == '__main__':
    unittest.main()
