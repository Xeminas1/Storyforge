"""Exercise the real HTTP/SQLite/Ollama adapter with a local scripted model.

This verifies protocol and transaction boundaries, not live model intelligence.
"""
import json
import os
import sys
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from contextlib import closing
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from unittest.mock import MagicMock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import engine
import server


def output(text, **state):
    return json.dumps({'narration': text, 'state_updates': state})


def at_output_limit(content):
    return {'message': {'content': content}, 'done': True,
            'done_reason': 'length', 'eval_count': 1050, 'eval_duration': 1000000}


class ScriptedOllama(BaseHTTPRequestHandler):
    def do_POST(self):
        data = json.loads(self.rfile.read(int(self.headers['Content-Length'])))
        self.server.requests.append(data)
        reply = self.server.replies.pop(0)
        result = reply if isinstance(reply, dict) else {
            'message': {'content': reply}, 'eval_count': 30, 'eval_duration': 1000000}
        body = json.dumps(result).encode()
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *_):
        pass


class GameMasterHttpTests(unittest.TestCase):
    def setUp(self):
        self.temp = self.enterContext(tempfile.TemporaryDirectory())
        self.path = Path(self.temp) / 'storyforge.db'
        self.enterContext(patch.object(server, 'DB_PATH', self.path))
        with closing(engine.open_db(self.path)) as con:
            world = engine.make_world(con, {'title': 'River Gate', 'description': 'A sentry keeps watch.'})
            self.cid = engine.new_campaign(con, {'world_id': world['id'], 'pc_name': 'Xeminas'})['id']
        self.model = self.start_server(ScriptedOllama)
        self.model.requests = []
        self.model.replies = []
        self.enterContext(patch.dict(os.environ, {'OLLAMA_URL': f'http://127.0.0.1:{self.model.server_port}'}))
        self.app = self.start_server(server.Handler)
        self.app.release_watcher = MagicMock()
        self.base = f'http://127.0.0.1:{self.app.server_port}'

    def start_server(self, handler):
        http = ThreadingHTTPServer(('127.0.0.1', 0), handler)
        thread = threading.Thread(target=lambda: http.serve_forever(poll_interval=0.02), daemon=True)
        thread.start()
        def cleanup():
            http.shutdown()
            http.server_close()
            thread.join(2)
        self.addCleanup(cleanup)
        return http

    def post(self, suffix, payload, expected=200):
        request = urllib.request.Request(self.base + '/api/campaigns/' + self.cid + suffix,
                                         data=json.dumps(payload).encode(),
                                         headers={'Content-Type': 'application/json'})
        try:
            response = urllib.request.urlopen(request, timeout=5)
        except urllib.error.HTTPError as exc:
            response = exc
        with response:
            result = json.load(response)
            self.assertEqual(response.status, expected, result)
            return result

    def dump(self):
        with closing(engine.open_db(self.path)) as con:
            return '\n'.join(con.iterdump())

    def test_rejected_draft_is_rewritten_through_actual_model_protocol(self):
        bad = 'Xeminas believes the stranger is trustworthy.'
        self.model.replies = [
            output(bad, location='Throne Room'),
            output('At River Gate, the sentry calls for the gatekeeper.', location='River Gate',
                   evidence={'location':'At River Gate, the sentry calls for the gatekeeper.'}),
        ]
        result = self.post('/turn', {'action': 'I watch the sentry.', 'model': 'qwen3:8b'})
        self.assertEqual(len(self.model.requests), 2)
        self.assertEqual(result['state']['location'], 'River Gate')
        self.assertEqual([m['role'] for m in result['messages']], ['player', 'gm'])
        self.assertTrue(result['messages'][-1]['has_checkpoint'])
        sent = self.model.requests[-1]
        self.assertEqual(sent['format']['type'], 'object')
        self.assertEqual(sent['format']['required'], ['narration','state_updates'])
        self.assertFalse(sent['think'])
        self.assertNotIn(bad, json.dumps(sent['messages']))

    def test_invalid_real_model_responses_leave_database_identical(self):
        self.model.replies = [output('The sentry keeps watch.', location='Xeminas believes the sentry.')]*2
        before = self.dump()
        result = self.post('/turn', {'action': 'I watch.'}, expected=400)
        self.assertIn('Nothing was saved', result['error'])
        self.assertEqual(self.dump(), before)
        self.assertEqual(len(self.model.requests), 2)

    def test_truncated_reply_uses_one_fresh_correction_through_actual_http(self):
        partial = '{"narration":"PRIVATE_PARTIAL_STORY you choose to enter the palace'
        observed = 'At River Gate, the sentry opens the shutter and calls for the boatman.'
        self.model.replies = [at_output_limit(partial), output(observed,
            location='River Gate', evidence={'location': observed})]
        action = 'i step off the train and look at my surroundings'
        with self.assertLogs('engine.ollama', level='WARNING') as logs:
            result = self.post('/turn', {'action': action, 'model': 'qwen3:8b'})
        self.assertEqual(len(self.model.requests), 2)
        self.assertIn(observed, result['narration'])
        self.assertEqual(result['state']['location'], 'River Gate')
        self.assertEqual(result['state']['journal'], [])
        self.assertEqual([message['role'] for message in result['messages']], ['player', 'gm'])
        self.assertEqual(result['messages'][0]['content'], action)
        self.assertTrue(result['messages'][-1]['has_checkpoint'])
        repair_messages = self.model.requests[-1]['messages']
        self.assertIn('response token limit', repair_messages[-1]['content'])
        self.assertIn(action, repair_messages[-1]['content'])
        self.assertIn('state_updates:{} is valid', repair_messages[-1]['content'])
        self.assertNotIn('PRIVATE_PARTIAL_STORY', json.dumps(repair_messages))
        self.assertNotIn('PRIVATE_PARTIAL_STORY', '\n'.join(logs.output))
        self.assertFalse(any(message['role'] == 'assistant' for message in repair_messages))
        for request in self.model.requests:
            self.assertEqual(request['options']['num_predict'], 1050)
            self.assertFalse(request['think'])
            self.assertLessEqual(sum(len(message['content'].encode('utf-8'))
                                     for message in request['messages']), engine.GM_CONTEXT_BYTE_LIMIT)

    def test_complete_json_at_output_limit_can_commit_after_normal_checks(self):
        observed = 'At River Gate, the sentry rings a small brass bell.'
        self.model.replies = [at_output_limit(output(observed,
            location='River Gate', evidence={'location': observed}))]
        result = self.post('/turn', {'action': 'I watch the sentry.'})
        self.assertEqual(len(self.model.requests), 1)
        self.assertIn(observed, result['narration'])
        self.assertEqual(result['state']['location'], 'River Gate')
        self.assertEqual(len(result['messages']), 2)
        self.assertTrue(result['messages'][-1]['has_checkpoint'])

    def test_complete_json_at_output_limit_still_checks_player_agency(self):
        forbidden = 'Xeminas decides to trust the sentry and raises a hand.'
        self.model.replies = [at_output_limit(output(forbidden)),
                              output('The sentry asks the boatman for a passenger list.')]
        result = self.post('/turn', {'action': 'I watch the sentry.'})
        self.assertEqual(len(self.model.requests), 2)
        self.assertNotIn(forbidden, result['narration'])
        correction = self.model.requests[-1]['messages'][-1]['content']
        self.assertIn('unrequested player action or thought', correction)
        self.assertNotIn(forbidden, json.dumps(self.model.requests[-1]['messages']))
        self.assertEqual(result['state']['journal'], [])

    def test_complete_json_at_output_limit_still_requires_state_evidence(self):
        self.model.replies = [at_output_limit(output('The sentry opens the shutter.',
            location='Royal Palace')), output('The sentry sets a lantern beside the shutter.')]
        result = self.post('/turn', {'action': 'I wait.'})
        self.assertEqual(len(self.model.requests), 2)
        self.assertEqual(result['state']['location'], 'Unknown')
        correction = self.model.requests[-1]['messages'][-1]['content']
        self.assertIn('state change lacks visible evidence: location', correction)
        self.assertNotIn('Royal Palace', result['narration'])

    def test_twice_truncated_new_turn_leaves_database_identical(self):
        self.model.replies = [at_output_limit('{"narration":"PRIVATE_PARTIAL_STORY')]*2
        before = self.dump()
        with self.assertLogs('engine.ollama', level='WARNING'):
            result = self.post('/turn', {'action': 'I watch.'}, expected=503)
        self.assertEqual(len(self.model.requests), 2)
        self.assertEqual(self.dump(), before)
        self.assertIn('Nothing was saved', result['error'])
        self.assertNotIn('PRIVATE_PARTIAL_STORY', result['error'])

    def test_twice_truncated_retry_preserves_old_reply_later_turn_and_checkpoints(self):
        first = 'The sentry puts a brass token into your hand.'
        self.model.replies = [output(first, inventory_add=['brass token'],
            evidence={'inventory_add': first})]
        original = self.post('/turn', {'action': 'I wait.'})
        target = original['messages'][-1]['id']
        later = 'The boatman lowers a gangplank.'
        self.model.replies = [output(later, journal_entry=later,
            evidence={'journal_entry': later})]
        self.post('/turn', {'action': 'I watch the boatman.'})
        before = self.dump()
        self.model.requests.clear()
        self.model.replies = [at_output_limit('{"narration":"PRIVATE_RETRY_DRAFT')]*2
        with self.assertLogs('engine.ollama', level='WARNING'):
            result = self.post(f'/messages/{target}/retry',
                {'feedback': 'Show more of the conversation.'}, expected=503)
        self.assertEqual(len(self.model.requests), 2)
        self.assertEqual(self.dump(), before)
        self.assertIn('Nothing was saved', result['error'])
        self.assertNotIn('PRIVATE_RETRY_DRAFT', result['error'])

    def test_truncation_then_unsafe_correction_gets_no_third_generation(self):
        self.model.replies = [at_output_limit('{"narration":"PRIVATE_PARTIAL_STORY'),
            output('You decide to follow the sentry.', location='Royal Palace')]
        before = self.dump()
        with self.assertLogs('engine.ollama', level='WARNING'):
            result = self.post('/turn', {'action': 'I wait.'}, expected=400)
        self.assertEqual(len(self.model.requests), 2)
        self.assertEqual(self.dump(), before)
        self.assertIn('Nothing was saved', result['error'])

    def test_unicode_action_and_lore_stay_within_context_budget_during_limit_recovery(self):
        action = 'I study the notice: ' + '月明かりの港と古い灯台。' * 90
        with closing(engine.open_db(self.path)) as con:
            world_id = engine.get_campaign(con, self.cid)['world_id']
            con.execute('UPDATE worlds SET description=? WHERE id=?', (
                'The notice stands beside River Gate. ' + '港の歴史と灯台の伝承。' * 60, world_id))
            con.commit()
        self.model.replies = [at_output_limit('{"narration":"PRIVATE_PARTIAL_STORY'),
                              output('The sentry points out a tide mark beneath the notice.')]
        with self.assertLogs('engine.ollama', level='WARNING'):
            result = self.post('/turn', {'action': action})
        self.assertEqual(len(self.model.requests), 2)
        self.assertEqual(result['messages'][0]['content'], action)
        self.assertIn(action, self.model.requests[-1]['messages'][-1]['content'])
        for request in self.model.requests:
            self.assertLessEqual(sum(len(message['content'].encode('utf-8'))
                                     for message in request['messages']), engine.GM_CONTEXT_BYTE_LIMIT)

    def test_opening_repairs_screenshot_failures_without_repeating_rejected_draft(self):
        bad = ('[River Gate - Coast - Dusk]\n\n'
               'I survey the platform. You stand beside the porter, choose the council, '
               'turn to the gate and say your name.')
        scene = 'At River Gate on the Coast, Dusk settles over the sentry post.'
        event = 'The sentry opens the shutter.'
        good = ('[River Gate - Coast - Dusk]\n\n' + scene + ' ' + event
                + '\n\nSentry: "I keep watch until the relief arrives." '
                  'Will you choose the riverside path or remain at the gate?')
        self.model.replies = [
            output(bad, location='River Gate', parent_area='Coast', time_of_day='Dusk',
                   journal_entry=event),
            output(good, location='River Gate', parent_area='Coast', time_of_day='Dusk',
                   journal_entry=event, evidence={'location': scene, 'parent_area': scene,
                       'time_of_day': scene, 'journal_entry': event}),
        ]
        result = self.post('/turn', {'action': '__START__', 'model': 'qwen3:8b'})
        self.assertEqual(len(self.model.requests), 2)
        self.assertEqual([message['role'] for message in result['messages']], ['gm'])
        self.assertTrue(result['messages'][0]['has_checkpoint'])
        self.assertIn('Sentry: "I keep watch', result['narration'])
        self.assertIn('Will you choose', result['narration'])
        self.assertEqual(result['state']['location'], 'River Gate')
        self.assertEqual(result['state']['parent_area'], 'Coast')
        self.assertEqual(result['state']['time_of_day'], 'Dusk')
        self.assertEqual(result['state']['journal'], [event])
        self.assertNotIn('evidence', result['state'])
        for request in self.model.requests:
            messages = request['messages']
            self.assertEqual(request['model'], 'qwen3:8b')
            self.assertNotIn('__START__', json.dumps(messages))
            self.assertNotIn(bad, json.dumps(messages))
            self.assertNotIn('I survey the platform', json.dumps(messages))
            self.assertLessEqual(sum(len(message['content'].encode('utf-8'))
                                     for message in messages), engine.GM_CONTEXT_BYTE_LIMIT)
        opening = self.model.requests[0]['messages'][-1]['content']
        repair = self.model.requests[1]['messages'][-1]['content']
        self.assertIn('no player action or dialogue has been submitted', opening)
        self.assertIn(opening, repair)
        self.assertNotRegex(opening + '\n' + repair, r'\bI\b')
        self.assertIn('state_updates.evidence[field]', repair)
        self.assertIn('header alone is not evidence', repair)
        self.assertIn('state_updates:{} is valid', repair)

    def test_twice_unsafe_opening_keeps_database_identical(self):
        bad = ('[River Gate - Coast - Dusk]\n\n'
               'I survey the platform. You stand beside the porter, choose the council, '
               'turn to the gate and say your name.')
        self.model.replies = [output(bad, location='River Gate', parent_area='Coast',
            time_of_day='Dusk', journal_entry='The porter offers an invitation.')]*2
        before = self.dump()
        result = self.post('/turn', {'action': '__START__', 'model': 'qwen3:8b'}, expected=400)
        self.assertEqual(len(self.model.requests), 2)
        self.assertEqual(self.dump(), before)
        self.assertIn('Nothing was saved', result['error'])
        self.assertIn('Begin story', result['error'])
        self.assertNotIn('__START__', result['error'])
        self.assertNotIn('unrequested player action or thought', result['error'])

    def test_malformed_opening_repair_retains_original_task_and_accepts_no_state_change(self):
        self.model.replies = ['not a JSON response', output(
            'The sentry opens the shutter.\n\nSentry: "I keep the river watch."')]
        result = self.post('/turn', {'action': '__START__', 'model': 'qwen3:8b'})
        self.assertEqual(len(self.model.requests), 2)
        self.assertEqual([message['role'] for message in result['messages']], ['gm'])
        self.assertEqual(result['state']['location'], 'Unknown')
        self.assertEqual(result['state']['journal'], [])
        self.assertNotIn('scene_memory', result['state'])
        opening = self.model.requests[0]['messages'][-1]['content']
        repair = self.model.requests[1]['messages'][-1]['content']
        self.assertIn(opening, repair)
        self.assertIn('invalid response format', repair)
        self.assertIn('state_updates:{} is valid', repair)
        self.assertNotIn('__START__', repair)
        self.assertNotIn('not a JSON response', repair)
        self.assertLessEqual(sum(len(message['content'].encode('utf-8'))
            for message in self.model.requests[1]['messages']), engine.GM_CONTEXT_BYTE_LIMIT)

    def test_agency_safe_opening_still_requires_visible_state_evidence(self):
        # The opening mode must not bypass grounding just because NPC prose and
        # its direct invitation are safe. Header labels alone are insufficient.
        text = ('[River Gate - Coast - Dusk]\n\n'
                'The sentry opens the shutter. Sentry: "I keep the river watch." '
                'Will you choose the riverside path?')
        self.model.replies = [output(text, location='River Gate', parent_area='Coast',
            time_of_day='Dusk', journal_entry='The sentry opens the shutter.')]*2
        before = self.dump()
        result = self.post('/turn', {'action': '__START__', 'model': 'qwen3:8b'}, expected=400)
        self.assertEqual(len(self.model.requests), 2)
        self.assertEqual(self.dump(), before)
        repair = self.model.requests[1]['messages'][-1]['content']
        self.assertIn('state change lacks visible evidence: location', repair)
        # Unsupported optional notes are omitted; actual scene changes still
        # reject the whole draft and leave every saved row unchanged.
        self.assertNotIn('state change lacks visible evidence: journal_entry', repair)
        self.assertNotIn('unattributed first-person dialogue', repair)
        self.assertNotIn('unrequested player action or thought: choose', repair)
        self.assertIn('Nothing was saved', result['error'])

    def test_supported_opening_state_does_not_authorize_a_player_decision(self):
        scene = 'At River Gate on the Coast, Dusk settles over the sentry post.'
        text = '[River Gate - Coast - Dusk]\n\n' + scene + ' You choose to follow the sentry.'
        self.model.replies = [output(text, location='River Gate', parent_area='Coast',
            time_of_day='Dusk', evidence={'location': scene, 'parent_area': scene,
                'time_of_day': scene})]*2
        before = self.dump()
        result = self.post('/turn', {'action': '__START__', 'model': 'qwen3:8b'}, expected=400)
        self.assertEqual(len(self.model.requests), 2)
        self.assertEqual(self.dump(), before)
        repair = self.model.requests[1]['messages'][-1]['content']
        self.assertIn('unrequested player action or thought: choose', repair)
        self.assertNotIn('state change lacks visible evidence', repair)
        self.assertIn('Nothing was saved', result['error'])

    def test_retry_later_turn_uses_prior_history_without_crashing(self):
        first_text='The sentry calls for a lantern and puts a gate token into your hand.'
        self.model.replies = [output(first_text, inventory_add=['gate token'],
                                    evidence={'inventory_add':first_text})]
        self.post('/turn', {'action': 'I listen.'})
        self.model.replies = [output('A gatekeeper opens the shutter.',
                                    journal_entry='A gatekeeper opens the shutter.',
                                    evidence={'journal_entry':'A gatekeeper opens the shutter.'})]
        second = self.post('/turn', {'action': 'I wait.'})
        target = second['messages'][-1]['id']
        self.model.replies = [output('The gatekeeper asks the sentry for a lantern.')]
        result = self.post(f'/messages/{target}/retry', {'feedback': 'Advance the conversation.'})
        self.assertEqual(len(result['messages']), 4)
        self.assertEqual(result['state']['inventory'], ['gate token'])
        self.assertEqual(result['state']['journal'], [])
        self.assertTrue(any(m['role'] == 'assistant' and 'sentry calls' in m['content']
                            for m in self.model.requests[-1]['messages']))

    def test_memory_removal_route_preserves_story_and_rewind_correction(self):
        text = 'Maribel guards the brass observatory key.'
        self.model.replies = [output(text, scene_memory={
            'npcs': [{'name': 'Maribel', 'fact': text, 'evidence': text}],
            'events': [{'text': text, 'evidence': text}],
        })]
        first = self.post('/turn', {'action': 'I listen.'})
        self.model.replies = [output('The sentry calls for the gatekeeper.')]
        second = self.post('/turn', {'action': 'I wait.'})
        target = second['messages'][-1]['id']
        calls = len(self.model.requests)
        payload = {'kind': 'npc_fact', 'name': 'Maribel', 'index': 0, 'text': text}
        result = self.post('/memory/remove', payload)
        self.assertTrue(result['removed'])
        self.assertEqual(result['state']['scene_memory']['npcs'], [])
        self.assertEqual(result['state']['scene_memory']['events'], [text])
        self.assertEqual(len(self.model.requests), calls)
        before = self.dump()
        stale = self.post('/memory/remove', payload, expected=400)
        self.assertIn('Refresh', stale['error'])
        self.assertEqual(self.dump(), before)
        self.model.replies = [output('A gatekeeper opens the shutter.')]
        retried = self.post(f'/messages/{target}/retry', {'feedback': 'Continue the conversation.'})
        self.assertEqual(retried['state']['scene_memory']['npcs'], [])
        self.assertEqual(retried['state']['scene_memory']['events'], [text])
        self.assertEqual(retried['messages'][1]['content'], first['messages'][1]['content'])


if __name__ == '__main__':
    unittest.main()
