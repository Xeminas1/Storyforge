"""Offline regressions for the local Windows backend startup manager."""
import json
import os
import subprocess
import sys
import tempfile
import threading
import time
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import engine


class LocalServicesTests(unittest.TestCase):
    def setUp(self):
        self.root = Path(self.enterContext(tempfile.TemporaryDirectory()))
        self.child = MagicMock()
        self.child.poll.return_value = None
        self.popen = self.enterContext(patch.object(engine._services_subprocess, 'Popen', return_value=self.child))
        self.run = self.enterContext(patch.object(engine._services_subprocess, 'run',
            return_value=subprocess.CompletedProcess([], 1, b'', b'')))
        self.enterContext(patch.object(engine._services_shutil, 'which', return_value=None))
        self.enterContext(patch.object(engine.LocalServices, '_http_bytes', side_effect=OSError('offline test')))
        self.enterContext(patch.object(engine.LocalServices, '_port_busy', return_value=False))
        self.enterContext(patch.object(engine.LocalServices, '_program_files', return_value=[]))
        self.enterContext(patch.object(engine.LocalServices, 'STARTUP_SECONDS', .02))
        self.enterContext(patch.object(engine.LocalServices, 'POLL_SECONDS', .001))
        self.enterContext(patch.dict(os.environ, {'OLLAMA_URL': 'http://127.0.0.1:11434',
            'STORYFORGE_COMFY_PORT': '8188'}))
        self.manager = self.make_manager()

    def make_manager(self, windows=True):
        manager = engine.LocalServices(self.root, windows=windows)
        self.addCleanup(manager.close)
        return manager

    def executable(self, name):
        path = self.root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.touch()
        return path.resolve()

    def only(self, service, *, enabled=True):
        return self.manager.save_settings({'enabled': enabled,
            **{key: key == service for key in engine.LocalServices.SERVICE_NAMES}})

    def wait_idle(self, manager=None):
        manager = manager or self.manager
        deadline = time.monotonic() + 2
        while manager.snapshot()['starting']:
            if time.monotonic() > deadline:
                self.fail('Background service check did not finish')
            threading.Event().wait(.002)
        return {item['id']: item for item in manager.snapshot()['services']}

    def test_snapshot_is_cached_and_never_probes_launches_or_writes_settings(self):
        with patch.object(self.manager, '_ready') as ready:
            first = self.manager.snapshot()
            first['settings']['enabled'] = False
            first['services'][0]['state'] = 'tampered'
            second = self.manager.snapshot()
        ready.assert_not_called()
        self.assertTrue(second['settings']['enabled'])
        self.assertNotEqual(second['services'][0]['state'], 'tampered')
        self.assertFalse(self.manager.config_path.exists())
        self.popen.assert_not_called()
        self.run.assert_not_called()

    def test_settings_round_trip_preserves_unspecified_fields_and_uses_private_data(self):
        folder = str(self.root / 'Comfy Desktop')
        result = self.manager.save_settings({'enabled': False, 'kokoro': False,
            'comfyui_mode': 'desktop', 'comfyui_path': folder})
        saved = json.loads(self.manager.config_path.read_text())
        self.assertEqual(saved, result['settings'])
        self.assertTrue(saved['ollama'])
        self.assertEqual(self.manager.config_path, self.root / 'data/local-services.json')
        self.assertEqual(self.make_manager().snapshot()['settings'], saved)
        self.assertFalse(list(self.manager.config_path.parent.glob('.local-services-*.tmp')))

    def test_invalid_settings_are_typed_and_leave_previous_file_unchanged(self):
        self.manager.save_settings({'enabled': False})
        original = self.manager.config_path.read_bytes()
        invalid = [[], {'enabled': 1}, {'ollama': 'false'}, {'kokoro': None},
            {'comfyui': 0}, {'unknown': True}, {'comfyui_mode': 'shell'},
            {'comfyui_path': 42}, {'comfyui_path': 'relative/path'},
            {'comfyui_path': r'\\server\share\ComfyUI.exe'},
            {'comfyui_path': '"' + str(self.root / 'ComfyUI.exe') + '"'},
            {'comfyui_python': str(self.root / 'python.exe') + '\n--evil'}]
        for payload in invalid:
            with self.subTest(payload=payload):
                with self.assertRaises(ValueError):
                    self.manager.save_settings(payload)
                self.assertEqual(self.manager.config_path.read_bytes(), original)
        self.popen.assert_not_called()

    def test_damaged_or_unsupported_saved_settings_disable_startup_without_rewriting(self):
        self.manager.config_path.parent.mkdir()
        for raw in (b'{broken', b'[]', b'{"enabled": "yes"}', b'{"unknown": true}', b' ' * 65537):
            with self.subTest(raw=raw[:30]):
                self.manager.config_path.write_bytes(raw)
                manager = self.make_manager()
                self.assertFalse(manager.snapshot()['enabled'])
                self.assertTrue(manager.snapshot()['configuration_error'])
                self.assertEqual(self.manager.config_path.read_bytes(), raw)
                manager.start()
        self.popen.assert_not_called()
        self.run.assert_not_called()

    def test_unreadable_saved_settings_are_retained_and_can_be_repaired_explicitly(self):
        self.manager.save_settings({'enabled': True})
        original = self.manager.config_path.read_bytes()
        with patch.object(Path, 'open', side_effect=PermissionError('test read denied')):
            manager = self.make_manager()
        self.assertFalse(manager.snapshot()['enabled'])
        self.assertTrue(manager.snapshot()['configuration_error'])
        self.assertEqual(self.manager.config_path.read_bytes(), original)
        repaired = manager.save_settings({'enabled': True})
        self.assertEqual(repaired['configuration_error'], '')

    def test_master_switch_prevents_automatic_start(self):
        self.only('ollama', enabled=False)
        with patch.object(self.manager, '_ready') as ready:
            result = self.manager.start()
        self.assertFalse(result['starting'])
        ready.assert_not_called()
        self.popen.assert_not_called()
        self.run.assert_not_called()

    def test_manual_start_overrides_master_without_persistently_enabling_it(self):
        self.only('ollama', enabled=False)
        with patch.object(self.manager, '_ready', return_value=True) as ready:
            self.manager.start(manual=True)
            states = self.wait_idle()
        ready.assert_called_once_with('ollama')
        self.assertEqual(states['ollama']['state'], 'ready')
        self.assertFalse(self.manager.snapshot()['settings']['enabled'])
        self.assertFalse(json.loads(self.manager.config_path.read_text())['enabled'])

    def test_healthy_backends_are_reused_without_any_process_commands(self):
        with patch.object(self.manager, '_ready', return_value=True) as ready:
            self.manager.start()
            states = self.wait_idle()
        self.assertCountEqual([call.args[0] for call in ready.call_args_list],
            engine.LocalServices.SERVICE_NAMES)
        self.assertTrue(all(item['state'] == 'ready' for item in states.values()))
        self.popen.assert_not_called()
        self.run.assert_not_called()

    def test_individual_switches_limit_start_probes_and_commands(self):
        self.only('comfyui')
        with patch.object(self.manager, '_ready', return_value=True) as ready:
            self.manager.start()
            states = self.wait_idle()
        ready.assert_called_once_with('comfyui')
        self.assertEqual(states['ollama']['state'], 'disabled')
        self.assertEqual(states['kokoro']['state'], 'disabled')
        self.assertEqual(states['comfyui']['state'], 'ready')

    def test_non_windows_manager_can_check_but_never_start_processes(self):
        manager = self.make_manager(windows=False)
        with patch.object(manager, '_ready', return_value=False):
            manager.start(manual=True)
            states = self.wait_idle(manager)
        self.assertFalse(manager.snapshot()['supported'])
        self.assertTrue(all(item['state'] == 'offline' for item in states.values()))
        self.popen.assert_not_called()
        self.run.assert_not_called()

    def test_background_probe_keeps_status_and_settings_responsive_and_deduplicates_start(self):
        self.only('ollama')
        entered, release = threading.Event(), threading.Event()
        self.addCleanup(release.set)
        def blocked_probe(key):
            entered.set()
            release.wait(2)
            return True
        with patch.object(self.manager, '_ready', side_effect=blocked_probe) as ready:
            before = time.monotonic()
            self.manager.start()
            self.assertLess(time.monotonic() - before, .5)
            self.assertTrue(entered.wait(1))
            self.assertTrue(self.manager.start()['starting'])
            self.assertTrue(self.manager.snapshot()['starting'])
            ready.assert_called_once_with('ollama')
            before = time.monotonic()
            result = self.manager.save_settings({'enabled': False})
            self.assertLess(time.monotonic() - before, .5)
            self.assertFalse(result['starting'])
            release.set()
        self.popen.assert_not_called()

    def test_check_probes_with_master_off_and_exposes_results_without_launching(self):
        self.manager.save_settings({'enabled': False})
        with patch.object(self.manager, '_ready', side_effect=lambda key: key == 'ollama') as ready, \
             patch.object(self.manager, '_start_ollama') as ollama, \
             patch.object(self.manager, '_start_kokoro') as kokoro, \
             patch.object(self.manager, '_start_comfy') as comfy:
            self.manager.check()
            states = self.wait_idle()
        self.assertEqual(ready.call_count, 3)
        self.assertEqual(states['ollama']['state'], 'ready')
        self.assertEqual(states['kokoro']['state'], 'offline')
        self.assertEqual(states['comfyui']['state'], 'offline')
        self.assertFalse(self.manager.snapshot()['enabled'])
        for start in (ollama, kokoro, comfy):
            start.assert_not_called()
        self.popen.assert_not_called()
        self.run.assert_not_called()

    def test_check_respects_individual_backend_switches(self):
        self.only('kokoro', enabled=False)
        with patch.object(self.manager, '_ready', return_value=True) as ready:
            self.manager.check()
            states = self.wait_idle()
        ready.assert_called_once_with('kokoro')
        self.assertEqual(states['kokoro']['state'], 'ready')
        self.assertEqual(states['ollama']['state'], 'disabled')
        self.assertEqual(states['comfyui']['state'], 'disabled')

    def test_ollama_url_accepts_only_explicit_loopback_http_endpoints(self):
        valid = {'http://127.0.0.1:11434': ('http://127.0.0.1:11434', '127.0.0.1', 11434),
            'http://localhost:1234/': ('http://127.0.0.1:1234', '127.0.0.1', 1234),
            'http://[::1]:11434': ('http://[::1]:11434', '[::1]', 11434)}
        for address, expected in valid.items():
            with self.subTest(address=address), patch.dict(os.environ, {'OLLAMA_URL': address}):
                self.assertEqual(self.manager._ollama_address(), expected)
        invalid = ('http://example.com:11434', 'http://0.0.0.0:11434', 'https://127.0.0.1:11434',
            'http://127.0.0.1', 'http://name@127.0.0.1:11434', 'http://127.0.0.1:11434/api',
            'http://127.0.0.1:11434/?q=1', 'http://127.0.0.1:11434/#fragment',
            'http://127.0.0.1:0', 'http://127.0.0.1:65536', 'http://127.0.0.1:11434\n')
        for address in invalid:
            with self.subTest(address=address), patch.dict(os.environ, {'OLLAMA_URL': address}):
                with self.assertRaises(ValueError):
                    self.manager._ollama_address()

    def test_ollama_uses_installed_executable_fixed_serve_argument_and_local_host(self):
        executable = self.executable('Ollama/ollama.exe')
        self.only('ollama')
        with patch.object(self.manager, '_ready', return_value=False), \
             patch.object(self.manager, '_existing_executable', return_value=executable), \
             patch.object(self.manager, '_wait', return_value=True):
            self.manager.start()
            self.wait_idle()
        self.assertEqual(self.popen.call_args.args[0], [str(executable), 'serve'])
        self.assertEqual(self.popen.call_args.kwargs['env']['OLLAMA_HOST'], '127.0.0.1:11434')
        self.assertFalse(self.popen.call_args.kwargs['shell'])

    def test_occupied_backend_ports_wait_for_warmup_without_duplicate_processes(self):
        for service in ('ollama', 'kokoro'):
            with self.subTest(service=service):
                self.only(service)
                with patch.object(self.manager, '_ready', side_effect=[False, False, True]) as ready, \
                     patch.object(self.manager, '_port_busy', return_value=True):
                    self.manager.start()
                    states = self.wait_idle()
                self.assertEqual(states[service]['state'], 'ready')
                self.assertEqual([call.args[0] for call in ready.call_args_list], [service] * 3)
        self.popen.assert_not_called()
        self.run.assert_not_called()

    def test_unhealthy_occupied_backend_ports_time_out_without_process_commands(self):
        for service in ('ollama', 'kokoro'):
            with self.subTest(service=service):
                self.only(service)
                with patch.object(self.manager, '_ready', return_value=False), \
                     patch.object(self.manager, '_port_busy', return_value=True):
                    self.manager.start()
                    states = self.wait_idle()
                self.assertEqual(states[service]['state'], 'error')
                self.assertIn('port is occupied', states[service]['detail'])
        self.popen.assert_not_called()
        self.run.assert_not_called()

    def test_occupied_backend_warmup_wait_can_be_cancelled_without_late_ready_state(self):
        for service in ('ollama', 'kokoro'):
            with self.subTest(service=service):
                manager = self.make_manager()
                manager.save_settings({key: key == service for key in manager.SERVICE_NAMES})
                entered, finished = threading.Event(), threading.Event()
                original_wait = manager._wait
                def waiting(ready, cancel):
                    entered.set()
                    try:
                        return original_wait(ready, cancel)
                    finally:
                        finished.set()
                with patch.object(manager, '_ready', return_value=False), \
                     patch.object(manager, '_port_busy', return_value=True), \
                     patch.object(manager, '_wait', side_effect=waiting):
                    manager.start()
                    self.assertTrue(entered.wait(1))
                    manager.close()
                    self.assertTrue(finished.wait(1))
                states = {item['id']: item for item in manager.snapshot()['services']}
                self.assertFalse(manager.snapshot()['starting'])
                self.assertEqual(states[service]['state'], 'offline')
        self.popen.assert_not_called()
        self.run.assert_not_called()

    def test_comfy_desktop_folder_resolves_only_known_application_names(self):
        for name in self.manager.DESKTOP_NAMES:
            with self.subTest(name=name):
                executable = self.executable(name + '/'+ name)
                settings = {**self.manager.snapshot()['settings'], 'comfyui_path': str(executable.parent)}
                argv, cwd = self.manager._comfy_command(settings)
                self.assertEqual(argv, [str(executable)])
                self.assertEqual(cwd, executable.parent)

    def test_comfy_portable_uses_embedded_python_and_fixed_local_arguments(self):
        python = self.executable('portable/python_embeded/python.exe')
        main = self.executable('portable/ComfyUI/main.py')
        settings = {**self.manager.snapshot()['settings'], 'comfyui_mode': 'portable',
            'comfyui_path': str(self.root / 'portable')}
        argv, cwd = self.manager._comfy_command(settings)
        self.assertEqual(argv, [str(python), '-s', str(main), '--listen', '127.0.0.1',
            '--port', '8188', '--disable-auto-launch'])
        self.assertEqual(cwd, main.parent)

    def test_comfy_python_mode_supports_venv_or_explicit_python_with_fixed_arguments(self):
        main = self.executable('backend/main.py')
        default = self.executable('backend/.venv/Scripts/python.exe')
        explicit = self.executable('Python/pythonw.exe')
        for configured, expected in (('', default), (str(explicit), explicit)):
            with self.subTest(configured=configured):
                settings = {**self.manager.snapshot()['settings'], 'comfyui_mode': 'python',
                    'comfyui_path': str(main), 'comfyui_python': configured}
                argv, cwd = self.manager._comfy_command(settings)
                self.assertEqual(argv, [str(expected), str(main), '--listen', '127.0.0.1',
                    '--port', '8188', '--disable-auto-launch'])
                self.assertEqual(cwd, main.parent)

    def test_comfy_does_not_execute_batch_files_installers_or_path_embedded_arguments(self):
        for name in ('run.bat', 'run.cmd', 'setup.exe', 'Uninstall ComfyUI.exe', 'arbitrary.exe'):
            path = self.executable(name)
            settings = {**self.manager.snapshot()['settings'], 'comfyui_path': str(path)}
            with self.subTest(path=path), self.assertRaises(ValueError):
                self.manager._comfy_command(settings)
        main = self.executable('backend/main.py')
        for python in (self.executable('python.bat'), self.executable('arbitrary.exe')):
            settings = {**self.manager.snapshot()['settings'], 'comfyui_mode': 'python',
                'comfyui_path': str(main), 'comfyui_python': str(python)}
            with self.subTest(python=python), self.assertRaises(ValueError):
                self.manager._comfy_command(settings)
        path = self.executable('ComfyUI.exe')
        settings = {**self.manager.snapshot()['settings'], 'comfyui_path': str(path) + ' --listen 0.0.0.0'}
        with self.assertRaises(ValueError):
            self.manager._comfy_command(settings)
        self.popen.assert_not_called()
        self.run.assert_not_called()

    def test_docker_uses_local_named_pipe_and_ignores_remote_docker_environment(self):
        executable = self.executable('Docker/docker.exe')
        remote = {'DOCKER_HOST': 'tcp://remote:2375', 'DOCKER_CONTEXT': 'remote',
            'DOCKER_TLS_VERIFY': '1', 'DOCKER_CERT_PATH': '/remote', 'DOCKER_API_VERSION': '1.1'}
        with patch.dict(os.environ, remote):
            self.manager._docker(executable, ['start', 'storyforge-kokoro'])
        self.assertEqual(self.run.call_args.args[0], [str(executable), '--host',
            'npipe:////./pipe/docker_engine', 'start', 'storyforge-kokoro'])
        self.assertFalse(self.run.call_args.kwargs['shell'])
        self.assertEqual(self.run.call_args.kwargs['timeout'], 5)
        for key in remote:
            self.assertNotIn(key, self.run.call_args.kwargs['env'])

    def test_kokoro_bindings_require_ipv4_localhost_port_7860_and_no_external_ports(self):
        safe = {'7860/tcp': [{'HostIp': '127.0.0.1', 'HostPort': '7860'}]}
        self.assertTrue(self.manager._safe_kokoro_bindings(json.dumps(safe).encode()))
        loopback_extras = {'7860/tcp': [*safe['7860/tcp'], {'HostIp': '::1', 'HostPort': '7860'}],
            '9000/tcp': [{'HostIp': '127.0.0.1', 'HostPort': '9000'}]}
        self.assertTrue(self.manager._safe_kokoro_bindings(json.dumps(loopback_extras).encode()))
        unsafe = [None, [], {}, {'7860/tcp': []},
            {'7860/tcp': [{'HostIp': '0.0.0.0', 'HostPort': '7860'}]},
            {'7860/tcp': [{'HostIp': '::', 'HostPort': '7860'}]},
            {'7860/tcp': [{'HostIp': '::1', 'HostPort': '7860'}]},
            {'7860/tcp': [{'HostIp': '127.0.0.1', 'HostPort': '7861'}]},
            {**safe, '9000/tcp': [{'HostIp': '0.0.0.0', 'HostPort': '9000'}]},
            {**safe, '9000/tcp': None}]
        for bindings in unsafe:
            with self.subTest(bindings=bindings):
                self.assertFalse(self.manager._safe_kokoro_bindings(json.dumps(bindings).encode()))
        self.assertFalse(self.manager._safe_kokoro_bindings(b'{broken'))
        self.assertFalse(self.manager._safe_kokoro_bindings(b' ' * 65537))

    def test_kokoro_starts_only_existing_verified_container_without_images_or_creation(self):
        executable = self.executable('Docker/docker.exe')
        self.only('kokoro')
        inspected = subprocess.CompletedProcess([], 0, json.dumps({'7860/tcp': [
            {'HostIp': '127.0.0.1', 'HostPort': '7860'}]}).encode(), b'')
        started = subprocess.CompletedProcess([], 0, b'storyforge-kokoro', b'')
        with patch.object(self.manager, '_ready', return_value=False), \
             patch.object(self.manager, '_existing_executable', return_value=executable), \
             patch.object(self.manager, '_docker_ready', return_value=True), \
             patch.object(self.manager, '_docker', side_effect=[inspected, started]) as docker, \
             patch.object(self.manager, '_wait', return_value=True):
            self.manager.start()
            states = self.wait_idle()
        self.assertEqual(states['kokoro']['state'], 'ready')
        self.assertEqual([call.args[1] for call in docker.call_args_list], [
            ['inspect', '--type', 'container', '--format', '{{json .HostConfig.PortBindings}}', 'storyforge-kokoro'],
            ['start', 'storyforge-kokoro']])
        self.popen.assert_not_called()

    def test_unsafe_existing_kokoro_container_is_left_unchanged(self):
        executable = self.executable('Docker/docker.exe')
        self.only('kokoro')
        inspected = subprocess.CompletedProcess([], 0, b'{"7860/tcp": [{"HostIp": "0.0.0.0", "HostPort": "7860"}]}', b'')
        with patch.object(self.manager, '_ready', return_value=False), \
             patch.object(self.manager, '_existing_executable', return_value=executable), \
             patch.object(self.manager, '_docker_ready', return_value=True), \
             patch.object(self.manager, '_docker', return_value=inspected) as docker:
            self.manager.start()
            states = self.wait_idle()
        self.assertEqual(states['kokoro']['state'], 'needs_setup')
        self.assertEqual(docker.call_count, 1)
        self.assertEqual(docker.call_args.args[1][0], 'inspect')
        self.popen.assert_not_called()

    def test_live_child_is_reused_only_for_same_command_and_working_directory(self):
        cancel = threading.Event()
        self.manager._run_cancel = cancel
        first = self.executable('first/ComfyUI.exe')
        second = self.executable('second/ComfyUI.exe')
        self.manager._spawn('comfyui', [str(first)], first.parent, cancel)
        self.manager._spawn('comfyui', [str(first)], first.parent, cancel)
        self.assertEqual(self.popen.call_count, 1)
        self.manager._spawn('comfyui', [str(second)], second.parent, cancel)
        self.assertEqual(self.popen.call_count, 2)
        self.assertEqual(self.popen.call_args.args[0], [str(second)])

    def test_close_leaves_shared_backends_alive_and_prevents_new_launches(self):
        cancel = threading.Event()
        self.manager._run_cancel = cancel
        executable = self.executable('ComfyUI.exe')
        self.manager._spawn('comfyui', [str(executable)], executable.parent, cancel)
        self.manager.close()
        self.assertTrue(cancel.is_set())
        self.assertFalse(self.manager.start(manual=True)['starting'])
        self.child.terminate.assert_not_called()
        self.child.kill.assert_not_called()
        self.child.wait.assert_not_called()
        self.assertEqual(self.popen.call_count, 1)


if __name__ == '__main__':
    unittest.main()
