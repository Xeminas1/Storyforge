"""Synthetic production-path checks for optional notes and strict turn state.

The scripted model never contacts Ollama or reads personal campaign data. These
tests distinguish disposable metadata from narration and consequential changes.
"""
import copy
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import engine


LABELS = {'location': 'Lantern Pier', 'parent_area': 'Greyhaven', 'time_of_day': 'Dusk'}
HEADER = '[Lantern Pier - Greyhaven - Dusk]'
INTRO = (HEADER + '\n\n'
         'At Lantern Pier in Greyhaven, dusk settles over the harbour cranes. '
         'A ferryman coils a length of blue rope beside three empty mooring posts. '
         'Across the water, a lamplighter carries an oil can along the southern breakwater.')
FRESH = (HEADER + '\n\n'
         'Maribel locks the iron cabinet. A sealed parcel awaits collection. '
         'The courier places a cracked compass on the customs counter. '
         '"The sender paid in old copper," the courier tells the quartermaster.')
LATER = (HEADER + '\n\n'
         'A dockworker rings the warehouse bell. Two carts roll beneath the raised shutter. '
         'The quartermaster checks their painted numbers against a green cargo ledger.')
REPLACEMENT = (HEADER + '\n\n'
               'A glass bead rolls from the parcel onto the scales. '
               'Maribel examines its tiny engraved lighthouse beneath a magnifying lens. '
               'The courier finds a second wax seal inside the wrapping.')
LETTER = 'A sealed letter awaits an answer.'
CELLAR = 'The cellar door remains locked.'
PENDING = 'A missing ferry awaits inspection.'


def fact(text, evidence=None):
    return {'text': text, 'evidence': text if evidence is None else evidence}


class OptionalTurnNotesTests(unittest.TestCase):
    def setUp(self):
        directory = self.enterContext(tempfile.TemporaryDirectory())
        self.con = engine.open_db(Path(directory) / 'synthetic.db')
        self.addCleanup(self.con.close)
        world = engine.make_world(self.con, {
            'title': 'Harbour of Vale',
            'description': 'An original port story about cargo disputes and lighthouse keepers.'})
        campaign = engine.new_campaign(self.con, {
            'world_id': world['id'], 'pc_name': 'Mira', 'aliases': 'Lady Willow',
            'pronouns': 'she/her', 'species': 'High Elf'})
        self.cid = campaign['id']
        self.prior_memory = {
            'summary': 'A ferryman guards the western mooring.',
            'npcs': [{'name': 'Ferryman Orin', 'facts': ['Ferryman Orin guards the mooring.']}],
            'events': ['The lighthouse bell sounded twice.'],
            'open_threads': [LETTER, CELLAR, PENDING],
        }
        state = copy.deepcopy(campaign['state'])
        state.update(LABELS)
        state.update(inventory=['brass key'], journal=['A foghorn sounded beyond the quay.'],
                     scene_memory=copy.deepcopy(self.prior_memory))
        with self.con:
            self.con.execute('UPDATE campaigns SET state_json=? WHERE id=?', (json.dumps(state), self.cid))
            first = self.con.execute(
                'INSERT INTO messages (campaign_id,role,content,created_at) VALUES (?,?,?,?)',
                (self.cid, 'gm', INTRO, engine.now())).lastrowid
            self.con.execute('INSERT INTO turn_checkpoints VALUES (?,?,?,?)',
                             (first, json.dumps(state), json.dumps(state), '__START__'))

    def snapshot(self):
        return list(self.con.iterdump())

    def scripted(self, narration, changes=None):
        calls = []
        proposal = copy.deepcopy(changes or {})

        def chat(messages, model):
            calls.append(copy.deepcopy(messages))
            self.assertEqual(model, 'ministral-3:14b')
            return json.dumps({'narration': narration, 'state_updates': proposal})

        chat.requires_state_evidence = True
        return chat, calls, proposal

    def play(self, narration=FRESH, changes=None, action='I listen.'):
        chat, calls, proposal = self.scripted(narration, changes)
        original = copy.deepcopy(proposal)
        result = engine.play_turn(self.con, self.cid, action, model='ministral-3:14b', chat=chat)
        self.assertEqual(len(calls), 1, 'Optional notes must not force a corrective generation.')
        self.assertEqual(proposal, original)
        self.assertEqual(result['state']['inventory'], ['brass key'])
        return result

    def assert_old_memory(self, result):
        self.assertEqual(result['state']['scene_memory'], self.prior_memory)

    def assert_atomic_rejection(self, narration=FRESH, changes=None, action='I listen.'):
        before = self.snapshot()
        chat, calls, proposal = self.scripted(narration, changes)
        original = copy.deepcopy(proposal)
        with self.assertRaisesRegex(ValueError, 'Nothing was saved'):
            engine.play_turn(self.con, self.cid, action, model='ministral-3:14b', chat=chat)
        self.assertEqual(len(calls), 2)
        self.assertEqual(self.snapshot(), before)
        self.assertEqual(proposal, original)

    def test_unsupported_optional_journal_is_omitted_without_losing_good_prose(self):
        result = self.play(changes={
            'journal_entry': 'The lighthouse has collapsed.',
            'evidence': {'journal_entry': 'The lighthouse has collapsed.'}})
        self.assertEqual(result['narration'], FRESH)
        self.assertEqual(result['state']['journal'], ['A foghorn sounded beyond the quay.'])
        self.assert_old_memory(result)

    def test_unrequested_player_behavior_in_optional_journal_still_rejects_atomically(self):
        self.assert_atomic_rejection(changes={
            'journal_entry': 'Mira decides to accept the contract.',
            'evidence': {'journal_entry': 'Mira decides to accept the contract.'}})

    def test_invalid_summary_preserves_the_previous_summary_and_valid_siblings(self):
        observed = 'Maribel locks the iron cabinet.'
        changes = {'scene_memory': {
            'summary': fact('Maribel secures the entrance.'),
            'npcs': [{'name': 'Maribel', 'fact': observed, 'evidence': observed}],
            'events': [fact(observed)]}}
        original = copy.deepcopy(changes)
        result = self.play(changes=changes)
        memory = result['state']['scene_memory']
        self.assertEqual(memory['summary'], self.prior_memory['summary'])
        self.assertIn({'name': 'Maribel', 'facts': [observed]}, memory['npcs'])
        self.assertEqual(memory['events'], self.prior_memory['events'] + [observed])
        self.assertEqual(memory['open_threads'], self.prior_memory['open_threads'])
        self.assertEqual(changes, original)

    def test_npc_notes_with_missing_visible_evidence_are_filtered_individually(self):
        observed = 'Maribel locks the iron cabinet.'
        unsupported = 'Invented Captain watches the eastern road.'
        changes = {'scene_memory': {'npcs': [
            {'name': 'Maribel', 'fact': observed, 'evidence': observed},
            {'name': 'Invented Captain', 'fact': unsupported, 'evidence': unsupported},
        ]}}
        result = self.play(changes=changes)
        self.assertEqual(result['state']['scene_memory']['npcs'],
                         self.prior_memory['npcs'] + [{'name': 'Maribel', 'facts': [observed]}])

    def test_player_alias_and_missing_npc_subject_still_reject_atomically(self):
        appearance = "Lady Willow's cloak bears a silver clasp."
        observed = 'Maribel locks the iron cabinet.'
        for npc in (
            {'name': 'Lady Willow', 'fact': appearance, 'evidence': appearance},
            {'name': 'Unnamed Sentry', 'fact': observed, 'evidence': observed},
        ):
            with self.subTest(name=npc['name']):
                self.assert_atomic_rejection(FRESH + '\n\n' + appearance,
                                             {'scene_memory': {'npcs': [npc]}})

    def test_events_and_open_threads_keep_valid_siblings_only(self):
        event = 'Maribel locks the iron cabinet.'
        thread = 'A sealed parcel awaits collection.'
        changes = {'scene_memory': {
            'events': [fact('The tower collapses.'), fact(event), fact('')],
            'open_threads': [fact('The courier needs a royal pardon.'), fact(thread),
                             fact('The parcel needs collecting.', thread)],
        }}
        result = self.play(changes=changes)
        self.assertEqual(result['state']['scene_memory']['events'], self.prior_memory['events'] + [event])
        self.assertEqual(result['state']['scene_memory']['open_threads'],
                         self.prior_memory['open_threads'] + [thread])

    def test_resolution_notes_require_an_existing_thread_and_matching_visible_evidence(self):
        resolution = ("The ledger note '" + LETTER + "' is crossed out after the courier delivers the reply.")
        changes = {'scene_memory': {'resolve_threads': [
            fact(LETTER, resolution),
            fact(CELLAR, 'Maribel locks the iron cabinet.'),
        ]}}
        result = self.play(FRESH + '\n\n' + resolution, changes)
        self.assertEqual(result['state']['scene_memory']['open_threads'], [CELLAR, PENDING])
        self.assertEqual(result['state']['scene_memory']['events'], self.prior_memory['events'])

    def test_resolving_a_nonexistent_thread_still_rejects_atomically(self):
        unknown = 'The warehouse debt remains unpaid.'
        self.assert_atomic_rejection(FRESH + '\n\n' + unknown,
                                     {'scene_memory': {'resolve_threads': [fact(unknown)]}})

    def test_optional_paraphrases_are_discarded_without_fuzzy_fact_matching(self):
        paraphrase = 'Maribel has locked the iron cabinet.'
        observed = 'Maribel locks the iron cabinet.'
        result = self.play(changes={'scene_memory': {
            'summary': fact(paraphrase, observed), 'events': [fact(paraphrase, observed)],
            'open_threads': [fact('A parcel awaits collection.', 'A sealed parcel awaits collection.')],
        }})
        self.assert_old_memory(result)

    def test_missing_quotes_do_not_hide_unrequested_player_behavior_in_memory(self):
        unsafe = 'Mira decides to sign the contract.'
        for field in ('summary', 'events', 'open_threads'):
            with self.subTest(field=field):
                note = fact(unsafe)
                value = note if field == 'summary' else [note]
                self.assert_atomic_rejection(changes={'scene_memory': {field: value}})

    def test_filtering_does_not_mutate_the_decoded_update_object(self):
        changes = {
            'location': 'lantern   pier',
            'evidence': {'location': 'An unnecessary cosmetic update.'},
            'scene_memory': {'summary': fact('An unsupported optional summary.'),
                             'events': [fact('Maribel locks the iron cabinet.')]},
        }
        original = copy.deepcopy(changes)
        # Expose the parser's owned object at the boundary: pruning must work
        # on a copy rather than edit the decoded proposal supplied to the turn.
        with patch.object(engine, 'parse_gm_response', return_value=(FRESH, changes)):
            result = self.play(changes=changes)
        self.assertEqual(changes, original)
        self.assertEqual(result['state']['location'], LABELS['location'])
        self.assertEqual(result['state']['scene_memory']['summary'], self.prior_memory['summary'])
        self.assertEqual(result['state']['scene_memory']['events'],
                         self.prior_memory['events'] + ['Maribel locks the iron cabinet.'])

    def test_all_invalid_optional_notes_leave_prior_data_unchanged(self):
        changes = {'journal_entry': 'An unnarrated trial has ended.', 'scene_memory': {
            'summary': fact('A different scene is underway.'),
            'npcs': [{'name': 'Phantom', 'fact': 'Phantom rules the quay.', 'evidence': 'Phantom rules the quay.'}],
            'events': [fact('A bridge has fallen.')],
            'open_threads': [fact('A secret tunnel needs exploring.')],
            'resolve_threads': [fact(CELLAR, 'A bridge has fallen.')],
        }}
        result = self.play(changes=changes)
        self.assert_old_memory(result)
        self.assertEqual(result['state']['journal'], ['A foghorn sounded beyond the quay.'])

    def test_cosmetic_scene_patch_and_heading_preserve_canonical_labels_without_new_evidence(self):
        narration = '[lantern   pier - GREYHAVEN - dusk]\n\n' + FRESH.split('\n\n', 1)[1]
        result = self.play(narration, {'location': ' LANTERN   PIER ', 'parent_area': 'greyhaven',
                                      'time_of_day': 'dusk'})
        self.assertEqual({field: result['state'][field] for field in LABELS}, LABELS)
        self.assertEqual(result['narration'], FRESH)

    def test_escaped_emphasis_and_backtick_evidence_use_the_same_deterministic_normalization(self):
        raw_sign = r'The courier reads \*KEEP CLOSED\* from the sign.'
        raw_mark = 'A seal is marked `COPPER`.'
        sign = 'The courier reads *KEEP CLOSED* from the sign.'
        mark = 'A seal is marked COPPER.'
        result = self.play(HEADER + '\n\n' + raw_sign + ' ' + raw_mark, {
            'journal_entry': sign, 'evidence': {'journal_entry': raw_sign},
            'scene_memory': {'events': [fact(mark, raw_mark)]},
        })
        self.assertEqual(result['state']['journal'][-1], sign)
        self.assertEqual(result['state']['scene_memory']['events'][-1], mark)
        self.assertIn(sign + ' ' + mark, result['narration'])

    def test_supported_actual_transition_accepts_normalized_literal_evidence(self):
        raw = r'At \*Customs Office\*, a clerk lays a red ledger on the desk.'
        narration = '[Customs Office - Greyhaven - Dusk]\n\n' + raw
        result = self.play(narration, {'location': 'Customs Office', 'evidence': {'location': raw}},
                           action='I walk to the Customs Office.')
        self.assertEqual(result['state']['location'], 'Customs Office')
        self.assertTrue(result['narration'].startswith('[Customs Office - Greyhaven - Dusk]\n\n'))

    def test_unsupported_consequential_changes_still_reject_atomically(self):
        for changes in (
            {'location': 'High Tower'}, {'parent_area': 'Northbank'}, {'time_of_day': 'Midnight'},
            {'inventory_add': ['ruby seal']}, {'inventory_remove': ['brass key']},
        ):
            with self.subTest(changes=changes):
                combined = copy.deepcopy(changes)
                combined['scene_memory'] = {'summary': fact('This optional note is unsupported.')}
                self.assert_atomic_rejection(changes=combined)

    def test_actual_transition_does_not_accept_paraphrased_evidence(self):
        body = 'At High Tower, a sentry checks a bronze bell.'
        narration = '[High Tower - Greyhaven - Dusk]\n\n' + body
        self.assert_atomic_rejection(narration, {
            'location': 'High Tower', 'evidence': {'location': 'A guard checks a bell at High Tower.'}},
            action='I walk to High Tower.')

    def test_unsupported_heading_and_placeholder_erasure_still_reject_atomically(self):
        with self.subTest(kind='heading'):
            self.assert_atomic_rejection('[High Tower - Greyhaven - Dusk]\n\n' + FRESH.split('\n\n', 1)[1])
        with self.subTest(kind='placeholder'):
            self.assert_atomic_rejection(changes={
                'location': 'Unknown', 'evidence': {'location': 'The courier marks a box Unknown.'}})

    def test_narration_player_control_and_replay_are_not_optional_metadata_failures(self):
        changes = {'scene_memory': {'summary': fact('An unsupported optional note.')}}
        with self.subTest(kind='agency'):
            self.assert_atomic_rejection(HEADER + '\n\nMira decides to accept the contract.', changes)
        with self.subTest(kind='replay'):
            self.assert_atomic_rejection(INTRO, changes)

    def test_retry_accepts_good_replacement_without_duplicating_action_or_keeping_future_memory(self):
        first = self.play()
        target = first['messages'][-1]['id']
        player = first['messages'][-2]
        later_event = 'A dockworker rings the warehouse bell.'
        self.play(LATER, {'scene_memory': {'events': [fact(later_event)]}}, action='I wait.')
        observed = 'A glass bead rolls from the parcel onto the scales.'
        changes = {'scene_memory': {'summary': fact('A captain demands payment.'),
                                    'events': [fact(observed), fact('A roof caves in.')]}}
        chat, calls, proposal = self.scripted(REPLACEMENT, changes)
        original = copy.deepcopy(proposal)
        result = engine.retry_message(self.con, self.cid, target,
                                      feedback='Keep the current scene and let me choose Mira\'s actions.',
                                      model='ministral-3:14b', chat=chat)
        self.assertEqual(len(calls), 1)
        self.assertEqual(proposal, original)
        self.assertEqual([message['role'] for message in result['messages']], ['gm', 'player', 'gm'])
        self.assertEqual(result['messages'][1]['id'], player['id'])
        self.assertEqual(result['messages'][1]['content'], 'I listen.')
        self.assertEqual(sum(message['role'] == 'player' for message in result['messages']), 1)
        self.assertEqual(result['state']['scene_memory']['summary'], self.prior_memory['summary'])
        self.assertEqual(result['state']['scene_memory']['events'], self.prior_memory['events'] + [observed])
        self.assertNotIn(later_event, json.dumps(result['state']))
        self.assertIsNone(self.con.execute('SELECT 1 FROM turn_checkpoints WHERE gm_message_id=?',
                                          (target,)).fetchone())
        checkpoint = self.con.execute('SELECT state_before,state_after,source_action FROM turn_checkpoints WHERE gm_message_id=?',
                                      (result['messages'][-1]['id'],)).fetchone()
        self.assertEqual(json.loads(checkpoint['state_before'])['scene_memory'], self.prior_memory)
        self.assertEqual(json.loads(checkpoint['state_after']), result['state'])
        self.assertEqual(checkpoint['source_action'], 'I listen.')

    def test_failed_retry_keeps_messages_feedback_checkpoints_and_state_identical(self):
        first = self.play()
        target = first['messages'][-1]['id']
        self.play(LATER, action='I wait.')
        before = self.snapshot()
        changes = {'location': 'High Tower', 'scene_memory': {'summary': fact('Another optional mistake.')}}
        chat, calls, proposal = self.scripted(REPLACEMENT, changes)
        original = copy.deepcopy(proposal)
        with self.assertRaisesRegex(ValueError, 'Nothing was saved'):
            engine.retry_message(self.con, self.cid, target, feedback='Do not move the scene.',
                                 model='ministral-3:14b', chat=chat)
        self.assertEqual(len(calls), 2)
        self.assertEqual(self.snapshot(), before)
        self.assertEqual(proposal, original)


if __name__ == '__main__':
    unittest.main()
