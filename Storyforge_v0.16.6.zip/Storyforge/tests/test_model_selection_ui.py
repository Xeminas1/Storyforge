"""Persist the player's local GM model choice across refresh and readiness checks."""
import unittest

import test_story_request_ui as story_ui


MODEL_HARNESS = r"""
nodes.set('installed-models',new Element('installed-models'));
const modelStorage=new Map();
const storage={getItem:key=>modelStorage.has(key)?modelStorage.get(key):null,
               setItem:(key,value)=>modelStorage.set(key,String(value))};
context.localStorage=storage;
get('model').value='qwen3:8b';
const modelUi=vm.runInContext('({initializeGameMasterModel,refreshInstalledModels,selectedGameMasterModel})',context);
function reloadModelPage(localStorage=storage){
  const model=new Element('model'),installed=new Element('installed-models');
  model.value='qwen3:8b';
  const elements=new Map([['model',model],['installed-models',installed]]);
  const page=vm.createContext({document:{getElementById:id=>elements.get(id)||null},
    window:{requestAnimationFrame:fn=>fn()},console,setTimeout,clearTimeout,localStorage});
  vm.runInContext(source.slice(0,bootstrap),page);
  const ui=vm.runInContext('({initializeGameMasterModel,refreshInstalledModels,selectedGameMasterModel})',page);
  ui.initializeGameMasterModel();
  return {context:page,ui,model,installed};
}
function returnModels(models){
  context.modelResult={models};
  vm.runInContext('request=async()=>modelResult;',context);
}
"""


@unittest.skipUnless(story_ui.NODE, 'Node is required for model selection browser checks')
class ModelSelectionUiTests(unittest.TestCase):
    def run_js(self, script):
        story_ui.StoryRequestUiTests.run_js(self, MODEL_HARNESS + '\n' + script)

    def test_new_browser_keeps_default_without_creating_a_saved_choice(self):
        self.run_js(r"""
modelUi.initializeGameMasterModel();
assert.equal(get('model').value,'qwen3:8b');
assert.equal(modelStorage.has('sf_model'),false);
returnModels(['qwen3:8b','qwen3:14b','qwen3.5:9b']);
await modelUi.refreshInstalledModels();
assert.equal(get('model').value,'qwen3:8b');
assert.equal(modelStorage.has('sf_model'),false);
""")

    def test_explicit_choice_survives_a_new_page_and_installed_model_refresh(self):
        self.run_js(r"""
modelUi.initializeGameMasterModel();
get('model').value='qwen3:14b';get('model').oninput();
assert.equal(modelStorage.get('sf_model'),'qwen3:14b');
const page=reloadModelPage();
assert.equal(page.model.value,'qwen3:14b');
page.context.modelResult={models:['qwen3:8b','qwen3:14b','qwen3.5:9b']};
vm.runInContext('request=async()=>modelResult;',page.context);
await page.ui.refreshInstalledModels();
assert.equal(page.model.value,'qwen3:14b');
assert.equal(modelStorage.get('sf_model'),'qwen3:14b');
""")

    def test_change_trims_the_exact_saved_tag_and_keeps_other_preferences(self):
        self.run_js(r"""
modelStorage.set('sf_engine','browser');
modelUi.initializeGameMasterModel();
get('model').value='  custom-local:14b  ';get('model').onchange();
assert.equal(get('model').value,'custom-local:14b');
assert.equal(modelStorage.get('sf_model'),'custom-local:14b');
assert.equal(modelStorage.get('sf_engine'),'browser');
assert.equal(reloadModelPage().model.value,'custom-local:14b');
""")

    def test_storage_denial_does_not_break_selection_or_model_refresh(self):
        self.run_js(r"""
context.localStorage={getItem(){throw new Error('Storage blocked');},setItem(){throw new Error('Storage full');}};
modelUi.initializeGameMasterModel();
assert.equal(get('model').value,'qwen3:8b');
get('model').value='qwen3:14b';get('model').oninput();
returnModels(['qwen3:8b']);await modelUi.refreshInstalledModels();
assert.equal(get('model').value,'qwen3:14b');
assert.equal(modelUi.selectedGameMasterModel(),'qwen3:14b');
const page=reloadModelPage(context.localStorage);
assert.equal(page.model.value,'qwen3:8b');
""")

    def test_explicit_missing_model_is_retained_with_an_actionable_warning(self):
        self.run_js(r"""
modelStorage.set('sf_model','qwen3:14b');modelUi.initializeGameMasterModel();
returnModels(['qwen3:8b']);await modelUi.refreshInstalledModels(true);
assert.equal(get('model').value,'qwen3:14b');
assert.equal(modelStorage.get('sf_model'),'qwen3:14b');
assert.ok(get('model').title.includes('Choose an installed model'));
assert.equal(app.notices.length,1);assert.equal(app.notices[0].fail,true);
assert.ok(app.notices[0].text.includes('qwen3:14b'));
assert.ok(app.notices[0].text.includes('Choose an installed model'));
""")

    def test_empty_warmup_list_does_not_erase_saved_model(self):
        self.run_js(r"""
modelStorage.set('sf_model','qwen3:14b');modelUi.initializeGameMasterModel();
returnModels([]);await modelUi.refreshInstalledModels(false);
assert.equal(get('model').value,'qwen3:14b');assert.equal(app.notices.length,0);
returnModels(['qwen3:8b','qwen3:14b']);await modelUi.refreshInstalledModels(true);
assert.equal(get('model').value,'qwen3:14b');assert.equal(app.notices.length,0);
assert.equal(get('model').title,'Installed Ollama model');
""")

    def test_delayed_model_list_cannot_replace_a_choice_typed_while_waiting(self):
        self.run_js(r"""
modelUi.initializeGameMasterModel();
const pending=modelUi.refreshInstalledModels(true);
get('model').value='qwen3:14b';get('model').oninput();
resolveResponse({models:['qwen3:8b']});await pending;
assert.equal(get('model').value,'qwen3:14b');
assert.equal(modelStorage.get('sf_model'),'qwen3:14b');
assert.equal(app.notices.length,1);
""")

    def test_fresh_install_fallback_chooses_an_installed_model_then_keeps_it(self):
        self.run_js(r"""
modelUi.initializeGameMasterModel();
returnModels(['other-local:8b','qwen3.5:9b']);await modelUi.refreshInstalledModels();
assert.equal(get('model').value,'qwen3.5:9b');
returnModels(['qwen3:8b','qwen3.5:9b','qwen3.5:14b']);await modelUi.refreshInstalledModels();
assert.equal(get('model').value,'qwen3.5:9b');
assert.equal(modelStorage.has('sf_model'),false);
""")

    def test_turn_uses_and_saves_the_visible_selection_without_needing_blur(self):
        self.run_js(r"""
modelUi.initializeGameMasterModel();
get('model').value='qwen3:14b';get('action').value='I wait.';
const pending=app.sendAction();
assert.equal(app.calls[0].options.body.model,'qwen3:14b');
assert.equal(modelStorage.get('sf_model'),'qwen3:14b');
resolveResponse(result);await pending;
assert.equal(reloadModelPage().model.value,'qwen3:14b');
""")

    def test_retry_uses_and_saves_the_visible_selection(self):
        self.run_js(r"""
modelUi.initializeGameMasterModel();
get('model').value='qwen3:14b';
app.openStoryMessageAction(2,'retry');
const pending=get('confirm-story-correction').onclick();
assert.equal(app.calls[0].url,'/api/campaigns/first/messages/2/retry');
assert.equal(app.calls[0].options.body.model,'qwen3:14b');
assert.equal(modelStorage.get('sf_model'),'qwen3:14b');
resolveResponse(result);await pending;
assert.equal(reloadModelPage().model.value,'qwen3:14b');
""")

    def test_empty_submission_shows_the_same_default_that_is_sent(self):
        self.run_js(r"""
modelStorage.set('sf_model','qwen3:14b');modelUi.initializeGameMasterModel();
get('model').value='  ';get('model').oninput();get('action').value='I wait.';
const pending=app.sendAction();
assert.equal(app.calls[0].options.body.model,'qwen3:8b');
assert.equal(get('model').value,'qwen3:8b');
assert.equal(modelStorage.get('sf_model'),'qwen3:8b');
resolveResponse(result);await pending;
""")


if __name__ == '__main__':
    unittest.main()
