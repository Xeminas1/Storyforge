@echo off
setlocal
cd /d "%~dp0"
echo Storyforge update check - read-only diagnostics
 echo.
if exist "C:\Storyforge\.venv\Scripts\python.exe" (
  "C:\Storyforge\.venv\Scripts\python.exe" "%~dp0collect_update.py"
  goto finished
)
if exist "C:\Storyforge\venv\Scripts\python.exe" (
  "C:\Storyforge\venv\Scripts\python.exe" "%~dp0collect_update.py"
  goto finished
)
where py.exe >nul 2>nul
if not errorlevel 1 (
  py -3 "%~dp0collect_update.py"
  goto finished
)
where python.exe >nul 2>nul
if not errorlevel 1 (
  python "%~dp0collect_update.py"
  goto finished
)
echo Python could not be found. Tell Codex how Storyforge is normally launched.
goto done
:finished
if errorlevel 1 echo The check could not finish. Copy the error shown above for Codex.
:done
echo.
pause
