"""Read-only Storyforge update diagnostic. Does not import Storyforge modules.

Only approved application-file fingerprints, numeric version/cache metadata,
selected updater status fields, and two fixed localhost GET endpoints are read.
No source text, server response body, error message, personal story, or database
is retained in the report. This is a standalone helper, not an application update.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import urllib.error
import urllib.request

APP_FILES = ('updater.py', 'server.py', 'engine.py')
HTTP_PATHS = ('/api/health', '/api/updates')
BASE_URL = 'http://127.0.0.1:8787'
READ_LIMIT = 32 * 1024
SOURCE_LIMIT = 8 * 1024 * 1024
MAX_RECORDS = 500
VERSION_RE = re.compile(r'^\d{1,5}\.\d{1,5}\.\d{1,5}$')
SOURCE_VERSION_RE = re.compile(
    rb'''(?m)^VERSION[ \t]*=[ \t]*["'](\d{1,5}\.\d{1,5}\.\d{1,5})["'][ \t]*(?:\r?$|\#)''')
CACHE_NAME_RE = re.compile(r'^(updater|server|engine)\.cpython-\d{2,3}(?:\.opt-[12])?\.pyc$')
CACHE_VERSION_RE = re.compile(rb'(?<![0-9.])(\d{1,5}\.\d{1,5}\.\d{1,5})(?![0-9.])')
PHASES = frozenset(('scheduled', 'installing', 'completed', 'rolled_back', 'failed'))
ACTIVE_PHASES = frozenset(('scheduled', 'installing'))
TERMINAL_PHASES = frozenset(('completed', 'rolled_back', 'failed'))


def error_type(exc: BaseException) -> str:
    """Store exception class only; messages may contain paths or response data."""
    return type(exc).__name__


def numeric_version(value: object) -> str | None:
    return value if isinstance(value, str) and VERSION_RE.fullmatch(value) else None


def selected_status(value: object) -> dict:
    """Explicit allowlist. Never retain error/backup/channel/token/story fields."""
    if not isinstance(value, dict):
        return {}
    result = {}
    phase = value.get('phase')
    if isinstance(phase, str) and phase in PHASES:
        result['phase'] = phase
    for key in ('target_version', 'version'):
        version = numeric_version(value.get(key))
        if version is not None:
            result[key] = version
    timestamp = value.get('timestamp')
    if type(timestamp) in (int, float) and 0 <= timestamp <= 10**12:
        result['timestamp'] = timestamp
    return result


def read_json(path: Path) -> object:
    if path.is_symlink():
        raise ValueError('Symbolic links are not read')
    with path.open('rb') as handle:
        payload = handle.read(READ_LIMIT + 1)
    if len(payload) > READ_LIMIT:
        raise ValueError('Diagnostic read limit exceeded')
    return json.loads(payload)


def disk_status(root: Path) -> dict:
    try:
        return selected_status(read_json(root / 'data' / 'updates' / 'status.json'))
    except (OSError, ValueError, TypeError) as exc:
        return {'error_type': error_type(exc)}


def file_fingerprint(path: Path, *, include_version: bool = False) -> dict:
    try:
        if path.is_symlink():
            raise ValueError('Symbolic links are not read')
        with path.open('rb') as handle:
            stat = os.fstat(handle.fileno())
            if stat.st_size > SOURCE_LIMIT:
                raise ValueError('Diagnostic read limit exceeded')
            payload = handle.read(SOURCE_LIMIT + 1)
        if len(payload) > SOURCE_LIMIT:
            raise ValueError('Diagnostic read limit exceeded')
        result = {'size': len(payload), 'mtime_ns': stat.st_mtime_ns,
                  'sha256': hashlib.sha256(payload).hexdigest()}
        if include_version:
            match = SOURCE_VERSION_RE.search(payload)
            if match:
                result['version'] = match.group(1).decode('ascii')
        return result
    except (OSError, ValueError) as exc:
        return {'error_type': error_type(exc)}


def source_snapshot(root: Path) -> dict:
    return {name: file_fingerprint(root / name, include_version=name == 'updater.py')
            for name in APP_FILES}


def cache_snapshot(root: Path) -> list[dict]:
    """Inspect bounded cache headers/numeric tags; never load or execute bytecode."""
    folder = root / '__pycache__'
    try:
        if folder.is_symlink():
            return [{'error_type': 'ValueError'}]
        candidates = []
        for entry in folder.iterdir():
            if CACHE_NAME_RE.fullmatch(entry.name) and not entry.is_symlink():
                try:
                    candidates.append((entry.stat().st_mtime_ns, entry))
                except OSError:
                    continue
        candidates.sort(key=lambda item: item[0], reverse=True)
        result = []
        for _, path in candidates[:9]:
            try:
                with path.open('rb') as handle:
                    stat = os.fstat(handle.fileno())
                    prefix = handle.read(64 * 1024)
                result.append({'name': path.name, 'size': stat.st_size,
                               'mtime_ns': stat.st_mtime_ns,
                               'header_hex': prefix[:16].hex(),
                               'numeric_version_candidates': sorted({
                                   match.group(1).decode('ascii')
                                   for match in CACHE_VERSION_RE.finditer(prefix)})[:8]})
            except OSError as exc:
                result.append({'name': path.name, 'error_type': error_type(exc)})
        return result
    except FileNotFoundError:
        return []
    except OSError as exc:
        return [{'error_type': error_type(exc)}]


def staging_snapshot(root: Path) -> list[dict]:
    """Latest three staged versions plus approved source-file fingerprints only."""
    folder = root / 'data' / 'updates' / 'staging'
    try:
        if folder.is_symlink():
            return [{'error_type': 'ValueError'}]
        candidates = []
        for entry in folder.iterdir():
            if not re.fullmatch(r'[a-f0-9]{32}', entry.name) or entry.is_symlink():
                continue
            metadata = entry / 'metadata.json'
            try:
                if not metadata.is_symlink():
                    candidates.append((metadata.stat().st_mtime_ns, entry))
            except OSError:
                continue
        candidates.sort(key=lambda item: item[0], reverse=True)
        result = []
        for mtime, entry in candidates[:3]:
            selected = {'metadata_mtime_ns': mtime}
            try:
                value = read_json(entry / 'metadata.json')
                version = numeric_version(value.get('version')) if isinstance(value, dict) else None
                if version is not None:
                    selected['version'] = version
                selected['source_files'] = source_snapshot(entry / 'files')
            except (OSError, ValueError, TypeError) as exc:
                selected['error_type'] = error_type(exc)
            result.append(selected)
        return result
    except FileNotFoundError:
        return []
    except OSError as exc:
        return [{'error_type': error_type(exc)}]


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def loopback_opener():
    """A direct fixed-loopback connection, without proxies, redirects or cookies."""
    return urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())


def fetch_endpoint(opener, path: str) -> dict:
    if path not in HTTP_PATHS:
        raise ValueError('Only the two approved localhost endpoints are supported')
    result = {}
    try:
        request = urllib.request.Request(BASE_URL + path, method='GET',
                                         headers={'Accept': 'application/json'})
        with opener.open(request, timeout=0.5) as response:
            result['http_status'] = response.status
            payload = response.read(READ_LIMIT + 1)
        if len(payload) > READ_LIMIT:
            return {**result, 'error_type': 'ResponseTooLarge'}
        value = json.loads(payload)
        if not isinstance(value, dict):
            return {**result, 'error_type': 'UnexpectedResponseType'}
        version = numeric_version(value.get('version'))
        if version is not None:
            result['version'] = version
        if path == '/api/health':
            if type(value.get('ok')) is bool:
                result['ok'] = value['ok']
        else:
            result['status'] = selected_status(value.get('status'))
        return result
    except urllib.error.HTTPError as exc:
        result.update(http_status=exc.code, error_type=error_type(exc))
        exc.close()
    except (OSError, ValueError, TypeError) as exc:
        result['error_type'] = error_type(exc)
    return result


def collect_sample(root: Path, opener) -> dict:
    return {'source_files': source_snapshot(root), 'disk_status': disk_status(root),
            'health': fetch_endpoint(opener, '/api/health'),
            'updates': fetch_endpoint(opener, '/api/updates')}


class TransitionRecorder:
    def __init__(self, limit: int = MAX_RECORDS, heartbeat: float = 5.0):
        self.limit = max(2, min(MAX_RECORDS, limit))
        self.heartbeat = heartbeat
        self.records = []
        self.dropped_records = 0
        self.last_state = None
        self.last_recorded_at = float('-inf')

    def add(self, elapsed: float, state: dict, *, force: bool = False) -> bool:
        signature = json.dumps(state, sort_keys=True, separators=(',', ':'), allow_nan=False)
        changed = signature != self.last_state
        if not (force or changed or elapsed - self.last_recorded_at >= self.heartbeat):
            return False
        record = {'elapsed_seconds': round(elapsed, 3),
                  'kind': 'transition' if changed else 'heartbeat', **state}
        if len(self.records) >= self.limit:
            # Keep the first observation and the most recent bounded history.
            del self.records[1]
            self.dropped_records += 1
        self.records.append(record)
        self.last_state = signature
        self.last_recorded_at = elapsed
        return True


class UpdateAttemptTracker:
    """An old completed/rollback status must not end a newly opened collector."""
    def __init__(self):
        self.activity_timestamp = None
        self.activity_seen = False
        self.initial_terminal_signatures = set()
        self.initialized = False

    def observe(self, state: dict) -> bool:
        statuses = [state.get('disk_status', {}), state.get('updates', {}).get('status', {})]
        if not self.initialized:
            for status in statuses:
                if status.get('phase') in TERMINAL_PHASES:
                    self.initial_terminal_signatures.add((status.get('phase'), status.get('timestamp')))
            self.initialized = True
        for status in statuses:
            if status.get('phase') in ACTIVE_PHASES:
                self.activity_seen = True
                timestamp = status.get('timestamp')
                if type(timestamp) in (int, float):
                    self.activity_timestamp = max(self.activity_timestamp or timestamp, timestamp)
        if not self.activity_seen:
            return False
        for status in statuses:
            if status.get('phase') not in TERMINAL_PHASES:
                continue
            timestamp = status.get('timestamp')
            signature = (status.get('phase'), timestamp)
            if signature in self.initial_terminal_signatures:
                continue
            if type(timestamp) not in (int, float):
                continue
            if self.activity_timestamp is not None and timestamp < self.activity_timestamp:
                continue
            return True
        return False


def enter_pressed() -> bool:
    if os.name != 'nt':
        return False
    try:
        import msvcrt
        while msvcrt.kbhit():
            if msvcrt.getwch() in ('\r', '\n'):
                return True
    except (ImportError, OSError):
        pass
    return False


def monitor(root: Path, seconds: float = 240, *, opener=None, sample_fn=None,
            clock=None, sleep=None, stop_requested=None, on_sample=None) -> dict:
    if not 1 <= seconds <= 600:
        raise ValueError('Duration must be between 1 and 600 seconds')
    clock = clock or time.monotonic
    sleep = sleep or time.sleep
    stop_requested = stop_requested or enter_pressed
    opener = opener or loopback_opener()
    sample_fn = sample_fn or (lambda: collect_sample(root, opener))
    started = clock()
    recorder = TransitionRecorder()
    tracker = UpdateAttemptTracker()
    terminal_at = None
    ready_observations = 0
    final_state = None
    reason = 'time_limit'
    try:
        while True:
            tick = clock()
            if stop_requested():
                reason = 'enter_pressed'
                break
            state = sample_fn()
            final_state = state
            elapsed = clock() - started
            if recorder.add(elapsed, state) and on_sample:
                on_sample(recorder.records[-1])
            if tracker.observe(state) and terminal_at is None:
                terminal_at = elapsed
            if terminal_at is not None:
                # Rollback writes its terminal status before starting the old
                # server. Keep observing until that process is ready as well.
                health = state.get('health', {})
                disk_version = state.get('source_files', {}).get('updater.py', {}).get('version')
                ready = (health.get('http_status') == 200 and health.get('ok') is True
                         and numeric_version(disk_version) is not None
                         and health.get('version') == disk_version)
                ready_observations = ready_observations + 1 if ready else 0
                if elapsed - terminal_at >= 3 and ready_observations >= 2:
                    reason = 'update_attempt_finished'
                    break
                if elapsed - terminal_at >= 30:
                    reason = 'update_result_without_confirmed_readiness'
                    break
            if elapsed >= seconds:
                break
            sleep(max(0.0, min(0.5 - (clock() - tick), seconds - elapsed)))
    except KeyboardInterrupt:
        reason = 'ctrl_c'
    except Exception as exc:
        reason = 'collector_error'
        recorder.add(clock() - started, {'error_type': error_type(exc)}, force=True)
    return {'stop_reason': reason, 'duration_seconds': round(clock() - started, 3),
            'sample_interval_seconds': 0.5, 'heartbeat_seconds': 5,
            'dropped_records': recorder.dropped_records,
            'records': recorder.records, 'last_observation': final_state}


def save_report(report: dict, output: Path | None = None) -> Path:
    if output is not None:
        with output.open('x', encoding='utf-8') as handle:
            json.dump(report, handle, indent=2, ensure_ascii=True, allow_nan=False)
            handle.write('\n')
        return output
    stamp = dt.datetime.now().strftime('%Y%m%d-%H%M%S')
    folder = Path(__file__).resolve().parent
    for suffix in range(1000):
        name = f'Storyforge-update-check-{stamp}' + (f'-{suffix}' if suffix else '') + '.json'
        path = folder / name
        try:
            return save_report(report, path)
        except FileExistsError:
            continue
    raise FileExistsError('Could not reserve a unique report filename')


def open_report(path: Path) -> None:
    if os.name != 'nt':
        return
    try:
        subprocess.Popen([r'C:\Windows\System32\notepad.exe', str(path.resolve())], shell=False)
    except OSError:
        pass


def valid_installation_root(root: Path) -> bool:
    try:
        return all((root / name).is_file() and not (root / name).is_symlink()
                   for name in ('server.py', 'updater.py'))
    except OSError:
        return False


def select_root(requested: Path | None) -> Path | None:
    if requested is not None:
        if valid_installation_root(requested):
            return requested
        print('That folder does not contain server.py and updater.py. No check was started.')
        return None
    default = Path(r'C:\Storyforge')
    if valid_installation_root(default):
        return default
    print(r'Storyforge was not found in C:\Storyforge.')
    print('Enter the folder containing server.py and updater.py, or press Enter to cancel.')
    try:
        answer = input('Storyforge folder: ').strip()
    except (EOFError, KeyboardInterrupt):
        print('\nCheck cancelled.')
        return None
    if not answer:
        print('Check cancelled.')
        return None
    if len(answer) >= 2 and answer.startswith('"') and answer.endswith('"'):
        answer = answer[1:-1]
    root = Path(answer)
    if not valid_installation_root(root):
        print('That folder does not contain server.py and updater.py. No check was started.')
        return None
    return root


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description='Read-only Storyforge update check.')
    parser.add_argument('--root', type=Path, default=None)
    parser.add_argument('--seconds', type=int, default=240, choices=range(1, 601), metavar='1-600')
    parser.add_argument('--output', type=Path, default=None)
    args = parser.parse_args(argv)
    root = select_root(args.root)
    if root is None:
        return 2 if args.root is not None else 0
    print('Storyforge update check (read-only)\n')
    print('Keep this window open. In your browser, retry the existing v0.16.1 ZIP update.')
    print('Wait for the result. This check ends shortly afterwards, or after four minutes.')
    print('Press Enter or Ctrl+C to finish early. Your report will open in Notepad.')
    print('This does not install, change, start, stop, or repair Storyforge or its programs.')
    print('The report excludes stories, saves, artwork, response bodies and error messages.\n')
    report = {'diagnostic': 'Storyforge read-only update check', 'format_version': 1,
              'started_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
              'root_exists': root.is_dir(),
              'helper_python_version': '.'.join(map(str, sys.version_info[:3])),
              'helper_executable': sys.executable,
              'application_interpreter': 'Unknown: the helper interpreter does not identify the running application interpreter.',
              'initial_snapshot': {'source_files': source_snapshot(root),
                                   'disk_status': disk_status(root),
                                   'cache_metadata': cache_snapshot(root),
                                   'staging': staging_snapshot(root)}}
    def progress(record):
        phase = record.get('disk_status', {}).get('phase', 'waiting')
        health = record.get('health', {})
        runtime = health.get('version', health.get('error_type', 'unknown'))
        print(f"{record['elapsed_seconds']:6.1f}s  update: {phase}  running version: {runtime}", flush=True)
    report['monitor'] = monitor(root, args.seconds, on_sample=progress)
    report['final_snapshot'] = {'source_files': source_snapshot(root),
                                'disk_status': disk_status(root),
                                'cache_metadata': cache_snapshot(root),
                                'staging': staging_snapshot(root)}
    report['finished_utc'] = dt.datetime.now(dt.timezone.utc).isoformat()
    try:
        path = save_report(report, args.output)
    except (OSError, ValueError) as exc:
        print('Could not save the report:', error_type(exc))
        return 1
    print('\nSaved report:', str(path.resolve()))
    print('Upload this JSON file to the Storyforge conversation.')
    open_report(path)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
