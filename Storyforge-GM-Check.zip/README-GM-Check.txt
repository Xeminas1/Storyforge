Storyforge GM continuity check

This is a diagnostic helper, not an application update. Do not put this ZIP
into Storyforge's Updates panel.

1. Extract Storyforge-GM-Check.py and Run-Storyforge-GM-Check.cmd into your
   existing Storyforge folder, beside engine.py (usually C:\Storyforge).
   These two new helper files do not replace any application files.
2. Start Ollama normally and leave the installed ministral-3:14b model in place.
   Close other GPU inference jobs while comparing response times.
3. Double-click Run-Storyforge-GM-Check.cmd. Leave its window open while it runs.
   Nine dependent synthetic steps may take several minutes. A failed step
   blocks its dependent steps instead of pretending that event happened.
4. The window prints the new JSON report path under Storyforge's data folder.
   Share that continuity-check JSON for review. It contains invented test-world
   prompts and generated responses, selected model metadata and timings.

No personal campaigns, portraits, artwork or settings are opened. The helper
does not change application source, download models, start services, install an
update or contact a cloud AI. It calls your already-running local Ollama.
The opening is authored setup; subsequent actions and a retry use the installed
Storyforge generation pipeline. Passing storage checks does not establish good
storytelling or perfect player agency. Read the synthetic prose in the report.

Optional PowerShell commands from the Storyforge folder:

py Storyforge-GM-Check.py --model ministral-3:14b --repeat 1
py Storyforge-GM-Check.py --model ministral-3:14b --model gemma3:12b --repeat 2

Only choose models already installed. The helper does not download the second
example model. --report path.json chooses a NEW report; existing files are
never overwritten. --storyforge-dir C:\Storyforge selects an installation.

You can remove the two helper files afterwards. Existing app updates and saved
campaigns remain separate. Keep the generated report if you want to compare a
later run with the same model and application version.
