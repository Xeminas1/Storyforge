@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 goto use_python
py -3 "%~dp0Storyforge-GM-Check.py" %*
goto finished
:use_python
python "%~dp0Storyforge-GM-Check.py" %*
:finished
echo.
pause
